/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : O-2018.06-SP1
// Date      : Tue Nov 10 23:15:27 2026
/////////////////////////////////////////////////////////////


module norm_v4_29_DW01_sub_16 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n8, n10, n11, n12, n13, n14, n15, n16, n17,
         n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30, n31,
         n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44, n45,
         n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59,
         n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73,
         n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86, n87,
         n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99, n100,
         n101, n102, n103, n104, n105, n106, n107, n108, n109, n110, n111,
         n112, n113, n114, n115, n116, n117, n118, n119, n120, n121, n122,
         n123, n124, n125, n126, n127, n128, n129, n130, n131, n132, n133,
         n134, n135, n136, n137, n207;

  OAI21X1 U6 ( .A0(n11), .A1(n8), .B0(n6), .Y(n5) );
  OAI21X1 U20 ( .A0(n20), .A1(n23), .B0(n21), .Y(n19) );
  OAI21X1 U44 ( .A0(n44), .A1(n47), .B0(n45), .Y(n43) );
  OAI21X1 U57 ( .A0(n72), .A1(n57), .B0(n58), .Y(n56) );
  OAI21X1 U61 ( .A0(n61), .A1(n64), .B0(n62), .Y(n60) );
  OAI21X1 U75 ( .A0(n75), .A1(n78), .B0(n76), .Y(n74) );
  OAI21X1 U90 ( .A0(n90), .A1(n93), .B0(n91), .Y(n89) );
  OAI21X1 U96 ( .A0(n96), .A1(n99), .B0(n97), .Y(n95) );
  OAI21X1 U103 ( .A0(n103), .A1(n106), .B0(n104), .Y(n102) );
  OAI21X1 U108 ( .A0(n108), .A1(B[0]), .B0(n109), .Y(n107) );
  INVXL U142 ( .A(B[2]), .Y(n136) );
  INVXL U143 ( .A(B[15]), .Y(n123) );
  INVXL U144 ( .A(B[18]), .Y(n120) );
  INVXL U145 ( .A(B[23]), .Y(n115) );
  INVXL U146 ( .A(B[6]), .Y(n132) );
  NAND2XL U147 ( .A(A[17]), .B(n121), .Y(n51) );
  NOR2X2 U148 ( .A(n69), .B(n67), .Y(n65) );
  NOR2X2 U149 ( .A(A[12]), .B(n126), .Y(n69) );
  NOR2X1 U150 ( .A(n22), .B(n20), .Y(n18) );
  OAI21X1 U151 ( .A0(n67), .A1(n70), .B0(n68), .Y(n66) );
  NAND2X1 U152 ( .A(A[1]), .B(n137), .Y(n109) );
  NOR2X1 U153 ( .A(n83), .B(n81), .Y(n79) );
  NAND2X1 U154 ( .A(A[6]), .B(n132), .Y(n93) );
  NOR2X2 U155 ( .A(n38), .B(n36), .Y(n34) );
  NOR2X1 U156 ( .A(n98), .B(n96), .Y(n94) );
  NAND2XL U157 ( .A(A[15]), .B(n123), .Y(n62) );
  NAND2XL U158 ( .A(A[7]), .B(n131), .Y(n91) );
  NOR2X1 U159 ( .A(A[20]), .B(n118), .Y(n38) );
  NAND2XL U160 ( .A(A[9]), .B(n129), .Y(n82) );
  NAND2XL U161 ( .A(A[13]), .B(n125), .Y(n68) );
  NAND2XL U162 ( .A(A[5]), .B(n133), .Y(n97) );
  NAND2XL U163 ( .A(A[25]), .B(n113), .Y(n21) );
  NAND2XL U164 ( .A(A[3]), .B(n135), .Y(n104) );
  NAND2XL U165 ( .A(A[14]), .B(n124), .Y(n64) );
  NAND2X2 U166 ( .A(A[10]), .B(n128), .Y(n78) );
  NAND2X2 U167 ( .A(A[19]), .B(n119), .Y(n45) );
  NAND2X2 U168 ( .A(A[18]), .B(n120), .Y(n47) );
  NOR2X1 U169 ( .A(n71), .B(n57), .Y(n55) );
  NOR2X1 U170 ( .A(n40), .B(n26), .Y(n24) );
  NAND2XL U171 ( .A(n48), .B(n42), .Y(n40) );
  NOR2XL U172 ( .A(n52), .B(n50), .Y(n48) );
  NOR2XL U173 ( .A(A[24]), .B(n114), .Y(n22) );
  NAND2XL U174 ( .A(A[27]), .B(n111), .Y(n15) );
  AOI21XL U175 ( .A0(n12), .A1(n19), .B0(n13), .Y(n11) );
  OAI21XL U176 ( .A0(n14), .A1(n17), .B0(n15), .Y(n13) );
  AOI21XL U177 ( .A0(n28), .A1(n35), .B0(n29), .Y(n27) );
  OAI21XL U178 ( .A0(n30), .A1(n33), .B0(n31), .Y(n29) );
  NAND2XL U179 ( .A(A[21]), .B(n117), .Y(n37) );
  NAND2XL U180 ( .A(A[11]), .B(n127), .Y(n76) );
  NOR2XL U181 ( .A(A[16]), .B(n122), .Y(n52) );
  NOR2XL U182 ( .A(A[2]), .B(n136), .Y(n105) );
  NAND2XL U183 ( .A(n79), .B(n73), .Y(n71) );
  NOR2XL U184 ( .A(A[8]), .B(n130), .Y(n83) );
  NAND2XL U185 ( .A(A[23]), .B(n115), .Y(n31) );
  NAND2XL U186 ( .A(A[26]), .B(n112), .Y(n17) );
  NOR2XL U187 ( .A(A[4]), .B(n134), .Y(n98) );
  INVXL U188 ( .A(B[10]), .Y(n128) );
  INVXL U189 ( .A(B[28]), .Y(n110) );
  OAI21X1 U190 ( .A0(n41), .A1(n26), .B0(n27), .Y(n25) );
  NOR2X2 U191 ( .A(n207), .B(A[29]), .Y(n6) );
  NAND2X2 U192 ( .A(n24), .B(n4), .Y(n2) );
  NOR2X2 U193 ( .A(n14), .B(n16), .Y(n12) );
  NOR2X2 U194 ( .A(A[26]), .B(n112), .Y(n16) );
  NOR2X2 U195 ( .A(n32), .B(n30), .Y(n28) );
  NOR2X2 U196 ( .A(A[22]), .B(n116), .Y(n32) );
  NOR2X2 U197 ( .A(n77), .B(n75), .Y(n73) );
  NOR2X2 U198 ( .A(A[10]), .B(n128), .Y(n77) );
  NOR2X2 U199 ( .A(A[21]), .B(n117), .Y(n36) );
  NOR2X2 U200 ( .A(A[23]), .B(n115), .Y(n30) );
  NOR2X2 U201 ( .A(n63), .B(n61), .Y(n59) );
  NOR2X2 U202 ( .A(A[14]), .B(n124), .Y(n63) );
  NOR2X2 U203 ( .A(n46), .B(n44), .Y(n42) );
  NOR2X2 U204 ( .A(A[18]), .B(n120), .Y(n46) );
  NOR2X2 U205 ( .A(n10), .B(n8), .Y(n4) );
  NAND2X2 U206 ( .A(n12), .B(n18), .Y(n10) );
  OAI21X1 U207 ( .A0(n50), .A1(n53), .B0(n51), .Y(n49) );
  NOR2X2 U208 ( .A(A[6]), .B(n132), .Y(n92) );
  NOR2X2 U209 ( .A(A[27]), .B(n111), .Y(n14) );
  NOR2X2 U210 ( .A(A[28]), .B(n110), .Y(n8) );
  NOR2X2 U211 ( .A(A[5]), .B(n133), .Y(n96) );
  NOR2X2 U212 ( .A(A[15]), .B(n123), .Y(n61) );
  NOR2X2 U213 ( .A(A[11]), .B(n127), .Y(n75) );
  NOR2X2 U214 ( .A(A[9]), .B(n129), .Y(n81) );
  NOR2X2 U215 ( .A(A[19]), .B(n119), .Y(n44) );
  NOR2X2 U216 ( .A(n105), .B(n103), .Y(n101) );
  AOI21X1 U217 ( .A0(n73), .A1(n80), .B0(n74), .Y(n72) );
  NOR2X2 U218 ( .A(A[13]), .B(n125), .Y(n67) );
  NOR2X2 U219 ( .A(A[25]), .B(n113), .Y(n20) );
  NOR2X2 U220 ( .A(A[7]), .B(n131), .Y(n90) );
  OAI21X1 U221 ( .A0(n36), .A1(n39), .B0(n37), .Y(n35) );
  NAND2X2 U222 ( .A(n34), .B(n28), .Y(n26) );
  NOR2X2 U223 ( .A(A[1]), .B(n137), .Y(n108) );
  NAND2X2 U224 ( .A(n65), .B(n59), .Y(n57) );
  NAND2X2 U225 ( .A(A[20]), .B(n118), .Y(n39) );
  OAI21X1 U226 ( .A0(n54), .A1(n2), .B0(n3), .Y(n1) );
  AND2X2 U227 ( .A(A[28]), .B(n110), .Y(n207) );
  INVX2 U228 ( .A(B[13]), .Y(n125) );
  INVX2 U229 ( .A(B[25]), .Y(n113) );
  INVX2 U230 ( .A(B[1]), .Y(n137) );
  INVX2 U231 ( .A(B[7]), .Y(n131) );
  INVX2 U232 ( .A(B[26]), .Y(n112) );
  INVX2 U233 ( .A(B[14]), .Y(n124) );
  INVX2 U234 ( .A(B[20]), .Y(n118) );
  INVX2 U235 ( .A(B[27]), .Y(n111) );
  INVX2 U236 ( .A(B[5]), .Y(n133) );
  INVX2 U237 ( .A(B[9]), .Y(n129) );
  INVX2 U238 ( .A(B[21]), .Y(n117) );
  INVX2 U239 ( .A(B[11]), .Y(n127) );
  INVX2 U240 ( .A(B[19]), .Y(n119) );
  INVX2 U241 ( .A(B[17]), .Y(n121) );
  INVX2 U242 ( .A(B[3]), .Y(n135) );
  INVX2 U243 ( .A(B[16]), .Y(n122) );
  INVX2 U244 ( .A(B[22]), .Y(n116) );
  INVX2 U245 ( .A(B[24]), .Y(n114) );
  INVX2 U246 ( .A(B[4]), .Y(n134) );
  INVX2 U247 ( .A(B[8]), .Y(n130) );
  INVX2 U248 ( .A(B[12]), .Y(n126) );
  OAI21X1 U249 ( .A0(n100), .A1(n86), .B0(n87), .Y(n85) );
  NAND2X2 U250 ( .A(n94), .B(n88), .Y(n86) );
  NOR2X2 U251 ( .A(n92), .B(n90), .Y(n88) );
  AOI21X1 U252 ( .A0(n42), .A1(n49), .B0(n43), .Y(n41) );
  NAND2X2 U253 ( .A(A[22]), .B(n116), .Y(n33) );
  AOI21X1 U254 ( .A0(n59), .A1(n66), .B0(n60), .Y(n58) );
  OAI21X1 U255 ( .A0(n81), .A1(n84), .B0(n82), .Y(n80) );
  AOI21X1 U256 ( .A0(n101), .A1(n107), .B0(n102), .Y(n100) );
  NAND2X2 U257 ( .A(A[2]), .B(n136), .Y(n106) );
  NOR2X2 U258 ( .A(A[3]), .B(n135), .Y(n103) );
  NAND2X2 U259 ( .A(A[16]), .B(n122), .Y(n53) );
  NOR2X2 U260 ( .A(A[17]), .B(n121), .Y(n50) );
  AOI21X1 U261 ( .A0(n25), .A1(n4), .B0(n5), .Y(n3) );
  NAND2X2 U262 ( .A(A[12]), .B(n126), .Y(n70) );
  AOI21X1 U263 ( .A0(n88), .A1(n95), .B0(n89), .Y(n87) );
  NAND2X2 U264 ( .A(A[24]), .B(n114), .Y(n23) );
  NAND2X2 U265 ( .A(A[4]), .B(n134), .Y(n99) );
  CLKINVX2 U266 ( .A(n1), .Y(DIFF[30]) );
  NAND2X2 U267 ( .A(A[8]), .B(n130), .Y(n84) );
  AOI21X1 U268 ( .A0(n85), .A1(n55), .B0(n56), .Y(n54) );
endmodule


module norm_v4_29_DW01_sub_42 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n222, n224, n225, n226,
         n228, n230, n231, n232, n233, n234, n235, n236, n237, n238, n239,
         n240, n241, n242, n243, n244, n245, n246, n247, n248, n249, n250,
         n251, n252, n253, n254, n255, n256, n257, n258, n259, n260, n261,
         n262, n263, n264, n265, n266, n267, n268, n269, n270, n271, n272,
         n273, n274, n275, n276, \B[0] ;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[11]), .Y(n266) );
  INVXL U311 ( .A(B[17]), .Y(n260) );
  INVXL U312 ( .A(B[15]), .Y(n262) );
  INVXL U313 ( .A(B[16]), .Y(n261) );
  INVXL U314 ( .A(B[24]), .Y(n253) );
  INVXL U315 ( .A(B[9]), .Y(n268) );
  INVXL U316 ( .A(B[18]), .Y(n259) );
  OAI21X1 U317 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  INVXL U318 ( .A(B[23]), .Y(n254) );
  INVXL U319 ( .A(B[6]), .Y(n271) );
  NOR2X1 U320 ( .A(A[2]), .B(n275), .Y(n215) );
  OAI21X2 U321 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  AOI21X1 U322 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  OAI21X1 U323 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U324 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  AOI21X1 U325 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  AOI21X1 U326 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  INVX2 U327 ( .A(n30), .Y(DIFF[30]) );
  INVX1 U328 ( .A(n188), .Y(n187) );
  NAND2XL U329 ( .A(n58), .B(n46), .Y(n44) );
  NAND2XL U330 ( .A(n115), .B(n101), .Y(n95) );
  NAND2XL U331 ( .A(n67), .B(n33), .Y(n31) );
  NOR2X1 U332 ( .A(n196), .B(n193), .Y(n191) );
  AOI21X1 U333 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X2 U334 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  NOR2XL U335 ( .A(n63), .B(n60), .Y(n58) );
  OAI21X2 U336 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  CLKNAND2X2 U337 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U338 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U339 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U340 ( .A(A[16]), .B(n261), .Y(n127) );
  CLKNAND2X2 U341 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U342 ( .A(A[8]), .B(n269), .Y(n186) );
  NAND2XL U343 ( .A(A[3]), .B(n274), .Y(n213) );
  CLKNAND2X2 U344 ( .A(A[20]), .B(n257), .Y(n93) );
  NAND2XL U345 ( .A(A[2]), .B(n275), .Y(n216) );
  NOR2X2 U346 ( .A(A[28]), .B(n249), .Y(n35) );
  NAND2X2 U347 ( .A(n180), .B(n168), .Y(n162) );
  CLKINVX2 U348 ( .A(n219), .Y(n248) );
  CLKNAND2X2 U349 ( .A(A[22]), .B(n255), .Y(n79) );
  NAND2X2 U350 ( .A(n83), .B(n71), .Y(n69) );
  OAI21X2 U351 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  NAND2XL U352 ( .A(n90), .B(n93), .Y(n10) );
  NOR2X2 U353 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U354 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U355 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U356 ( .A(A[17]), .B(n260), .Y(n121) );
  NAND2XL U357 ( .A(A[19]), .B(n258), .Y(n104) );
  AOI21X1 U358 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  INVXL U359 ( .A(n181), .Y(n179) );
  CLKINVX2 U360 ( .A(n180), .Y(n178) );
  INVXL U361 ( .A(n116), .Y(n114) );
  OAI21X1 U362 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  AOI21X1 U363 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21X1 U364 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NAND2X1 U365 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U366 ( .A(n235), .B(n146), .Y(n16) );
  NAND2BXL U367 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U368 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  OAI21XL U369 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U370 ( .A(n78), .B(n73), .Y(n71) );
  NOR2X2 U371 ( .A(n143), .B(n136), .Y(n134) );
  INVXL U372 ( .A(n149), .Y(n151) );
  NAND2XL U373 ( .A(n243), .B(n197), .Y(n24) );
  NOR2X2 U374 ( .A(A[14]), .B(n263), .Y(n143) );
  NAND2XL U375 ( .A(n248), .B(n220), .Y(n29) );
  AOI21X4 U376 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  NOR2XL U377 ( .A(n162), .B(n132), .Y(n130) );
  OAI21X2 U378 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  CLKNAND2X2 U379 ( .A(n148), .B(n134), .Y(n132) );
  NAND2BX1 U380 ( .AN(n95), .B(n83), .Y(n81) );
  OAI21XL U381 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  OAI21BX1 U382 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  AOI21XL U383 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2XL U384 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U385 ( .A(n162), .Y(n164) );
  INVXL U386 ( .A(n115), .Y(n113) );
  NOR2X1 U387 ( .A(n212), .B(n215), .Y(n210) );
  INVXL U388 ( .A(n185), .Y(n241) );
  XNOR2XL U389 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2BXL U390 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21XL U391 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  XNOR2XL U392 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  AOI21XL U393 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U394 ( .A(n244), .B(n202), .Y(n25) );
  NAND2XL U395 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U396 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U397 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2XL U398 ( .A(n238), .B(n171), .Y(n19) );
  XNOR2XL U399 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  XNOR2XL U400 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  AOI21XL U401 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2XL U402 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U403 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  XNOR2XL U404 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2XL U405 ( .A(n228), .B(n88), .Y(n9) );
  AOI21XL U406 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  XNOR2XL U407 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  NAND2XL U408 ( .A(n76), .B(n79), .Y(n8) );
  NAND2XL U409 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U410 ( .A(n63), .Y(n225) );
  INVXL U411 ( .A(n196), .Y(n243) );
  AOI21XL U412 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U413 ( .A(n232), .B(n122), .Y(n13) );
  NAND2XL U414 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U415 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  INVXL U416 ( .A(n215), .Y(n247) );
  NAND2XL U417 ( .A(n247), .B(n216), .Y(n28) );
  XNOR2XL U418 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  AOI2B1XL U419 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  OAI21X2 U420 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  INVXL U421 ( .A(n110), .Y(n231) );
  INVXL U422 ( .A(n175), .Y(n239) );
  INVXL U423 ( .A(n53), .Y(n51) );
  INVXL U424 ( .A(n159), .Y(n237) );
  INVXL U425 ( .A(n206), .Y(n245) );
  INVXL U426 ( .A(n78), .Y(n76) );
  INVXL U427 ( .A(n126), .Y(n233) );
  INVXL U428 ( .A(n92), .Y(n90) );
  INVXL U429 ( .A(n212), .Y(n246) );
  INVXL U430 ( .A(n48), .Y(n222) );
  INVXL U431 ( .A(n193), .Y(n242) );
  INVXL U432 ( .A(n73), .Y(n226) );
  INVXL U433 ( .A(n136), .Y(n234) );
  INVXL U434 ( .A(n60), .Y(n224) );
  INVXL U435 ( .A(n87), .Y(n228) );
  INVXL U436 ( .A(n103), .Y(n230) );
  AOI21BX1 U437 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U438 ( .A(A[11]), .B(n266), .Y(n170) );
  CLKNAND2X2 U439 ( .A(A[10]), .B(n267), .Y(n176) );
  CLKNAND2X2 U440 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U441 ( .A(A[6]), .B(n271), .Y(n197) );
  CLKNAND2X2 U442 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U443 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U444 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U445 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U446 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U447 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U448 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U449 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U450 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U451 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U452 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U453 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U454 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U455 ( .A(B[28]), .Y(n249) );
  INVXL U456 ( .A(B[10]), .Y(n267) );
  NOR2X2 U457 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U458 ( .A(n1), .Y(n128) );
  INVX2 U459 ( .A(n66), .Y(n65) );
  INVX2 U460 ( .A(n44), .Y(n42) );
  AOI21X1 U461 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  INVX2 U462 ( .A(n58), .Y(n56) );
  INVX2 U463 ( .A(n209), .Y(n208) );
  NAND2X2 U464 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U465 ( .A(n96), .Y(n98) );
  INVX2 U466 ( .A(n45), .Y(n43) );
  NOR2X2 U467 ( .A(n92), .B(n87), .Y(n83) );
  OAI21X1 U468 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X1 U469 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U470 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2X2 U471 ( .A(n159), .B(n154), .Y(n148) );
  NOR2X2 U472 ( .A(n53), .B(n48), .Y(n46) );
  NOR2X2 U473 ( .A(n110), .B(n103), .Y(n101) );
  OAI21X1 U474 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  NOR2X2 U475 ( .A(n126), .B(n121), .Y(n115) );
  OAI21X1 U476 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  OAI21X2 U477 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  NOR2X2 U478 ( .A(n175), .B(n170), .Y(n168) );
  AOI21X1 U479 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  NOR2X2 U480 ( .A(n206), .B(n201), .Y(n199) );
  NOR2X2 U481 ( .A(n185), .B(n182), .Y(n180) );
  NOR2X2 U482 ( .A(n44), .B(n35), .Y(n33) );
  NOR2X2 U483 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U484 ( .A(n237), .B(n160), .Y(n18) );
  NAND2X2 U485 ( .A(n233), .B(n127), .Y(n14) );
  NAND2X2 U486 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U487 ( .A(n245), .B(n207), .Y(n26) );
  AOI21X1 U488 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  OAI21X1 U489 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  NAND2X2 U490 ( .A(n224), .B(n61), .Y(n5) );
  XNOR2X1 U491 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  XNOR2X1 U492 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2X2 U493 ( .A(n239), .B(n176), .Y(n20) );
  NAND2X2 U494 ( .A(n234), .B(n137), .Y(n15) );
  NAND2X2 U495 ( .A(n246), .B(n213), .Y(n27) );
  NAND2X2 U496 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U497 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  NAND2X2 U498 ( .A(n222), .B(n49), .Y(n3) );
  AOI21X1 U499 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NAND2X2 U500 ( .A(n230), .B(n104), .Y(n11) );
  NAND2X2 U501 ( .A(n242), .B(n194), .Y(n23) );
  INVX2 U502 ( .A(n143), .Y(n235) );
  INVX2 U503 ( .A(n121), .Y(n232) );
  INVX2 U504 ( .A(n182), .Y(n240) );
  INVX2 U505 ( .A(n154), .Y(n236) );
  INVX2 U506 ( .A(n170), .Y(n238) );
  INVX2 U507 ( .A(n218), .Y(n217) );
  INVX2 U508 ( .A(n201), .Y(n244) );
  INVX2 U509 ( .A(n160), .Y(n158) );
  INVX2 U510 ( .A(n176), .Y(n174) );
  INVX2 U511 ( .A(n93), .Y(n91) );
  INVX2 U512 ( .A(n207), .Y(n205) );
  INVX2 U513 ( .A(n127), .Y(n125) );
  INVX2 U514 ( .A(n79), .Y(n77) );
  INVX2 U515 ( .A(n40), .Y(n38) );
  INVX2 U516 ( .A(n54), .Y(n52) );
  NOR2X2 U517 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U518 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U519 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U520 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U521 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U522 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U523 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U524 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U525 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U526 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U527 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U528 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U529 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U530 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U531 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U532 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U533 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U534 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U535 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U536 ( .A(A[7]), .B(n270), .Y(n193) );
  INVX2 U537 ( .A(B[1]), .Y(n276) );
  INVX2 U538 ( .A(B[7]), .Y(n270) );
  INVX2 U539 ( .A(B[13]), .Y(n264) );
  INVX2 U540 ( .A(B[3]), .Y(n274) );
  INVX2 U541 ( .A(B[5]), .Y(n272) );
  INVX2 U542 ( .A(B[21]), .Y(n256) );
  INVX2 U543 ( .A(B[12]), .Y(n265) );
  INVX2 U544 ( .A(B[8]), .Y(n269) );
  INVX2 U545 ( .A(B[4]), .Y(n273) );
  INVX2 U546 ( .A(B[20]), .Y(n257) );
  INVX2 U547 ( .A(B[25]), .Y(n252) );
  INVX2 U548 ( .A(B[19]), .Y(n258) );
  INVX2 U549 ( .A(B[14]), .Y(n263) );
  INVX2 U550 ( .A(B[27]), .Y(n250) );
  INVX2 U551 ( .A(B[22]), .Y(n255) );
  INVX2 U552 ( .A(B[26]), .Y(n251) );
  NAND2X1 U553 ( .A(A[14]), .B(n263), .Y(n146) );
  XNOR2X1 U554 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  XNOR2X1 U555 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  XNOR2X1 U556 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2X2 U557 ( .A(n199), .B(n191), .Y(n189) );
  AOI21X1 U558 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_43 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60,
         n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74,
         n75, n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n222, n224, n225, n226,
         n228, n230, n231, n232, n233, n234, n235, n236, n237, n238, n239,
         n240, n241, n242, n243, n244, n245, n246, n247, n248, n249, n250,
         n251, n252, n253, n254, n255, n256, n257, n258, n259, n260, n261,
         n262, n263, n264, n265, n266, n267, n268, n269, n270, n271, n272,
         n273, n274, n275, n276, \B[0] ;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U24 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U95 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[11]), .Y(n266) );
  INVXL U311 ( .A(B[17]), .Y(n260) );
  INVXL U312 ( .A(B[15]), .Y(n262) );
  INVXL U313 ( .A(B[16]), .Y(n261) );
  INVXL U314 ( .A(B[24]), .Y(n253) );
  INVXL U315 ( .A(B[9]), .Y(n268) );
  INVXL U316 ( .A(B[18]), .Y(n259) );
  INVXL U317 ( .A(B[23]), .Y(n254) );
  INVXL U318 ( .A(B[6]), .Y(n271) );
  OAI21X1 U319 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X1 U320 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  AOI21X1 U321 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  OAI21X1 U322 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U323 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  OAI21X1 U324 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  AOI21X1 U325 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  OAI21X1 U326 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  AOI21X1 U327 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  NOR2XL U328 ( .A(n95), .B(n69), .Y(n67) );
  NAND2XL U329 ( .A(n180), .B(n168), .Y(n162) );
  NOR2X1 U330 ( .A(n196), .B(n193), .Y(n191) );
  OAI21X2 U331 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  NOR2XL U332 ( .A(n126), .B(n121), .Y(n115) );
  NOR2XL U333 ( .A(n185), .B(n182), .Y(n180) );
  NOR2XL U334 ( .A(n159), .B(n154), .Y(n148) );
  NAND2X1 U335 ( .A(A[6]), .B(n271), .Y(n197) );
  NOR2XL U336 ( .A(A[4]), .B(n273), .Y(n206) );
  CLKNAND2X2 U337 ( .A(A[10]), .B(n267), .Y(n176) );
  CLKNAND2X2 U338 ( .A(A[20]), .B(n257), .Y(n93) );
  OAI21X2 U339 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NOR2X2 U340 ( .A(n53), .B(n48), .Y(n46) );
  INVXL U341 ( .A(n115), .Y(n113) );
  NAND2XL U342 ( .A(n115), .B(n231), .Y(n106) );
  NOR2X2 U343 ( .A(n92), .B(n87), .Y(n83) );
  NAND2XL U344 ( .A(n51), .B(n54), .Y(n4) );
  INVXL U345 ( .A(n92), .Y(n90) );
  CLKNAND2X2 U346 ( .A(A[12]), .B(n265), .Y(n160) );
  NAND2XL U347 ( .A(A[14]), .B(n263), .Y(n146) );
  NAND2XL U348 ( .A(A[11]), .B(n266), .Y(n171) );
  INVX2 U349 ( .A(n66), .Y(n65) );
  NAND2BXL U350 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U351 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  NAND2XL U352 ( .A(n222), .B(n49), .Y(n3) );
  NOR2X2 U353 ( .A(n143), .B(n136), .Y(n134) );
  NOR2X2 U354 ( .A(n78), .B(n73), .Y(n71) );
  INVXL U355 ( .A(n149), .Y(n151) );
  NAND2XL U356 ( .A(n224), .B(n61), .Y(n5) );
  NAND2XL U357 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X1 U358 ( .A(n240), .B(n183), .Y(n21) );
  NAND2XL U359 ( .A(n242), .B(n194), .Y(n23) );
  NAND2XL U360 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U361 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2XL U362 ( .A(n234), .B(n137), .Y(n15) );
  NAND2XL U363 ( .A(n230), .B(n104), .Y(n11) );
  NAND2XL U364 ( .A(n246), .B(n213), .Y(n27) );
  NAND2XL U365 ( .A(n76), .B(n79), .Y(n8) );
  NAND2XL U366 ( .A(n235), .B(n146), .Y(n16) );
  NAND2XL U367 ( .A(n243), .B(n197), .Y(n24) );
  CLKNAND2X2 U368 ( .A(A[22]), .B(n255), .Y(n79) );
  NOR2X2 U369 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U370 ( .A(A[11]), .B(n266), .Y(n170) );
  INVXL U371 ( .A(n44), .Y(n42) );
  AOI21X4 U372 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  OAI21X2 U373 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  OAI21XL U374 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  NAND2BX1 U375 ( .AN(n95), .B(n83), .Y(n81) );
  AOI21XL U376 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  INVXL U377 ( .A(n162), .Y(n164) );
  INVXL U378 ( .A(n45), .Y(n43) );
  NOR2XL U379 ( .A(n212), .B(n215), .Y(n210) );
  AOI21XL U380 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  XNOR2XL U381 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U382 ( .A(n245), .B(n207), .Y(n26) );
  INVXL U383 ( .A(n185), .Y(n241) );
  XNOR2XL U384 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NAND2XL U385 ( .A(n233), .B(n127), .Y(n14) );
  NOR2XL U386 ( .A(n63), .B(n60), .Y(n58) );
  AOI21XL U387 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U388 ( .A(n244), .B(n202), .Y(n25) );
  AOI21XL U389 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U390 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U391 ( .A(n63), .Y(n225) );
  INVXL U392 ( .A(n196), .Y(n243) );
  NAND2XL U393 ( .A(n231), .B(n111), .Y(n12) );
  INVXL U394 ( .A(n215), .Y(n247) );
  NAND2XL U395 ( .A(n247), .B(n216), .Y(n28) );
  AOI2B1XL U396 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  AOI21XL U397 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2XL U398 ( .A(n236), .B(n155), .Y(n17) );
  INVXL U399 ( .A(n110), .Y(n231) );
  INVXL U400 ( .A(n218), .Y(n217) );
  INVXL U401 ( .A(n53), .Y(n51) );
  INVXL U402 ( .A(n175), .Y(n239) );
  INVXL U403 ( .A(n159), .Y(n237) );
  INVXL U404 ( .A(n78), .Y(n76) );
  INVXL U405 ( .A(n212), .Y(n246) );
  INVXL U406 ( .A(n48), .Y(n222) );
  INVXL U407 ( .A(n193), .Y(n242) );
  INVXL U408 ( .A(n201), .Y(n244) );
  INVXL U409 ( .A(n73), .Y(n226) );
  INVXL U410 ( .A(n60), .Y(n224) );
  INVXL U411 ( .A(n136), .Y(n234) );
  INVXL U412 ( .A(n154), .Y(n236) );
  INVXL U413 ( .A(n87), .Y(n228) );
  INVXL U414 ( .A(n103), .Y(n230) );
  INVXL U415 ( .A(n121), .Y(n232) );
  INVXL U416 ( .A(n182), .Y(n240) );
  AOI21BX1 U417 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  INVXL U418 ( .A(n207), .Y(n205) );
  INVXL U419 ( .A(n127), .Y(n125) );
  INVXL U420 ( .A(n219), .Y(n248) );
  NOR2XL U421 ( .A(A[16]), .B(n261), .Y(n126) );
  CLKNAND2X2 U422 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U423 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U424 ( .A(A[24]), .B(n253), .Y(n64) );
  CLKNAND2X2 U425 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U426 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U427 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U428 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U429 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U430 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U431 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U432 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U433 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U434 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U435 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U436 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U437 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2X1 U438 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U439 ( .A(B[28]), .Y(n249) );
  INVXL U440 ( .A(B[10]), .Y(n267) );
  INVX2 U441 ( .A(n1), .Y(n128) );
  INVX2 U442 ( .A(n181), .Y(n179) );
  INVX2 U443 ( .A(n180), .Y(n178) );
  AOI21X1 U444 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  OAI21X1 U445 ( .A0(n66), .A1(n56), .B0(n57), .Y(n55) );
  INVX2 U446 ( .A(n59), .Y(n57) );
  INVX2 U447 ( .A(n58), .Y(n56) );
  NOR2X2 U448 ( .A(n162), .B(n132), .Y(n130) );
  NAND2X2 U449 ( .A(n148), .B(n134), .Y(n132) );
  AOI21X1 U450 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  NAND2X2 U451 ( .A(n58), .B(n46), .Y(n44) );
  NAND2X2 U452 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U453 ( .A(n83), .B(n71), .Y(n69) );
  INVX2 U454 ( .A(n188), .Y(n187) );
  INVX2 U455 ( .A(n209), .Y(n208) );
  NAND2X2 U456 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U457 ( .A(n96), .Y(n98) );
  INVX2 U458 ( .A(n116), .Y(n114) );
  NOR2X2 U459 ( .A(n175), .B(n170), .Y(n168) );
  AOI21X1 U460 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  NOR2BX1 U461 ( .AN(n148), .B(n143), .Y(n141) );
  NOR2X2 U462 ( .A(n110), .B(n103), .Y(n101) );
  OAI21X1 U463 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  AOI21X1 U464 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U465 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  OAI21X1 U466 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  AOI21X1 U467 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  XNOR2X1 U468 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  XNOR2X1 U469 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2X2 U470 ( .A(n237), .B(n160), .Y(n18) );
  XNOR2X1 U471 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2X2 U472 ( .A(n90), .B(n93), .Y(n10) );
  AOI21X1 U473 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  XNOR2X1 U474 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2X2 U475 ( .A(n228), .B(n88), .Y(n9) );
  AOI21X1 U476 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  XNOR2X1 U477 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  XNOR2X1 U478 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  XNOR2X1 U479 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2X2 U480 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2X1 U481 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  XNOR2X1 U482 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  XNOR2X1 U483 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  XNOR2X1 U484 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  XNOR2X1 U485 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  NAND2X2 U486 ( .A(n232), .B(n122), .Y(n13) );
  AOI21X1 U487 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2X2 U488 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U489 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  INVX2 U490 ( .A(n30), .Y(DIFF[30]) );
  INVX2 U491 ( .A(n126), .Y(n233) );
  INVX2 U492 ( .A(n143), .Y(n235) );
  INVX2 U493 ( .A(n206), .Y(n245) );
  INVX2 U494 ( .A(n170), .Y(n238) );
  INVX2 U495 ( .A(n93), .Y(n91) );
  INVX2 U496 ( .A(n160), .Y(n158) );
  INVX2 U497 ( .A(n176), .Y(n174) );
  INVX2 U498 ( .A(n54), .Y(n52) );
  INVX2 U499 ( .A(n79), .Y(n77) );
  INVX2 U500 ( .A(n40), .Y(n38) );
  NOR2X2 U501 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U502 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U503 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U504 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U505 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U506 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U507 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U508 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U509 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U510 ( .A(A[6]), .B(n271), .Y(n196) );
  OAI21X1 U511 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NOR2X2 U512 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U513 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U514 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U515 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U516 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U517 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U518 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U519 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U520 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U521 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U522 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U523 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U524 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U525 ( .A(A[27]), .B(n250), .Y(n48) );
  OAI21X1 U526 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U527 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U528 ( .A(A[4]), .B(n273), .Y(n207) );
  NAND2X2 U529 ( .A(A[18]), .B(n259), .Y(n111) );
  NAND2X2 U530 ( .A(A[16]), .B(n261), .Y(n127) );
  NAND2X2 U531 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2X2 U532 ( .A(n248), .B(n220), .Y(n29) );
  INVX2 U533 ( .A(B[13]), .Y(n264) );
  INVX2 U534 ( .A(B[27]), .Y(n250) );
  INVX2 U535 ( .A(B[21]), .Y(n256) );
  INVX2 U536 ( .A(B[25]), .Y(n252) );
  INVX2 U537 ( .A(B[26]), .Y(n251) );
  INVX2 U538 ( .A(B[3]), .Y(n274) );
  INVX2 U539 ( .A(B[1]), .Y(n276) );
  INVX2 U540 ( .A(B[20]), .Y(n257) );
  INVX2 U541 ( .A(B[12]), .Y(n265) );
  INVX2 U542 ( .A(B[22]), .Y(n255) );
  INVX2 U543 ( .A(B[7]), .Y(n270) );
  INVX2 U544 ( .A(B[4]), .Y(n273) );
  INVX2 U545 ( .A(B[14]), .Y(n263) );
  INVX2 U546 ( .A(B[8]), .Y(n269) );
  INVX2 U547 ( .A(B[5]), .Y(n272) );
  INVX2 U548 ( .A(B[19]), .Y(n258) );
  NOR2X2 U549 ( .A(n206), .B(n201), .Y(n199) );
  NAND2X2 U550 ( .A(n199), .B(n191), .Y(n189) );
  XNOR2XL U551 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NOR2X2 U552 ( .A(n44), .B(n35), .Y(n33) );
  NAND2X2 U553 ( .A(n67), .B(n33), .Y(n31) );
  OAI21X2 U554 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  AOI21X1 U555 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_46 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n97, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n222, n224, n225, n226,
         n228, n230, n231, n232, n233, n234, n235, n236, n237, n238, n239,
         n240, n241, n242, n243, n244, n245, n246, n247, n248, n249, n250,
         n251, n252, n253, n254, n255, n256, n257, n258, n259, n260, n261,
         n262, n263, n264, n265, n266, n267, n268, n269, n270, n271, n272,
         n273, n274, n275, n276, \B[0] , n374, n375;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U3 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U57 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U81 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  OAI21X1 U95 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[11]), .Y(n266) );
  INVXL U311 ( .A(B[17]), .Y(n260) );
  INVXL U312 ( .A(B[15]), .Y(n262) );
  INVXL U313 ( .A(B[16]), .Y(n261) );
  INVXL U314 ( .A(B[24]), .Y(n253) );
  INVXL U315 ( .A(B[9]), .Y(n268) );
  INVXL U316 ( .A(B[18]), .Y(n259) );
  INVXL U317 ( .A(B[23]), .Y(n254) );
  INVXL U318 ( .A(B[6]), .Y(n271) );
  OAI21X1 U319 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  OAI21BX1 U320 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  AOI21X1 U321 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  AOI21X1 U322 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  AOI21X1 U323 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  AOI21X1 U324 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  AOI21X1 U325 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  XNOR2XL U326 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  CLKNAND2X2 U327 ( .A(n128), .B(n67), .Y(n374) );
  AND2X4 U328 ( .A(n374), .B(n375), .Y(n66) );
  NAND2X1 U329 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2XL U330 ( .A(A[1]), .B(n276), .Y(n220) );
  CLKNAND2X2 U331 ( .A(A[2]), .B(n275), .Y(n216) );
  CLKNAND2X2 U332 ( .A(n180), .B(n168), .Y(n162) );
  NOR2X1 U333 ( .A(n159), .B(n154), .Y(n148) );
  INVXL U334 ( .A(n180), .Y(n178) );
  NOR2X2 U335 ( .A(n196), .B(n193), .Y(n191) );
  NAND2X2 U336 ( .A(n199), .B(n191), .Y(n189) );
  XNOR2XL U337 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2X2 U338 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U339 ( .A(n66), .Y(n65) );
  INVXL U340 ( .A(n68), .Y(n375) );
  INVXL U341 ( .A(n1), .Y(n128) );
  NOR2XL U342 ( .A(n212), .B(n215), .Y(n210) );
  CLKNAND2X2 U343 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U344 ( .A(A[18]), .B(n259), .Y(n111) );
  XNOR2X1 U345 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  NOR2X1 U346 ( .A(n110), .B(n103), .Y(n101) );
  NAND2BXL U347 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U348 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  NAND2X1 U349 ( .A(A[6]), .B(n271), .Y(n197) );
  NOR2X2 U350 ( .A(A[11]), .B(n266), .Y(n170) );
  NAND2XL U351 ( .A(A[14]), .B(n263), .Y(n146) );
  INVXL U352 ( .A(n181), .Y(n179) );
  NAND2X2 U353 ( .A(n115), .B(n101), .Y(n95) );
  INVX2 U354 ( .A(n159), .Y(n237) );
  NAND2X2 U355 ( .A(n83), .B(n71), .Y(n69) );
  OAI21X1 U356 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  OAI21X1 U357 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  NOR2X2 U358 ( .A(n206), .B(n201), .Y(n199) );
  NOR2X2 U359 ( .A(n143), .B(n136), .Y(n134) );
  OAI21X1 U360 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  NOR2X2 U361 ( .A(n78), .B(n73), .Y(n71) );
  NOR2X2 U362 ( .A(n53), .B(n48), .Y(n46) );
  INVXL U363 ( .A(n149), .Y(n151) );
  NAND2XL U364 ( .A(n90), .B(n93), .Y(n10) );
  INVXL U365 ( .A(n185), .Y(n241) );
  NAND2X2 U366 ( .A(A[12]), .B(n265), .Y(n160) );
  NOR2X2 U367 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U368 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X1 U369 ( .A(A[28]), .B(n249), .Y(n35) );
  NAND2X2 U370 ( .A(A[16]), .B(n261), .Y(n127) );
  INVXL U371 ( .A(n44), .Y(n42) );
  AOI21X4 U372 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  OAI21X2 U373 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  AOI2B1XL U374 ( .A1N(n96), .A0(n83), .B0(n86), .Y(n82) );
  CLKINVX2 U375 ( .A(n30), .Y(DIFF[30]) );
  INVXL U376 ( .A(n188), .Y(n187) );
  NAND2XL U377 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U378 ( .A(n116), .Y(n114) );
  INVXL U379 ( .A(n162), .Y(n164) );
  NAND2XL U380 ( .A(n67), .B(n33), .Y(n31) );
  INVXL U381 ( .A(n115), .Y(n113) );
  OAI21XL U382 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  OAI21X2 U383 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  AOI21XL U384 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NOR2XL U385 ( .A(n63), .B(n60), .Y(n58) );
  XNOR2XL U386 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  AOI21XL U387 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U388 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U389 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  NAND2XL U390 ( .A(n238), .B(n171), .Y(n19) );
  XNOR2XL U391 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U392 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U393 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2XL U394 ( .A(n228), .B(n88), .Y(n9) );
  XNOR2XL U395 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U396 ( .A(n245), .B(n207), .Y(n26) );
  XNOR2XL U397 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U398 ( .A(n76), .B(n79), .Y(n8) );
  XNOR2XL U399 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  XNOR2XL U400 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  AOI21XL U401 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U402 ( .A(n235), .B(n146), .Y(n16) );
  NAND2XL U403 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U404 ( .A(n63), .Y(n225) );
  INVXL U405 ( .A(n196), .Y(n243) );
  NAND2XL U406 ( .A(n243), .B(n197), .Y(n24) );
  AOI21XL U407 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U408 ( .A(n232), .B(n122), .Y(n13) );
  XNOR2XL U409 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U410 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U411 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  INVXL U412 ( .A(n215), .Y(n247) );
  NAND2XL U413 ( .A(n247), .B(n216), .Y(n28) );
  AOI2B1XL U414 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  OAI21X2 U415 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  INVXL U416 ( .A(n110), .Y(n231) );
  INVXL U417 ( .A(n175), .Y(n239) );
  INVXL U418 ( .A(n53), .Y(n51) );
  INVXL U419 ( .A(n206), .Y(n245) );
  INVXL U420 ( .A(n78), .Y(n76) );
  INVXL U421 ( .A(n126), .Y(n233) );
  INVXL U422 ( .A(n212), .Y(n246) );
  INVXL U423 ( .A(n48), .Y(n222) );
  INVXL U424 ( .A(n201), .Y(n244) );
  INVXL U425 ( .A(n73), .Y(n226) );
  INVXL U426 ( .A(n136), .Y(n234) );
  INVXL U427 ( .A(n60), .Y(n224) );
  INVXL U428 ( .A(n154), .Y(n236) );
  INVXL U429 ( .A(n103), .Y(n230) );
  INVXL U430 ( .A(n193), .Y(n242) );
  INVXL U431 ( .A(n93), .Y(n91) );
  AOI21BX1 U432 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U433 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U434 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U435 ( .A(A[21]), .B(n256), .Y(n87) );
  NAND2XL U436 ( .A(n248), .B(n220), .Y(n29) );
  CLKNAND2X2 U437 ( .A(A[22]), .B(n255), .Y(n79) );
  CLKNAND2X2 U438 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U439 ( .A(A[10]), .B(n267), .Y(n176) );
  CLKNAND2X2 U440 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U441 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U442 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U443 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U444 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U445 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U446 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U447 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U448 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U449 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U450 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U451 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U452 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U453 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U454 ( .A(A[7]), .B(n270), .Y(n194) );
  INVXL U455 ( .A(B[28]), .Y(n249) );
  INVXL U456 ( .A(B[10]), .Y(n267) );
  INVX2 U457 ( .A(n95), .Y(n97) );
  NAND2X2 U458 ( .A(n97), .B(n83), .Y(n81) );
  OAI21X1 U459 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  NOR2X2 U460 ( .A(n162), .B(n132), .Y(n130) );
  NAND2X2 U461 ( .A(n148), .B(n134), .Y(n132) );
  INVX2 U462 ( .A(n58), .Y(n56) );
  NAND2X2 U463 ( .A(n58), .B(n46), .Y(n44) );
  INVX2 U464 ( .A(n209), .Y(n208) );
  AOI21X1 U465 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U466 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U467 ( .A(n45), .Y(n43) );
  AOI21X1 U468 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  NOR2X2 U469 ( .A(n126), .B(n121), .Y(n115) );
  OAI21X1 U470 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  NOR2X2 U471 ( .A(n92), .B(n87), .Y(n83) );
  NOR2X2 U472 ( .A(n185), .B(n182), .Y(n180) );
  OAI21X1 U473 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X1 U474 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2BX1 U475 ( .AN(n148), .B(n143), .Y(n141) );
  OAI21X1 U476 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NOR2X2 U477 ( .A(n175), .B(n170), .Y(n168) );
  OAI21X2 U478 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  AOI21X1 U479 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  OAI21X1 U480 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  NOR2X2 U481 ( .A(n38), .B(A[29]), .Y(n36) );
  NOR2X2 U482 ( .A(n44), .B(n35), .Y(n33) );
  XNOR2X1 U483 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2X2 U484 ( .A(n233), .B(n127), .Y(n14) );
  AOI21X1 U485 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  XNOR2X1 U486 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2X2 U487 ( .A(n237), .B(n160), .Y(n18) );
  NAND2X2 U488 ( .A(n51), .B(n54), .Y(n4) );
  NAND2X2 U489 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U490 ( .A(n230), .B(n104), .Y(n11) );
  NAND2X2 U491 ( .A(n224), .B(n61), .Y(n5) );
  NAND2X2 U492 ( .A(n246), .B(n213), .Y(n27) );
  NAND2X2 U493 ( .A(n222), .B(n49), .Y(n3) );
  NAND2X2 U494 ( .A(n244), .B(n202), .Y(n25) );
  NAND2X2 U495 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U496 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  NAND2X2 U497 ( .A(n236), .B(n155), .Y(n17) );
  NAND2X2 U498 ( .A(n234), .B(n137), .Y(n15) );
  AOI21X1 U499 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NAND2X2 U500 ( .A(n242), .B(n194), .Y(n23) );
  AOI21X1 U501 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  INVX2 U502 ( .A(n92), .Y(n90) );
  INVX2 U503 ( .A(n143), .Y(n235) );
  INVX2 U504 ( .A(n54), .Y(n52) );
  INVX2 U505 ( .A(n170), .Y(n238) );
  INVX2 U506 ( .A(n182), .Y(n240) );
  INVX2 U507 ( .A(n121), .Y(n232) );
  INVX2 U508 ( .A(n219), .Y(n248) );
  INVX2 U509 ( .A(n87), .Y(n228) );
  INVX2 U510 ( .A(n218), .Y(n217) );
  INVX2 U511 ( .A(n127), .Y(n125) );
  INVX2 U512 ( .A(n207), .Y(n205) );
  INVX2 U513 ( .A(n176), .Y(n174) );
  INVX2 U514 ( .A(n160), .Y(n158) );
  INVX2 U515 ( .A(n79), .Y(n77) );
  INVX2 U516 ( .A(n40), .Y(n38) );
  NOR2X2 U517 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U518 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U519 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U520 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U521 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U522 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U523 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U524 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U525 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U526 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U527 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U528 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U529 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U530 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U531 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U532 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U533 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U534 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U535 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U536 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U537 ( .A(A[1]), .B(n276), .Y(n219) );
  CLKNAND2X2 U538 ( .A(A[20]), .B(n257), .Y(n93) );
  INVX2 U539 ( .A(B[1]), .Y(n276) );
  INVX2 U540 ( .A(B[13]), .Y(n264) );
  INVX2 U541 ( .A(B[5]), .Y(n272) );
  INVX2 U542 ( .A(B[21]), .Y(n256) );
  INVX2 U543 ( .A(B[12]), .Y(n265) );
  INVX2 U544 ( .A(B[27]), .Y(n250) );
  INVX2 U545 ( .A(B[25]), .Y(n252) );
  INVX2 U546 ( .A(B[4]), .Y(n273) );
  INVX2 U547 ( .A(B[3]), .Y(n274) );
  INVX2 U548 ( .A(B[7]), .Y(n270) );
  INVX2 U549 ( .A(B[22]), .Y(n255) );
  INVX2 U550 ( .A(B[20]), .Y(n257) );
  INVX2 U551 ( .A(B[14]), .Y(n263) );
  INVX2 U552 ( .A(B[19]), .Y(n258) );
  INVX2 U553 ( .A(B[26]), .Y(n251) );
  INVX2 U554 ( .A(B[8]), .Y(n269) );
  OAI21XL U555 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  AOI21X1 U556 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_33 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n31,
         n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46, n47,
         n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76,
         n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91, n92,
         n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106, n107,
         n110, n111, n112, n113, n114, n115, n116, n121, n122, n123, n125,
         n126, n127, n128, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n139, n140, n141, n142, n143, n146, n147, n148, n149, n151,
         n154, n155, n156, n158, n159, n160, n161, n162, n163, n164, n168,
         n169, n170, n171, n172, n174, n175, n176, n177, n178, n180, n181,
         n182, n183, n184, n185, n186, n187, n188, n189, n190, n191, n192,
         n193, n194, n195, n196, n197, n198, n199, n200, n201, n202, n203,
         n205, n206, n207, n208, n209, n210, n211, n212, n213, n214, n215,
         n216, n217, n218, n219, n220, n222, n224, n225, n226, n228, n230,
         n231, n232, n233, n234, n235, n236, n237, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n252,
         n253, n254, n255, n256, n257, n258, n259, n260, n261, n262, n263,
         n264, n265, n266, n267, n268, n269, n270, n271, n272, n273, n274,
         n275, n276, \B[0] , n374, n375, n377;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U103 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  OAI21X2 U309 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  INVXL U310 ( .A(B[2]), .Y(n275) );
  INVXL U311 ( .A(B[15]), .Y(n262) );
  INVXL U312 ( .A(B[18]), .Y(n259) );
  BUFX2 U313 ( .A(n161), .Y(n374) );
  AOI21X3 U314 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  OAI21X3 U315 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  CLKINVX12 U316 ( .A(n377), .Y(n375) );
  INVX18 U317 ( .A(n375), .Y(DIFF[30]) );
  INVXL U318 ( .A(B[23]), .Y(n254) );
  INVXL U319 ( .A(B[6]), .Y(n271) );
  OAI21X1 U320 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  OAI21X1 U321 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  AOI21X4 U322 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  INVXL U323 ( .A(n116), .Y(n114) );
  AOI21BXL U324 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  OAI21X2 U325 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  NAND2XL U326 ( .A(A[1]), .B(n276), .Y(n220) );
  OA21X4 U327 ( .A0(n1), .A1(n31), .B0(n32), .Y(n377) );
  NAND2X2 U328 ( .A(n67), .B(n33), .Y(n31) );
  NOR2X1 U329 ( .A(n159), .B(n154), .Y(n148) );
  OAI21X2 U330 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  NOR2XL U331 ( .A(n206), .B(n201), .Y(n199) );
  NOR2X2 U332 ( .A(n78), .B(n73), .Y(n71) );
  OAI21BXL U333 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  NOR2XL U334 ( .A(n126), .B(n121), .Y(n115) );
  NOR2XL U335 ( .A(n63), .B(n60), .Y(n58) );
  CLKNAND2X2 U336 ( .A(A[10]), .B(n267), .Y(n176) );
  NAND2XL U337 ( .A(n248), .B(n220), .Y(n29) );
  NAND2X1 U338 ( .A(n237), .B(n160), .Y(n18) );
  AOI21XL U339 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  NAND2XL U340 ( .A(n180), .B(n168), .Y(n162) );
  INVX2 U341 ( .A(n159), .Y(n237) );
  AOI21XL U342 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  AOI21XL U343 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  AOI21XL U344 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  AOI21X1 U345 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  NAND2XL U346 ( .A(n76), .B(n79), .Y(n8) );
  INVXL U347 ( .A(n149), .Y(n151) );
  OAI21X1 U348 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  NAND2BXL U349 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U350 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  NAND2XL U351 ( .A(A[12]), .B(n265), .Y(n160) );
  OAI21X1 U352 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  INVXL U353 ( .A(n44), .Y(n42) );
  NOR2XL U354 ( .A(n162), .B(n132), .Y(n130) );
  NAND2XL U355 ( .A(n148), .B(n134), .Y(n132) );
  OAI21XL U356 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  OAI21XL U357 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  NAND2BX1 U358 ( .AN(n95), .B(n83), .Y(n81) );
  OAI21BXL U359 ( .A0(n187), .A1(n178), .B0N(n181), .Y(n177) );
  INVXL U360 ( .A(n162), .Y(n164) );
  NOR2XL U361 ( .A(n212), .B(n215), .Y(n210) );
  NOR2XL U362 ( .A(n92), .B(n87), .Y(n83) );
  XNOR2XL U363 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2BXL U364 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U365 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21XL U366 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NOR2X1 U367 ( .A(n175), .B(n170), .Y(n168) );
  NOR2X1 U368 ( .A(n110), .B(n103), .Y(n101) );
  NOR2X1 U369 ( .A(n53), .B(n48), .Y(n46) );
  XNOR2XL U370 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U371 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U372 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U373 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U374 ( .A(n244), .B(n202), .Y(n25) );
  XNOR2XL U375 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2XL U376 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U377 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U378 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U379 ( .A(n374), .B(n18), .Y(DIFF[12]) );
  OAI21XL U380 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  AOI21XL U381 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U382 ( .A(n232), .B(n122), .Y(n13) );
  XNOR2XL U383 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  XNOR2XL U384 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U385 ( .A(n51), .B(n54), .Y(n4) );
  AOI21XL U386 ( .A0(n374), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U387 ( .A(n235), .B(n146), .Y(n16) );
  INVXL U388 ( .A(n185), .Y(n241) );
  NAND2XL U389 ( .A(n241), .B(n186), .Y(n22) );
  NAND2XL U390 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U391 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  INVXL U392 ( .A(n196), .Y(n243) );
  NAND2XL U393 ( .A(n243), .B(n197), .Y(n24) );
  NAND2XL U394 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U395 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  XNOR2XL U396 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U397 ( .A(n245), .B(n207), .Y(n26) );
  XNOR2XL U398 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U399 ( .A(n90), .B(n93), .Y(n10) );
  NAND2XL U400 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U401 ( .A(n63), .Y(n225) );
  INVXL U402 ( .A(n215), .Y(n247) );
  NAND2XL U403 ( .A(n247), .B(n216), .Y(n28) );
  NAND2XL U404 ( .A(n199), .B(n191), .Y(n189) );
  NOR2X1 U405 ( .A(n196), .B(n193), .Y(n191) );
  AOI2B1XL U406 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  AOI21X1 U407 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  INVXL U408 ( .A(n110), .Y(n231) );
  INVXL U409 ( .A(n143), .Y(n235) );
  INVXL U410 ( .A(n175), .Y(n239) );
  INVXL U411 ( .A(n53), .Y(n51) );
  INVXL U412 ( .A(n206), .Y(n245) );
  INVXL U413 ( .A(n126), .Y(n233) );
  INVXL U414 ( .A(n92), .Y(n90) );
  INVXL U415 ( .A(n78), .Y(n76) );
  INVXL U416 ( .A(n212), .Y(n246) );
  INVXL U417 ( .A(n170), .Y(n238) );
  INVXL U418 ( .A(n48), .Y(n222) );
  INVXL U419 ( .A(n193), .Y(n242) );
  INVXL U420 ( .A(n201), .Y(n244) );
  INVXL U421 ( .A(n136), .Y(n234) );
  INVXL U422 ( .A(n154), .Y(n236) );
  INVXL U423 ( .A(n73), .Y(n226) );
  INVXL U424 ( .A(n103), .Y(n230) );
  INVXL U425 ( .A(n121), .Y(n232) );
  INVXL U426 ( .A(n60), .Y(n224) );
  INVXL U427 ( .A(n87), .Y(n228) );
  INVXL U428 ( .A(n79), .Y(n77) );
  NOR2X2 U429 ( .A(A[9]), .B(n268), .Y(n182) );
  CLKNAND2X2 U430 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U431 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U432 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U433 ( .A(A[16]), .B(n261), .Y(n127) );
  CLKNAND2X2 U434 ( .A(A[8]), .B(n269), .Y(n186) );
  NAND2XL U435 ( .A(A[14]), .B(n263), .Y(n146) );
  CLKNAND2X2 U436 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U437 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2X1 U438 ( .A(A[6]), .B(n271), .Y(n197) );
  NAND2X1 U439 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U440 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U441 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U442 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U443 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U444 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U445 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U446 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U447 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U448 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U449 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U450 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U451 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U452 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U453 ( .A(A[19]), .B(n258), .Y(n104) );
  INVXL U454 ( .A(B[28]), .Y(n249) );
  INVXL U455 ( .A(B[10]), .Y(n267) );
  NOR2X2 U456 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U457 ( .A(n1), .Y(n128) );
  INVX2 U458 ( .A(n66), .Y(n65) );
  AOI21X2 U459 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  INVX2 U460 ( .A(n180), .Y(n178) );
  INVX2 U461 ( .A(n58), .Y(n56) );
  NAND2X2 U462 ( .A(n115), .B(n101), .Y(n95) );
  AOI21X1 U463 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U464 ( .A(n58), .B(n46), .Y(n44) );
  NAND2X2 U465 ( .A(n83), .B(n71), .Y(n69) );
  INVX2 U466 ( .A(n188), .Y(n187) );
  NAND2X2 U467 ( .A(n115), .B(n231), .Y(n106) );
  INVX2 U468 ( .A(n209), .Y(n208) );
  INVX2 U469 ( .A(n115), .Y(n113) );
  NAND2X2 U470 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U471 ( .A(n96), .Y(n98) );
  INVX2 U472 ( .A(n45), .Y(n43) );
  AOI21X1 U473 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  OAI21X1 U474 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U475 ( .A(n185), .B(n182), .Y(n180) );
  OAI21X1 U476 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  OAI21X1 U477 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  AOI21X2 U478 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  OAI21X1 U479 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2X2 U480 ( .A(n44), .B(n35), .Y(n33) );
  AOI21X1 U481 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  NOR2X2 U482 ( .A(n143), .B(n136), .Y(n134) );
  NOR2X2 U483 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U484 ( .A(n228), .B(n88), .Y(n9) );
  XNOR2X1 U485 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2X2 U486 ( .A(n233), .B(n127), .Y(n14) );
  NAND2X2 U487 ( .A(n234), .B(n137), .Y(n15) );
  NAND2X2 U488 ( .A(n230), .B(n104), .Y(n11) );
  AOI21X1 U489 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  OAI21X1 U490 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  NAND2X2 U491 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U492 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U493 ( .A0(n374), .A1(n237), .B0(n158), .Y(n156) );
  NAND2X2 U494 ( .A(n222), .B(n49), .Y(n3) );
  XOR2X1 U495 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  NAND2X2 U496 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U497 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  NAND2X2 U498 ( .A(n224), .B(n61), .Y(n5) );
  INVX2 U499 ( .A(n182), .Y(n240) );
  INVX2 U500 ( .A(n218), .Y(n217) );
  INVX2 U501 ( .A(n219), .Y(n248) );
  INVX2 U502 ( .A(n127), .Y(n125) );
  INVX2 U503 ( .A(n160), .Y(n158) );
  INVX2 U504 ( .A(n93), .Y(n91) );
  INVX2 U505 ( .A(n176), .Y(n174) );
  INVX2 U506 ( .A(n207), .Y(n205) );
  INVX2 U507 ( .A(n54), .Y(n52) );
  INVX2 U508 ( .A(n40), .Y(n38) );
  NOR2X2 U509 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U510 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U511 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U512 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U513 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U514 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U515 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U516 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U517 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U518 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U519 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U520 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U521 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U522 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U523 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U524 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U525 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U526 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U527 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U528 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U529 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U530 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U531 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U532 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U533 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U534 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U535 ( .A(A[1]), .B(n276), .Y(n219) );
  CLKNAND2X2 U536 ( .A(A[22]), .B(n255), .Y(n79) );
  INVX2 U537 ( .A(B[1]), .Y(n276) );
  INVX2 U538 ( .A(B[13]), .Y(n264) );
  INVX2 U539 ( .A(B[27]), .Y(n250) );
  INVX2 U540 ( .A(B[21]), .Y(n256) );
  INVX2 U541 ( .A(B[5]), .Y(n272) );
  INVX2 U542 ( .A(B[9]), .Y(n268) );
  INVX2 U543 ( .A(B[25]), .Y(n252) );
  INVX2 U544 ( .A(B[11]), .Y(n266) );
  INVX2 U545 ( .A(B[26]), .Y(n251) );
  INVX2 U546 ( .A(B[7]), .Y(n270) );
  INVX2 U547 ( .A(B[3]), .Y(n274) );
  INVX2 U548 ( .A(B[19]), .Y(n258) );
  INVX2 U549 ( .A(B[20]), .Y(n257) );
  INVX2 U550 ( .A(B[16]), .Y(n261) );
  INVX2 U551 ( .A(B[17]), .Y(n260) );
  INVX2 U552 ( .A(B[22]), .Y(n255) );
  INVX2 U553 ( .A(B[4]), .Y(n273) );
  INVX2 U554 ( .A(B[8]), .Y(n269) );
  INVX2 U555 ( .A(B[12]), .Y(n265) );
  INVX2 U556 ( .A(B[24]), .Y(n253) );
  INVX2 U557 ( .A(B[14]), .Y(n263) );
  XNOR2X1 U558 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  OAI21XL U559 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XNOR2XL U560 ( .A(n80), .B(n8), .Y(DIFF[22]) );
endmodule


module norm_v4_29_DW01_sub_34 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n31,
         n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46, n47,
         n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76,
         n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91, n92,
         n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106, n107,
         n110, n111, n112, n113, n114, n115, n116, n121, n122, n123, n126,
         n127, n128, n130, n131, n132, n133, n134, n135, n136, n137, n138,
         n139, n140, n141, n142, n143, n146, n147, n148, n149, n151, n154,
         n155, n156, n158, n159, n160, n161, n162, n163, n164, n168, n169,
         n170, n171, n172, n174, n175, n176, n177, n178, n180, n181, n182,
         n183, n184, n185, n186, n187, n188, n189, n190, n191, n192, n193,
         n194, n195, n196, n197, n198, n199, n200, n201, n202, n203, n205,
         n206, n207, n208, n209, n210, n211, n212, n213, n214, n215, n216,
         n217, n218, n219, n220, n222, n224, n225, n226, n228, n230, n231,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265,
         n266, n267, n268, n269, n270, n271, n272, n273, n274, n275, n276,
         \B[0] , n375, n376, n377, n378, n379, n380;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U7 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  OAI21XL U312 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21XL U313 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  OAI21XL U314 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OA21X4 U315 ( .A0(n1), .A1(n31), .B0(n32), .Y(DIFF[30]) );
  AOI21X3 U316 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  INVXL U317 ( .A(B[23]), .Y(n254) );
  INVXL U318 ( .A(B[6]), .Y(n271) );
  OAI21BX1 U319 ( .A0(n187), .A1(n178), .B0N(n181), .Y(n177) );
  NAND2X2 U320 ( .A(n378), .B(n122), .Y(n116) );
  NAND2X2 U321 ( .A(n376), .B(n377), .Y(n378) );
  OAI21BX1 U322 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  OAI21X1 U323 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  AOI21X1 U324 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  INVX2 U325 ( .A(n127), .Y(n377) );
  INVX1 U326 ( .A(n188), .Y(n187) );
  OAI21X1 U327 ( .A0(n187), .A1(n162), .B0(n163), .Y(n375) );
  INVX2 U328 ( .A(n121), .Y(n376) );
  CLKNAND2X2 U329 ( .A(A[17]), .B(n260), .Y(n122) );
  INVXL U330 ( .A(n116), .Y(n114) );
  AOI21BXL U331 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  OAI21XL U332 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  NOR2X2 U333 ( .A(n162), .B(n132), .Y(n130) );
  NOR2XL U334 ( .A(n92), .B(n87), .Y(n83) );
  CLKNAND2X2 U335 ( .A(A[12]), .B(n265), .Y(n160) );
  OAI21X2 U336 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NOR2XL U337 ( .A(n185), .B(n182), .Y(n180) );
  NOR2XL U338 ( .A(n206), .B(n201), .Y(n199) );
  NOR2XL U339 ( .A(n159), .B(n154), .Y(n148) );
  NAND2X1 U340 ( .A(A[6]), .B(n271), .Y(n197) );
  CLKNAND2X2 U341 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U342 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U343 ( .A(A[8]), .B(n269), .Y(n186) );
  NOR2XL U344 ( .A(n126), .B(n121), .Y(n115) );
  CLKNAND2X2 U345 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U346 ( .A(A[24]), .B(n253), .Y(n64) );
  CLKNAND2X2 U347 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2X2 U348 ( .A(A[16]), .B(n261), .Y(n127) );
  INVX2 U349 ( .A(n1), .Y(n128) );
  NAND2X2 U350 ( .A(n67), .B(n33), .Y(n31) );
  AND2X2 U351 ( .A(n379), .B(n380), .Y(n96) );
  INVXL U352 ( .A(n102), .Y(n380) );
  OAI21XL U353 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NAND2X1 U354 ( .A(n243), .B(n197), .Y(n24) );
  INVXL U355 ( .A(n185), .Y(n241) );
  NAND2X1 U356 ( .A(n247), .B(n216), .Y(n28) );
  NAND2XL U357 ( .A(n248), .B(n220), .Y(n29) );
  NAND2X2 U358 ( .A(n101), .B(n116), .Y(n379) );
  NOR2XL U359 ( .A(n110), .B(n103), .Y(n101) );
  OAI21X2 U360 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  OAI21XL U361 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  INVX2 U362 ( .A(n159), .Y(n237) );
  OAI21X1 U363 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  AOI21X1 U364 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  NOR2X2 U365 ( .A(n78), .B(n73), .Y(n71) );
  NAND2BXL U366 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U367 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  AOI21XL U368 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  OAI21X1 U369 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  INVXL U370 ( .A(n149), .Y(n151) );
  INVXL U371 ( .A(n196), .Y(n243) );
  OAI21X1 U372 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NAND2X1 U373 ( .A(A[10]), .B(n267), .Y(n176) );
  OAI21X2 U374 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  NAND2XL U375 ( .A(n148), .B(n134), .Y(n132) );
  NAND2BX1 U376 ( .AN(n95), .B(n83), .Y(n81) );
  CLKNAND2X2 U377 ( .A(n58), .B(n46), .Y(n44) );
  INVXL U378 ( .A(n162), .Y(n164) );
  OAI21XL U379 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  NOR2XL U380 ( .A(n212), .B(n215), .Y(n210) );
  NOR2BXL U381 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U382 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  NOR2X1 U383 ( .A(n53), .B(n48), .Y(n46) );
  XNOR2XL U384 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U385 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U386 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U387 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  XNOR2XL U388 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U389 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U390 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2XL U391 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U392 ( .A(n375), .B(n18), .Y(DIFF[12]) );
  NAND2XL U393 ( .A(n237), .B(n160), .Y(n18) );
  XNOR2XL U394 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U395 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U396 ( .A(n224), .B(n61), .Y(n5) );
  XNOR2XL U397 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  XNOR2XL U398 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NAND2XL U399 ( .A(n233), .B(n127), .Y(n14) );
  XNOR2XL U400 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  AOI21XL U401 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U402 ( .A(n235), .B(n146), .Y(n16) );
  XNOR2XL U403 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  AOI21XL U404 ( .A0(n128), .A1(n233), .B0(n377), .Y(n123) );
  NAND2XL U405 ( .A(n376), .B(n122), .Y(n13) );
  XNOR2XL U406 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U407 ( .A(n245), .B(n207), .Y(n26) );
  NAND2XL U408 ( .A(n76), .B(n79), .Y(n8) );
  NAND2XL U409 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U410 ( .A(n63), .Y(n225) );
  XNOR2XL U411 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U412 ( .A(n90), .B(n93), .Y(n10) );
  NAND2XL U413 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U414 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  INVXL U415 ( .A(n215), .Y(n247) );
  NAND2XL U416 ( .A(n228), .B(n88), .Y(n9) );
  NOR2X1 U417 ( .A(n175), .B(n170), .Y(n168) );
  OAI21X2 U418 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  NAND2XL U419 ( .A(n199), .B(n191), .Y(n189) );
  NOR2X1 U420 ( .A(n196), .B(n193), .Y(n191) );
  AOI2B1XL U421 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U422 ( .A(n110), .Y(n231) );
  INVXL U423 ( .A(n143), .Y(n235) );
  INVXL U424 ( .A(n175), .Y(n239) );
  INVXL U425 ( .A(n53), .Y(n51) );
  INVXL U426 ( .A(n206), .Y(n245) );
  INVXL U427 ( .A(n78), .Y(n76) );
  INVXL U428 ( .A(n126), .Y(n233) );
  INVXL U429 ( .A(n92), .Y(n90) );
  INVXL U430 ( .A(n212), .Y(n246) );
  INVXL U431 ( .A(n170), .Y(n238) );
  INVXL U432 ( .A(n48), .Y(n222) );
  INVXL U433 ( .A(n193), .Y(n242) );
  INVXL U434 ( .A(n182), .Y(n240) );
  INVXL U435 ( .A(n201), .Y(n244) );
  INVXL U436 ( .A(n136), .Y(n234) );
  INVXL U437 ( .A(n154), .Y(n236) );
  INVXL U438 ( .A(n73), .Y(n226) );
  INVXL U439 ( .A(n87), .Y(n228) );
  INVXL U440 ( .A(n103), .Y(n230) );
  NOR2X2 U441 ( .A(A[25]), .B(n252), .Y(n60) );
  CLKNAND2X2 U442 ( .A(A[22]), .B(n255), .Y(n79) );
  NAND2XL U443 ( .A(A[14]), .B(n263), .Y(n146) );
  NAND2X1 U444 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U445 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U446 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U447 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U448 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U449 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U450 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U451 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U452 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U453 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U454 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U455 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U456 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U457 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U458 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U459 ( .A(B[28]), .Y(n249) );
  INVXL U460 ( .A(B[10]), .Y(n267) );
  NOR2X2 U461 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U462 ( .A(n66), .Y(n65) );
  INVX2 U463 ( .A(n44), .Y(n42) );
  AOI21X1 U464 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  INVX2 U465 ( .A(n180), .Y(n178) );
  AOI21X2 U466 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  INVX2 U467 ( .A(n58), .Y(n56) );
  NAND2X2 U468 ( .A(n180), .B(n168), .Y(n162) );
  NAND2X2 U469 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U470 ( .A(n83), .B(n71), .Y(n69) );
  AOI21X1 U471 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U472 ( .A(n115), .B(n231), .Y(n106) );
  INVX2 U473 ( .A(n209), .Y(n208) );
  INVX2 U474 ( .A(n115), .Y(n113) );
  NAND2X2 U475 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U476 ( .A(n96), .Y(n98) );
  INVX2 U477 ( .A(n45), .Y(n43) );
  OAI21X1 U478 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  AOI21X1 U479 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  NOR2X2 U480 ( .A(n63), .B(n60), .Y(n58) );
  OAI21X1 U481 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  OAI21X1 U482 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  AOI21X1 U483 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U484 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  NOR2X2 U485 ( .A(n143), .B(n136), .Y(n134) );
  NOR2X2 U486 ( .A(n44), .B(n35), .Y(n33) );
  NOR2X2 U487 ( .A(n38), .B(A[29]), .Y(n36) );
  XNOR2X1 U488 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2X2 U489 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U490 ( .A(n246), .B(n213), .Y(n27) );
  NAND2X2 U491 ( .A(n230), .B(n104), .Y(n11) );
  AOI21X1 U492 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  NAND2X2 U493 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U494 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2X2 U495 ( .A(n222), .B(n49), .Y(n3) );
  NAND2X2 U496 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U497 ( .A(n244), .B(n202), .Y(n25) );
  NAND2X2 U498 ( .A(n234), .B(n137), .Y(n15) );
  AOI21X1 U499 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NAND2X2 U500 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U501 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  AOI21X1 U502 ( .A0(n375), .A1(n237), .B0(n158), .Y(n156) );
  INVX2 U503 ( .A(n60), .Y(n224) );
  INVX2 U504 ( .A(n93), .Y(n91) );
  INVX2 U505 ( .A(n219), .Y(n248) );
  INVX2 U506 ( .A(n218), .Y(n217) );
  INVX2 U507 ( .A(n207), .Y(n205) );
  INVX2 U508 ( .A(n160), .Y(n158) );
  INVX2 U509 ( .A(n176), .Y(n174) );
  INVX2 U510 ( .A(n79), .Y(n77) );
  INVX2 U511 ( .A(n54), .Y(n52) );
  INVX2 U512 ( .A(n40), .Y(n38) );
  NOR2X2 U513 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U514 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U515 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U516 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U517 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U518 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U519 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U520 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U521 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U522 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U523 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U524 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U525 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U526 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U527 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U528 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U529 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U530 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U531 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U532 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U533 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U534 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U535 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U536 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U537 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U538 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U539 ( .A(A[26]), .B(n251), .Y(n53) );
  INVX2 U540 ( .A(B[1]), .Y(n276) );
  INVX2 U541 ( .A(B[26]), .Y(n251) );
  INVX2 U542 ( .A(B[27]), .Y(n250) );
  INVX2 U543 ( .A(B[21]), .Y(n256) );
  INVX2 U544 ( .A(B[5]), .Y(n272) );
  INVX2 U545 ( .A(B[9]), .Y(n268) );
  INVX2 U546 ( .A(B[25]), .Y(n252) );
  INVX2 U547 ( .A(B[22]), .Y(n255) );
  INVX2 U548 ( .A(B[17]), .Y(n260) );
  INVX2 U549 ( .A(B[16]), .Y(n261) );
  INVX2 U550 ( .A(B[3]), .Y(n274) );
  INVX2 U551 ( .A(B[7]), .Y(n270) );
  INVX2 U552 ( .A(B[13]), .Y(n264) );
  INVX2 U553 ( .A(B[14]), .Y(n263) );
  INVX2 U554 ( .A(B[8]), .Y(n269) );
  INVX2 U555 ( .A(B[19]), .Y(n258) );
  INVX2 U556 ( .A(B[12]), .Y(n265) );
  INVX2 U557 ( .A(B[11]), .Y(n266) );
  INVX2 U558 ( .A(B[4]), .Y(n273) );
  INVX2 U559 ( .A(B[24]), .Y(n253) );
  INVX2 U560 ( .A(B[20]), .Y(n257) );
  XNOR2XL U561 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  AOI21X1 U562 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_36 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n180,
         n181, n182, n183, n184, n185, n186, n187, n188, n189, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n205, n206, n207, n208, n209, n210, n211, n212, n213, n214,
         n215, n216, n217, n218, n219, n220, n222, n224, n225, n226, n228,
         n230, n231, n232, n233, n234, n235, n236, n237, n238, n239, n240,
         n241, n242, n243, n244, n245, n246, n247, n248, n249, n250, n251,
         n252, n253, n254, n255, n256, n257, n258, n259, n260, n261, n262,
         n263, n264, n265, n266, n267, n268, n269, n270, n271, n272, n273,
         n274, n275, n276, \B[0] ;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U103 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U186 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  OAI21BX1 U314 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  AOI21X1 U315 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  OAI21X1 U316 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  INVXL U317 ( .A(n1), .Y(n128) );
  NOR2X1 U318 ( .A(n78), .B(n73), .Y(n71) );
  NOR2X1 U319 ( .A(n175), .B(n170), .Y(n168) );
  NAND2X1 U320 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U321 ( .A(A[10]), .B(n267), .Y(n176) );
  CLKNAND2X2 U322 ( .A(A[22]), .B(n255), .Y(n79) );
  OAI21XL U323 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  OAI21XL U324 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  AOI21X3 U325 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  OAI21X2 U326 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  AOI21X1 U327 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  NOR2XL U328 ( .A(n159), .B(n154), .Y(n148) );
  OAI21X1 U329 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  CLKNAND2X2 U330 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U331 ( .A(A[26]), .B(n251), .Y(n54) );
  NOR2X1 U332 ( .A(n92), .B(n87), .Y(n83) );
  NOR2X2 U333 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X1 U334 ( .A(n53), .B(n48), .Y(n46) );
  NAND2XL U335 ( .A(n247), .B(n216), .Y(n28) );
  NAND2XL U336 ( .A(A[6]), .B(n271), .Y(n197) );
  NAND2X2 U337 ( .A(A[16]), .B(n261), .Y(n127) );
  OAI21X2 U338 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  OAI21X1 U339 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U340 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  OAI21X2 U341 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  NOR2XL U342 ( .A(n212), .B(n215), .Y(n210) );
  NOR2XL U343 ( .A(n185), .B(n182), .Y(n180) );
  NOR2X1 U344 ( .A(n110), .B(n103), .Y(n101) );
  NOR2XL U345 ( .A(n206), .B(n201), .Y(n199) );
  NAND2XL U346 ( .A(n199), .B(n191), .Y(n189) );
  NOR2XL U347 ( .A(n196), .B(n193), .Y(n191) );
  INVXL U348 ( .A(n215), .Y(n247) );
  CLKNAND2X2 U349 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U350 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U351 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U352 ( .A(A[2]), .B(n275), .Y(n216) );
  NOR2X2 U353 ( .A(n162), .B(n132), .Y(n130) );
  AOI21XL U354 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  NAND2X2 U355 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U356 ( .A(n67), .B(n33), .Y(n31) );
  INVX2 U357 ( .A(n159), .Y(n237) );
  AOI21X1 U358 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  OAI21X1 U359 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  NAND2BXL U360 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U361 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  OAI21X1 U362 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  INVXL U363 ( .A(n149), .Y(n151) );
  NAND2X1 U364 ( .A(n241), .B(n186), .Y(n22) );
  OAI21X1 U365 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  INVXL U366 ( .A(n44), .Y(n42) );
  CLKINVX2 U367 ( .A(n30), .Y(DIFF[30]) );
  NAND2XL U368 ( .A(n148), .B(n134), .Y(n132) );
  NAND2BX2 U369 ( .AN(n95), .B(n83), .Y(n81) );
  OAI21XL U370 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  OAI21BX1 U371 ( .A0(n187), .A1(n178), .B0N(n181), .Y(n177) );
  NAND2XL U372 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U373 ( .A(n116), .Y(n114) );
  INVXL U374 ( .A(n162), .Y(n164) );
  INVXL U375 ( .A(n45), .Y(n43) );
  INVXL U376 ( .A(n115), .Y(n113) );
  OAI21XL U377 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  XNOR2XL U378 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2BXL U379 ( .AN(n148), .B(n143), .Y(n141) );
  NAND2XL U380 ( .A(n222), .B(n49), .Y(n3) );
  NAND2XL U381 ( .A(n242), .B(n194), .Y(n23) );
  XNOR2XL U382 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U383 ( .A(n238), .B(n171), .Y(n19) );
  NAND2XL U384 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U385 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  NAND2XL U386 ( .A(n234), .B(n137), .Y(n15) );
  NAND2XL U387 ( .A(n236), .B(n155), .Y(n17) );
  AOI21XL U388 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U389 ( .A(n244), .B(n202), .Y(n25) );
  NAND2XL U390 ( .A(n237), .B(n160), .Y(n18) );
  NAND2XL U391 ( .A(n230), .B(n104), .Y(n11) );
  XNOR2XL U392 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  XNOR2XL U393 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U394 ( .A(n239), .B(n176), .Y(n20) );
  NAND2XL U395 ( .A(n226), .B(n74), .Y(n7) );
  AOI21XL U396 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U397 ( .A(n232), .B(n122), .Y(n13) );
  OAI21XL U398 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  NAND2XL U399 ( .A(n224), .B(n61), .Y(n5) );
  NAND2XL U400 ( .A(n228), .B(n88), .Y(n9) );
  AOI21XL U401 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U402 ( .A(n235), .B(n146), .Y(n16) );
  XNOR2XL U403 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U404 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U405 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U406 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  INVXL U407 ( .A(n185), .Y(n241) );
  NAND2XL U408 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U409 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  XNOR2XL U410 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U411 ( .A(n90), .B(n93), .Y(n10) );
  XNOR2XL U412 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U413 ( .A(n76), .B(n79), .Y(n8) );
  INVXL U414 ( .A(n196), .Y(n243) );
  NAND2XL U415 ( .A(n243), .B(n197), .Y(n24) );
  XNOR2XL U416 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U417 ( .A(n245), .B(n207), .Y(n26) );
  NAND2XL U418 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U419 ( .A(n63), .Y(n225) );
  AOI2B1XL U420 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U421 ( .A(n110), .Y(n231) );
  INVXL U422 ( .A(n143), .Y(n235) );
  INVXL U423 ( .A(n175), .Y(n239) );
  INVXL U424 ( .A(n53), .Y(n51) );
  INVXL U425 ( .A(n126), .Y(n233) );
  INVXL U426 ( .A(n206), .Y(n245) );
  INVXL U427 ( .A(n78), .Y(n76) );
  INVXL U428 ( .A(n92), .Y(n90) );
  INVXL U429 ( .A(n212), .Y(n246) );
  INVXL U430 ( .A(n170), .Y(n238) );
  INVXL U431 ( .A(n193), .Y(n242) );
  INVXL U432 ( .A(n136), .Y(n234) );
  INVXL U433 ( .A(n182), .Y(n240) );
  INVXL U434 ( .A(n48), .Y(n222) );
  INVXL U435 ( .A(n154), .Y(n236) );
  INVXL U436 ( .A(n201), .Y(n244) );
  INVXL U437 ( .A(n103), .Y(n230) );
  INVXL U438 ( .A(n73), .Y(n226) );
  INVXL U439 ( .A(n87), .Y(n228) );
  INVXL U440 ( .A(n60), .Y(n224) );
  AOI21BX1 U441 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U442 ( .A(A[17]), .B(n260), .Y(n121) );
  CLKNAND2X2 U443 ( .A(A[4]), .B(n273), .Y(n207) );
  NAND2XL U444 ( .A(A[14]), .B(n263), .Y(n146) );
  CLKNAND2X2 U445 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U446 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U447 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U448 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U449 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U450 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U451 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U452 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U453 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U454 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U455 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U456 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U457 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U458 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U459 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U460 ( .A(B[28]), .Y(n249) );
  INVXL U461 ( .A(B[10]), .Y(n267) );
  NOR2X2 U462 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U463 ( .A(n66), .Y(n65) );
  OAI21X1 U464 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  INVX2 U465 ( .A(n58), .Y(n56) );
  AOI21X2 U466 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  INVX2 U467 ( .A(n180), .Y(n178) );
  AOI21X1 U468 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U469 ( .A(n58), .B(n46), .Y(n44) );
  NAND2X2 U470 ( .A(n180), .B(n168), .Y(n162) );
  NAND2X2 U471 ( .A(n83), .B(n71), .Y(n69) );
  INVX2 U472 ( .A(n209), .Y(n208) );
  INVX2 U473 ( .A(n188), .Y(n187) );
  NAND2X2 U474 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U475 ( .A(n96), .Y(n98) );
  OAI21X1 U476 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  OAI21X1 U477 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X1 U478 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  NOR2X2 U479 ( .A(n143), .B(n136), .Y(n134) );
  AOI21X1 U480 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  OAI21X1 U481 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U482 ( .A(n126), .B(n121), .Y(n115) );
  AOI21X1 U483 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21X1 U484 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U485 ( .A(n38), .B(A[29]), .Y(n36) );
  NOR2X2 U486 ( .A(n44), .B(n35), .Y(n33) );
  XNOR2X1 U487 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2X2 U488 ( .A(n233), .B(n127), .Y(n14) );
  AOI21X1 U489 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  AOI21X1 U490 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  AOI21X1 U491 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  AOI21X1 U492 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  XNOR2X1 U493 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  AOI21X1 U494 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  AOI21X1 U495 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  INVX2 U496 ( .A(n121), .Y(n232) );
  INVX2 U497 ( .A(n207), .Y(n205) );
  INVX2 U498 ( .A(n218), .Y(n217) );
  INVX2 U499 ( .A(n54), .Y(n52) );
  INVX2 U500 ( .A(n219), .Y(n248) );
  INVX2 U501 ( .A(n93), .Y(n91) );
  INVX2 U502 ( .A(n79), .Y(n77) );
  INVX2 U503 ( .A(n176), .Y(n174) );
  INVX2 U504 ( .A(n127), .Y(n125) );
  INVX2 U505 ( .A(n160), .Y(n158) );
  INVX2 U506 ( .A(n40), .Y(n38) );
  NOR2X2 U507 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U508 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U509 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U510 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U511 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U512 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U513 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U514 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U515 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U516 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U517 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U518 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U519 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U520 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U521 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U522 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U523 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U524 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U525 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U526 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U527 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U528 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U529 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U530 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U531 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U532 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U533 ( .A(A[22]), .B(n255), .Y(n78) );
  NAND2X2 U534 ( .A(n248), .B(n220), .Y(n29) );
  INVX2 U535 ( .A(B[17]), .Y(n260) );
  INVX2 U536 ( .A(B[22]), .Y(n255) );
  INVX2 U537 ( .A(B[1]), .Y(n276) );
  INVX2 U538 ( .A(B[27]), .Y(n250) );
  INVX2 U539 ( .A(B[5]), .Y(n272) );
  INVX2 U540 ( .A(B[9]), .Y(n268) );
  INVX2 U541 ( .A(B[19]), .Y(n258) );
  INVX2 U542 ( .A(B[25]), .Y(n252) );
  INVX2 U543 ( .A(B[11]), .Y(n266) );
  INVX2 U544 ( .A(B[21]), .Y(n256) );
  INVX2 U545 ( .A(B[16]), .Y(n261) );
  INVX2 U546 ( .A(B[20]), .Y(n257) );
  INVX2 U547 ( .A(B[3]), .Y(n274) );
  INVX2 U548 ( .A(B[7]), .Y(n270) );
  INVX2 U549 ( .A(B[13]), .Y(n264) );
  INVX2 U550 ( .A(B[14]), .Y(n263) );
  INVX2 U551 ( .A(B[8]), .Y(n269) );
  INVX2 U552 ( .A(B[12]), .Y(n265) );
  INVX2 U553 ( .A(B[26]), .Y(n251) );
  INVX2 U554 ( .A(B[24]), .Y(n253) );
  INVX2 U555 ( .A(B[4]), .Y(n273) );
  XNOR2X1 U556 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  AOI21X1 U557 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  XNOR2X1 U558 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  AOI21X1 U559 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_37 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n98, n101, n103, n104, n105, n106, n107,
         n110, n111, n112, n113, n114, n115, n116, n121, n122, n123, n125,
         n126, n127, n130, n131, n132, n133, n134, n135, n136, n137, n138,
         n139, n140, n141, n142, n143, n146, n147, n148, n149, n151, n154,
         n155, n156, n158, n159, n160, n161, n162, n163, n164, n168, n169,
         n170, n171, n172, n174, n175, n176, n177, n178, n179, n180, n181,
         n182, n183, n184, n185, n186, n187, n188, n189, n190, n191, n192,
         n193, n194, n195, n196, n197, n198, n199, n200, n201, n202, n203,
         n205, n206, n207, n208, n209, n210, n211, n212, n213, n214, n215,
         n216, n217, n218, n219, n220, n222, n224, n225, n226, n228, n230,
         n231, n232, n233, n234, n235, n236, n237, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n252,
         n253, n254, n255, n256, n257, n258, n259, n260, n261, n262, n263,
         n264, n265, n266, n267, n268, n269, n270, n271, n272, n273, n274,
         n275, n276, \B[0] , n374, n375, n376, n377, n378;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U7 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U81 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  OAI21X3 U312 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  AND2X4 U313 ( .A(n376), .B(n377), .Y(n209) );
  INVXL U314 ( .A(B[23]), .Y(n254) );
  INVXL U315 ( .A(B[6]), .Y(n271) );
  OAI21X2 U316 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NOR2X1 U317 ( .A(n110), .B(n103), .Y(n101) );
  OAI21BX1 U318 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  OAI21X1 U319 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  AND2X2 U320 ( .A(n375), .B(n374), .Y(n96) );
  OAI21X1 U321 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  AOI21X1 U322 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  OAI21X1 U323 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U324 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  OA21X2 U325 ( .A0(n103), .A1(n111), .B0(n104), .Y(n374) );
  NAND2X2 U326 ( .A(n101), .B(n116), .Y(n375) );
  OAI21X4 U327 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X4 U328 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  OAI21XL U329 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  NAND2X2 U330 ( .A(n210), .B(n218), .Y(n376) );
  INVX2 U331 ( .A(n211), .Y(n377) );
  NOR2X2 U332 ( .A(n212), .B(n215), .Y(n210) );
  OAI21X1 U333 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  AOI21X4 U334 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  NOR2X2 U335 ( .A(n162), .B(n132), .Y(n130) );
  AOI21X2 U336 ( .A0(n378), .A1(n67), .B0(n68), .Y(n66) );
  CLKNAND2X2 U337 ( .A(A[12]), .B(n265), .Y(n160) );
  NOR2XL U338 ( .A(n159), .B(n154), .Y(n148) );
  NOR2XL U339 ( .A(n206), .B(n201), .Y(n199) );
  NAND2X1 U340 ( .A(A[6]), .B(n271), .Y(n197) );
  CLKNAND2X2 U341 ( .A(A[10]), .B(n267), .Y(n176) );
  AO21XL U342 ( .A0(n188), .A1(n130), .B0(n131), .Y(n378) );
  CLKNAND2X2 U343 ( .A(A[22]), .B(n255), .Y(n79) );
  AOI21XL U344 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NOR2X2 U345 ( .A(n78), .B(n73), .Y(n71) );
  NOR2XL U346 ( .A(n63), .B(n60), .Y(n58) );
  CLKNAND2X2 U347 ( .A(A[20]), .B(n257), .Y(n93) );
  NAND2XL U348 ( .A(n180), .B(n168), .Y(n162) );
  NOR2X1 U349 ( .A(n92), .B(n87), .Y(n83) );
  NAND2X2 U350 ( .A(A[16]), .B(n261), .Y(n127) );
  NAND2XL U351 ( .A(n148), .B(n134), .Y(n132) );
  NOR2X1 U352 ( .A(n175), .B(n170), .Y(n168) );
  NAND2XL U353 ( .A(n199), .B(n191), .Y(n189) );
  OAI21X2 U354 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  CLKNAND2X2 U355 ( .A(A[24]), .B(n253), .Y(n64) );
  CLKNAND2X2 U356 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U357 ( .A(A[26]), .B(n251), .Y(n54) );
  NAND2X1 U358 ( .A(A[18]), .B(n259), .Y(n111) );
  INVX2 U359 ( .A(n66), .Y(n65) );
  AOI21XL U360 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  CLKINVX2 U361 ( .A(n180), .Y(n178) );
  NAND2X2 U362 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U363 ( .A(n67), .B(n33), .Y(n31) );
  INVX2 U364 ( .A(n159), .Y(n237) );
  XNOR2X1 U365 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  NAND2BXL U366 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U367 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  INVXL U368 ( .A(n149), .Y(n151) );
  NAND2X1 U369 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U370 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2XL U371 ( .A(n248), .B(n220), .Y(n29) );
  INVXL U372 ( .A(n44), .Y(n42) );
  CLKINVX2 U373 ( .A(n30), .Y(DIFF[30]) );
  OAI21X2 U374 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  OAI21XL U375 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  NAND2BX2 U376 ( .AN(n95), .B(n83), .Y(n81) );
  INVXL U377 ( .A(n181), .Y(n179) );
  NAND2XL U378 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U379 ( .A(n162), .Y(n164) );
  INVXL U380 ( .A(n115), .Y(n113) );
  XNOR2XL U381 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NOR2BXL U382 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U383 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21XL U384 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NOR2X1 U385 ( .A(n53), .B(n48), .Y(n46) );
  XNOR2XL U386 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U387 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U388 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U389 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U390 ( .A(n244), .B(n202), .Y(n25) );
  XNOR2XL U391 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U392 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U393 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2XL U394 ( .A(n237), .B(n160), .Y(n18) );
  NAND2XL U395 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U396 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  XNOR2XL U397 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U398 ( .A(n51), .B(n54), .Y(n4) );
  AOI21XL U399 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U400 ( .A(n235), .B(n146), .Y(n16) );
  INVXL U401 ( .A(n185), .Y(n241) );
  XNOR2XL U402 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  NAND2XL U403 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U404 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  AOI21XL U405 ( .A0(n378), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U406 ( .A(n232), .B(n122), .Y(n13) );
  XNOR2XL U407 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U408 ( .A(n245), .B(n207), .Y(n26) );
  XNOR2XL U409 ( .A(n378), .B(n14), .Y(DIFF[16]) );
  NAND2XL U410 ( .A(n233), .B(n127), .Y(n14) );
  XNOR2XL U411 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U412 ( .A(n76), .B(n79), .Y(n8) );
  INVXL U413 ( .A(n196), .Y(n243) );
  NAND2XL U414 ( .A(n243), .B(n197), .Y(n24) );
  NAND2XL U415 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U416 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  XNOR2XL U417 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U418 ( .A(n90), .B(n93), .Y(n10) );
  INVXL U419 ( .A(n215), .Y(n247) );
  NAND2XL U420 ( .A(n247), .B(n216), .Y(n28) );
  AOI2B1XL U421 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U422 ( .A(n110), .Y(n231) );
  INVXL U423 ( .A(n143), .Y(n235) );
  INVXL U424 ( .A(n175), .Y(n239) );
  INVXL U425 ( .A(n53), .Y(n51) );
  INVXL U426 ( .A(n206), .Y(n245) );
  INVXL U427 ( .A(n78), .Y(n76) );
  INVXL U428 ( .A(n126), .Y(n233) );
  INVXL U429 ( .A(n92), .Y(n90) );
  INVXL U430 ( .A(n212), .Y(n246) );
  INVXL U431 ( .A(n170), .Y(n238) );
  INVXL U432 ( .A(n48), .Y(n222) );
  INVXL U433 ( .A(n193), .Y(n242) );
  INVXL U434 ( .A(n201), .Y(n244) );
  INVXL U435 ( .A(n136), .Y(n234) );
  INVXL U436 ( .A(n73), .Y(n226) );
  INVXL U437 ( .A(n154), .Y(n236) );
  INVXL U438 ( .A(n60), .Y(n224) );
  INVXL U439 ( .A(n87), .Y(n228) );
  INVXL U440 ( .A(n103), .Y(n230) );
  AOI21BX1 U441 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U442 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U443 ( .A(A[17]), .B(n260), .Y(n121) );
  CLKNAND2X2 U444 ( .A(A[4]), .B(n273), .Y(n207) );
  NAND2XL U445 ( .A(A[14]), .B(n263), .Y(n146) );
  CLKNAND2X2 U446 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U447 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U448 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U449 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U450 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U451 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U452 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U453 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U454 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U455 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U456 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U457 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U458 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U459 ( .A(A[19]), .B(n258), .Y(n104) );
  INVXL U460 ( .A(B[10]), .Y(n267) );
  INVXL U461 ( .A(B[28]), .Y(n249) );
  NOR2X2 U462 ( .A(n95), .B(n69), .Y(n67) );
  OAI21X1 U463 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  INVX2 U464 ( .A(n58), .Y(n56) );
  NAND2X2 U465 ( .A(n58), .B(n46), .Y(n44) );
  NAND2X2 U466 ( .A(n83), .B(n71), .Y(n69) );
  AOI21X1 U467 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  INVX2 U468 ( .A(n188), .Y(n187) );
  INVX2 U469 ( .A(n209), .Y(n208) );
  INVX2 U470 ( .A(n116), .Y(n114) );
  NAND2X2 U471 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U472 ( .A(n96), .Y(n98) );
  INVX2 U473 ( .A(n45), .Y(n43) );
  AOI21X1 U474 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  NOR2X2 U475 ( .A(n185), .B(n182), .Y(n180) );
  NOR2X2 U476 ( .A(n126), .B(n121), .Y(n115) );
  AOI21X1 U477 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U478 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NOR2X2 U479 ( .A(n143), .B(n136), .Y(n134) );
  OAI21X1 U480 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2X2 U481 ( .A(n44), .B(n35), .Y(n33) );
  NOR2X2 U482 ( .A(n196), .B(n193), .Y(n191) );
  NAND2X2 U483 ( .A(n225), .B(n64), .Y(n6) );
  INVX2 U484 ( .A(n63), .Y(n225) );
  AOI21X1 U485 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  NOR2X2 U486 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U487 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U488 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  AOI21X1 U489 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2X2 U490 ( .A(n222), .B(n49), .Y(n3) );
  AOI21X1 U491 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  NAND2X2 U492 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U493 ( .A(n234), .B(n137), .Y(n15) );
  NAND2X2 U494 ( .A(n224), .B(n61), .Y(n5) );
  NAND2X2 U495 ( .A(n228), .B(n88), .Y(n9) );
  NAND2X2 U496 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U497 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  NAND2X2 U498 ( .A(n230), .B(n104), .Y(n11) );
  AOI21X1 U499 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  OAI21X1 U500 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  INVX2 U501 ( .A(n121), .Y(n232) );
  INVX2 U502 ( .A(n182), .Y(n240) );
  INVX2 U503 ( .A(n219), .Y(n248) );
  INVX2 U504 ( .A(n218), .Y(n217) );
  INVX2 U505 ( .A(n160), .Y(n158) );
  INVX2 U506 ( .A(n127), .Y(n125) );
  INVX2 U507 ( .A(n207), .Y(n205) );
  INVX2 U508 ( .A(n176), .Y(n174) );
  INVX2 U509 ( .A(n54), .Y(n52) );
  INVX2 U510 ( .A(n93), .Y(n91) );
  INVX2 U511 ( .A(n79), .Y(n77) );
  INVX2 U512 ( .A(n40), .Y(n38) );
  NOR2X2 U513 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U514 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U515 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U516 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U517 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U518 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U519 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U520 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U521 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U522 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U523 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U524 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U525 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U526 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U527 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U528 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U529 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U530 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U531 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U532 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U533 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U534 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U535 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U536 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U537 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U538 ( .A(A[27]), .B(n250), .Y(n48) );
  NAND2X2 U539 ( .A(A[1]), .B(n276), .Y(n220) );
  INVX2 U540 ( .A(B[13]), .Y(n264) );
  INVX2 U541 ( .A(B[1]), .Y(n276) );
  INVX2 U542 ( .A(B[27]), .Y(n250) );
  INVX2 U543 ( .A(B[5]), .Y(n272) );
  INVX2 U544 ( .A(B[9]), .Y(n268) );
  INVX2 U545 ( .A(B[25]), .Y(n252) );
  INVX2 U546 ( .A(B[11]), .Y(n266) );
  INVX2 U547 ( .A(B[17]), .Y(n260) );
  INVX2 U548 ( .A(B[3]), .Y(n274) );
  INVX2 U549 ( .A(B[16]), .Y(n261) );
  INVX2 U550 ( .A(B[7]), .Y(n270) );
  INVX2 U551 ( .A(B[22]), .Y(n255) );
  INVX2 U552 ( .A(B[26]), .Y(n251) );
  INVX2 U553 ( .A(B[20]), .Y(n257) );
  INVX2 U554 ( .A(B[14]), .Y(n263) );
  INVX2 U555 ( .A(B[4]), .Y(n273) );
  INVX2 U556 ( .A(B[8]), .Y(n269) );
  INVX2 U557 ( .A(B[21]), .Y(n256) );
  INVX2 U558 ( .A(B[12]), .Y(n265) );
  INVX2 U559 ( .A(B[19]), .Y(n258) );
  INVX2 U560 ( .A(B[24]), .Y(n253) );
endmodule


module norm_v4_29_DW01_sub_39 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n205, n206, n207, n210, n211, n212, n213, n214, n215, n216,
         n217, n218, n219, n220, n222, n224, n225, n226, n228, n230, n231,
         n232, n233, n234, n235, n236, n237, n238, n239, n240, n241, n242,
         n243, n244, n245, n246, n247, n248, n249, n250, n251, n252, n253,
         n254, n255, n256, n257, n258, n259, n260, n261, n262, n263, n264,
         n265, n266, n267, n268, n269, n270, n271, n272, n273, n274, n275,
         n276, \B[0] , n374, n375, n376, n377, n378, n379;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U194 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  NOR2X2 U314 ( .A(A[17]), .B(n260), .Y(n121) );
  INVX2 U315 ( .A(n188), .Y(n187) );
  OAI21X1 U316 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  AOI21X1 U317 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  AOI21X1 U318 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  AO21X2 U319 ( .A0(n210), .A1(n218), .B0(n211), .Y(n374) );
  AND2X2 U320 ( .A(n199), .B(n191), .Y(n375) );
  OAI21BX1 U321 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n376) );
  NOR2X2 U322 ( .A(n379), .B(n68), .Y(n66) );
  NAND2X4 U323 ( .A(n374), .B(n375), .Y(n377) );
  NAND2X4 U324 ( .A(n377), .B(n190), .Y(n188) );
  AOI21X4 U325 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  INVXL U326 ( .A(n1), .Y(n128) );
  NOR2X1 U327 ( .A(n53), .B(n48), .Y(n46) );
  NOR2X1 U328 ( .A(n126), .B(n121), .Y(n115) );
  OAI21BXL U329 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  OAI21X1 U330 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  NOR2X1 U331 ( .A(n206), .B(n201), .Y(n199) );
  OAI21XL U332 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  NOR2X2 U333 ( .A(n95), .B(n69), .Y(n67) );
  XNOR2X1 U334 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  CLKNAND2X2 U335 ( .A(A[2]), .B(n275), .Y(n216) );
  NOR2X2 U336 ( .A(n1), .B(n378), .Y(n379) );
  INVXL U337 ( .A(n67), .Y(n378) );
  INVXL U338 ( .A(n66), .Y(n65) );
  INVXL U339 ( .A(n181), .Y(n179) );
  OAI21X1 U340 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  NAND2XL U341 ( .A(n148), .B(n134), .Y(n132) );
  XNOR2XL U342 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2XL U343 ( .A(A[17]), .B(n260), .Y(n122) );
  NOR2X2 U344 ( .A(n162), .B(n132), .Y(n130) );
  NAND2BXL U345 ( .AN(n95), .B(n83), .Y(n81) );
  AOI21XL U346 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  INVXL U347 ( .A(n180), .Y(n178) );
  AOI21XL U348 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  NAND2XL U349 ( .A(n226), .B(n74), .Y(n7) );
  AOI21XL U350 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  OAI21X1 U351 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  NOR2XL U352 ( .A(n212), .B(n215), .Y(n210) );
  NOR2X2 U353 ( .A(n78), .B(n73), .Y(n71) );
  NAND2BXL U354 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U355 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  INVXL U356 ( .A(n63), .Y(n225) );
  NAND2XL U357 ( .A(n90), .B(n93), .Y(n10) );
  INVXL U358 ( .A(n185), .Y(n241) );
  OAI21X1 U359 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  INVXL U360 ( .A(n149), .Y(n151) );
  NOR2X2 U361 ( .A(n196), .B(n193), .Y(n191) );
  NAND2X1 U362 ( .A(n247), .B(n216), .Y(n28) );
  NAND2X1 U363 ( .A(A[14]), .B(n263), .Y(n146) );
  NOR2X1 U364 ( .A(A[28]), .B(n249), .Y(n35) );
  OAI21XL U365 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  OAI21X2 U366 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  CLKNAND2X2 U367 ( .A(n180), .B(n168), .Y(n162) );
  CLKNAND2X2 U368 ( .A(n58), .B(n46), .Y(n44) );
  NAND2XL U369 ( .A(n67), .B(n33), .Y(n31) );
  INVXL U370 ( .A(n162), .Y(n164) );
  INVXL U371 ( .A(n45), .Y(n43) );
  INVXL U372 ( .A(n96), .Y(n98) );
  NOR2XL U373 ( .A(n92), .B(n87), .Y(n83) );
  XNOR2XL U374 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2BXL U375 ( .AN(n148), .B(n143), .Y(n141) );
  NOR2X1 U376 ( .A(n110), .B(n103), .Y(n101) );
  XNOR2XL U377 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U378 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U379 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U380 ( .A0(n374), .A1(n245), .B0(n205), .Y(n203) );
  XNOR2XL U381 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  XNOR2XL U382 ( .A(n376), .B(n4), .Y(DIFF[26]) );
  NAND2XL U383 ( .A(n224), .B(n61), .Y(n5) );
  AOI21XL U384 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2XL U385 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U386 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  AOI21XL U387 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  XNOR2XL U388 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  AOI21XL U389 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U390 ( .A(n232), .B(n122), .Y(n13) );
  NAND2XL U391 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U392 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  XNOR2XL U393 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  XNOR2XL U394 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  INVXL U395 ( .A(n215), .Y(n247) );
  NOR2X1 U396 ( .A(n175), .B(n170), .Y(n168) );
  AOI2B1XL U397 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U398 ( .A(n110), .Y(n231) );
  INVXL U399 ( .A(n126), .Y(n233) );
  INVXL U400 ( .A(n143), .Y(n235) );
  INVXL U401 ( .A(n175), .Y(n239) );
  INVXL U402 ( .A(n53), .Y(n51) );
  INVXL U403 ( .A(n159), .Y(n237) );
  INVXL U404 ( .A(n206), .Y(n245) );
  INVXL U405 ( .A(n78), .Y(n76) );
  INVXL U406 ( .A(n92), .Y(n90) );
  INVXL U407 ( .A(n212), .Y(n246) );
  INVXL U408 ( .A(n48), .Y(n222) );
  INVXL U409 ( .A(n170), .Y(n238) );
  INVXL U410 ( .A(n193), .Y(n242) );
  INVXL U411 ( .A(n201), .Y(n244) );
  INVXL U412 ( .A(n136), .Y(n234) );
  INVXL U413 ( .A(n73), .Y(n226) );
  INVXL U414 ( .A(n87), .Y(n228) );
  INVXL U415 ( .A(n103), .Y(n230) );
  INVXL U416 ( .A(n121), .Y(n232) );
  AOI21BX1 U417 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U418 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U419 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U420 ( .A(A[25]), .B(n252), .Y(n60) );
  NAND2XL U421 ( .A(n248), .B(n220), .Y(n29) );
  CLKNAND2X2 U422 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U423 ( .A(A[22]), .B(n255), .Y(n79) );
  CLKNAND2X2 U424 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U425 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U426 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U427 ( .A(A[16]), .B(n261), .Y(n127) );
  CLKNAND2X2 U428 ( .A(A[10]), .B(n267), .Y(n176) );
  CLKNAND2X2 U429 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U430 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U431 ( .A(A[6]), .B(n271), .Y(n197) );
  NAND2X1 U432 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U433 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U434 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U435 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U436 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U437 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U438 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U439 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U440 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U441 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U442 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U443 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U444 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U445 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U446 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U447 ( .A(B[28]), .Y(n249) );
  INVXL U448 ( .A(B[10]), .Y(n267) );
  INVX2 U449 ( .A(n44), .Y(n42) );
  INVX2 U450 ( .A(n58), .Y(n56) );
  AOI21X4 U451 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  NAND2X2 U452 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U453 ( .A(n83), .B(n71), .Y(n69) );
  AOI21X1 U454 ( .A0(n374), .A1(n199), .B0(n200), .Y(n198) );
  INVX2 U455 ( .A(n30), .Y(DIFF[30]) );
  OAI21X1 U456 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  NAND2X2 U457 ( .A(n115), .B(n231), .Y(n106) );
  INVX2 U458 ( .A(n115), .Y(n113) );
  NAND2X2 U459 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U460 ( .A(n116), .Y(n114) );
  NOR2X2 U461 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X2 U462 ( .A(n185), .B(n182), .Y(n180) );
  OAI21X1 U463 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U464 ( .A(n159), .B(n154), .Y(n148) );
  OAI21X1 U465 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U466 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  OAI21X1 U467 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U468 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NAND2X2 U469 ( .A(n231), .B(n111), .Y(n12) );
  AOI21X1 U470 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  NOR2X2 U471 ( .A(n44), .B(n35), .Y(n33) );
  NOR2X2 U472 ( .A(n143), .B(n136), .Y(n134) );
  OAI21X2 U473 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  AOI21X1 U474 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U475 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U476 ( .A(n38), .B(A[29]), .Y(n36) );
  XNOR2X1 U477 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2X2 U478 ( .A(n225), .B(n64), .Y(n6) );
  NAND2X2 U479 ( .A(n51), .B(n54), .Y(n4) );
  NAND2X2 U480 ( .A(n237), .B(n160), .Y(n18) );
  NAND2X2 U481 ( .A(n239), .B(n176), .Y(n20) );
  NAND2X2 U482 ( .A(n241), .B(n186), .Y(n22) );
  XNOR2X1 U483 ( .A(n374), .B(n26), .Y(DIFF[4]) );
  NAND2X2 U484 ( .A(n245), .B(n207), .Y(n26) );
  NAND2X2 U485 ( .A(n235), .B(n146), .Y(n16) );
  NAND2X2 U486 ( .A(n233), .B(n127), .Y(n14) );
  NAND2X2 U487 ( .A(n234), .B(n137), .Y(n15) );
  NAND2X2 U488 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U489 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U490 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2X2 U491 ( .A(n230), .B(n104), .Y(n11) );
  NAND2X2 U492 ( .A(n228), .B(n88), .Y(n9) );
  NAND2X2 U493 ( .A(n222), .B(n49), .Y(n3) );
  NAND2X2 U494 ( .A(n244), .B(n202), .Y(n25) );
  NAND2X2 U495 ( .A(n243), .B(n197), .Y(n24) );
  INVX2 U496 ( .A(n196), .Y(n243) );
  NAND2X2 U497 ( .A(n76), .B(n79), .Y(n8) );
  INVX2 U498 ( .A(n154), .Y(n236) );
  INVX2 U499 ( .A(n218), .Y(n217) );
  INVX2 U500 ( .A(n182), .Y(n240) );
  INVX2 U501 ( .A(n60), .Y(n224) );
  INVX2 U502 ( .A(n207), .Y(n205) );
  INVX2 U503 ( .A(n54), .Y(n52) );
  INVX2 U504 ( .A(n219), .Y(n248) );
  INVX2 U505 ( .A(n127), .Y(n125) );
  INVX2 U506 ( .A(n160), .Y(n158) );
  INVX2 U507 ( .A(n176), .Y(n174) );
  INVX2 U508 ( .A(n93), .Y(n91) );
  INVX2 U509 ( .A(n40), .Y(n38) );
  INVX2 U510 ( .A(n79), .Y(n77) );
  NOR2X2 U511 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U512 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U513 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U514 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U515 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U516 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U517 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U518 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U519 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U520 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U521 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U522 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U523 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U524 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U525 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U526 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U527 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U528 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U529 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U530 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U531 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U532 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U533 ( .A(A[11]), .B(n266), .Y(n170) );
  INVX2 U534 ( .A(B[1]), .Y(n276) );
  INVX2 U535 ( .A(B[13]), .Y(n264) );
  INVX2 U536 ( .A(B[27]), .Y(n250) );
  INVX2 U537 ( .A(B[5]), .Y(n272) );
  INVX2 U538 ( .A(B[9]), .Y(n268) );
  INVX2 U539 ( .A(B[21]), .Y(n256) );
  INVX2 U540 ( .A(B[19]), .Y(n258) );
  INVX2 U541 ( .A(B[25]), .Y(n252) );
  INVX2 U542 ( .A(B[12]), .Y(n265) );
  INVX2 U543 ( .A(B[11]), .Y(n266) );
  INVX2 U544 ( .A(B[3]), .Y(n274) );
  INVX2 U545 ( .A(B[20]), .Y(n257) );
  INVX2 U546 ( .A(B[16]), .Y(n261) );
  INVX2 U547 ( .A(B[17]), .Y(n260) );
  INVX2 U548 ( .A(B[7]), .Y(n270) );
  INVX2 U549 ( .A(B[22]), .Y(n255) );
  INVX2 U550 ( .A(B[14]), .Y(n263) );
  INVX2 U551 ( .A(B[8]), .Y(n269) );
  INVX2 U552 ( .A(B[26]), .Y(n251) );
  INVX2 U553 ( .A(B[4]), .Y(n273) );
  INVX2 U554 ( .A(B[24]), .Y(n253) );
  OAI21XL U555 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  OAI21X1 U556 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21XL U557 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OAI21XL U558 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  XNOR2XL U559 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  AOI21X1 U560 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  AOI21X1 U561 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  AOI21X1 U562 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_40 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60,
         n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74,
         n75, n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n205, n206, n207, n209, n210, n211, n212, n213, n214, n215,
         n216, n217, n218, n219, n220, n222, n224, n225, n226, n228, n230,
         n231, n232, n233, n234, n235, n236, n237, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n248, n249, n250, n251, n252, n253,
         n254, n255, n256, n257, n258, n259, n260, n261, n262, n263, n264,
         n265, n266, n267, n268, n269, n270, n271, n272, n273, n274, n275,
         n276, \B[0] , n374, n375, n376, n377, n378;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U7 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U103 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  AOI21X1 U314 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  CLKNAND2X2 U315 ( .A(n377), .B(n374), .Y(n378) );
  OAI21X1 U316 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  OAI21X1 U317 ( .A0(n66), .A1(n56), .B0(n57), .Y(n55) );
  AOI21X1 U318 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  AOI21X1 U319 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  AOI21X1 U320 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  AND2X2 U321 ( .A(n199), .B(n191), .Y(n374) );
  OAI21X1 U322 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  CLKINVX1 U323 ( .A(n188), .Y(n187) );
  CLKNAND2X2 U324 ( .A(n128), .B(n67), .Y(n375) );
  INVXL U325 ( .A(n68), .Y(n376) );
  AND2X4 U326 ( .A(n375), .B(n376), .Y(n66) );
  CLKNAND2X4 U327 ( .A(n378), .B(n190), .Y(n188) );
  INVX2 U328 ( .A(n209), .Y(n377) );
  CLKINVX2 U329 ( .A(n30), .Y(DIFF[30]) );
  NOR2XL U330 ( .A(n206), .B(n201), .Y(n199) );
  CLKNAND2X2 U331 ( .A(A[12]), .B(n265), .Y(n160) );
  NOR2XL U332 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U333 ( .A(n92), .B(n87), .Y(n83) );
  NAND2X2 U334 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X2 U335 ( .A(A[18]), .B(n259), .Y(n111) );
  OAI21X1 U336 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  NAND2X2 U337 ( .A(A[8]), .B(n269), .Y(n186) );
  AOI21XL U338 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  NOR2X1 U339 ( .A(n212), .B(n215), .Y(n210) );
  NAND2X2 U340 ( .A(A[20]), .B(n257), .Y(n93) );
  INVXL U341 ( .A(n59), .Y(n57) );
  NAND2X2 U342 ( .A(n83), .B(n71), .Y(n69) );
  INVXL U343 ( .A(n185), .Y(n241) );
  NAND2XL U344 ( .A(n233), .B(n127), .Y(n14) );
  NAND2BXL U345 ( .AN(n35), .B(n40), .Y(n2) );
  XNOR2X1 U346 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  INVXL U347 ( .A(n149), .Y(n151) );
  NAND2XL U348 ( .A(A[6]), .B(n271), .Y(n197) );
  NOR2X1 U349 ( .A(A[28]), .B(n249), .Y(n35) );
  NAND2XL U350 ( .A(A[17]), .B(n260), .Y(n122) );
  INVXL U351 ( .A(n44), .Y(n42) );
  AOI21X4 U352 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  NOR2X1 U353 ( .A(n162), .B(n132), .Y(n130) );
  OAI21X2 U354 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  NAND2BX1 U355 ( .AN(n95), .B(n83), .Y(n81) );
  INVXL U356 ( .A(n58), .Y(n56) );
  INVXL U357 ( .A(n180), .Y(n178) );
  INVXL U358 ( .A(n181), .Y(n179) );
  NAND2XL U359 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U360 ( .A(n162), .Y(n164) );
  INVXL U361 ( .A(n115), .Y(n113) );
  OAI21X2 U362 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  NOR2X1 U363 ( .A(n196), .B(n193), .Y(n191) );
  NOR2BXL U364 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U365 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21XL U366 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  XNOR2XL U367 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  XNOR2XL U368 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2X1 U369 ( .A(n175), .B(n170), .Y(n168) );
  NOR2X1 U370 ( .A(n53), .B(n48), .Y(n46) );
  NAND2XL U371 ( .A(n239), .B(n176), .Y(n20) );
  NAND2XL U372 ( .A(n242), .B(n194), .Y(n23) );
  XNOR2XL U373 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  AOI21XL U374 ( .A0(n377), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U375 ( .A(n244), .B(n202), .Y(n25) );
  NAND2XL U376 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U377 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U378 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2XL U379 ( .A(n238), .B(n171), .Y(n19) );
  NAND2XL U380 ( .A(n226), .B(n74), .Y(n7) );
  XNOR2XL U381 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U382 ( .A(n51), .B(n54), .Y(n4) );
  XNOR2XL U383 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  NAND2XL U384 ( .A(n224), .B(n61), .Y(n5) );
  OAI21XL U385 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  NAND2XL U386 ( .A(n234), .B(n137), .Y(n15) );
  XNOR2XL U387 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2XL U388 ( .A(n236), .B(n155), .Y(n17) );
  NAND2XL U389 ( .A(n228), .B(n88), .Y(n9) );
  NAND2XL U390 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U391 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  NAND2XL U392 ( .A(n230), .B(n104), .Y(n11) );
  XNOR2XL U393 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  XNOR2XL U394 ( .A(n377), .B(n26), .Y(DIFF[4]) );
  NAND2XL U395 ( .A(n245), .B(n207), .Y(n26) );
  XNOR2XL U396 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U397 ( .A(n76), .B(n79), .Y(n8) );
  AOI21XL U398 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U399 ( .A(n235), .B(n146), .Y(n16) );
  INVXL U400 ( .A(n196), .Y(n243) );
  NAND2XL U401 ( .A(n243), .B(n197), .Y(n24) );
  AOI21XL U402 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U403 ( .A(n232), .B(n122), .Y(n13) );
  NAND2XL U404 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U405 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  NAND2XL U406 ( .A(n90), .B(n93), .Y(n10) );
  NAND2BXL U407 ( .AN(n215), .B(n216), .Y(n28) );
  AOI2B1XL U408 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U409 ( .A(n110), .Y(n231) );
  INVXL U410 ( .A(n218), .Y(n217) );
  INVXL U411 ( .A(n143), .Y(n235) );
  INVXL U412 ( .A(n53), .Y(n51) );
  INVXL U413 ( .A(n175), .Y(n239) );
  INVXL U414 ( .A(n159), .Y(n237) );
  INVXL U415 ( .A(n78), .Y(n76) );
  INVXL U416 ( .A(n92), .Y(n90) );
  INVXL U417 ( .A(n212), .Y(n246) );
  INVXL U418 ( .A(n48), .Y(n222) );
  INVXL U419 ( .A(n193), .Y(n242) );
  INVXL U420 ( .A(n170), .Y(n238) );
  INVXL U421 ( .A(n201), .Y(n244) );
  INVXL U422 ( .A(n73), .Y(n226) );
  INVXL U423 ( .A(n136), .Y(n234) );
  INVXL U424 ( .A(n87), .Y(n228) );
  INVXL U425 ( .A(n103), .Y(n230) );
  AOI21BX1 U426 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  INVXL U427 ( .A(n219), .Y(n248) );
  INVXL U428 ( .A(n207), .Y(n205) );
  INVXL U429 ( .A(n127), .Y(n125) );
  NOR2XL U430 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U431 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U432 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U433 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U434 ( .A(A[17]), .B(n260), .Y(n121) );
  NAND2X1 U435 ( .A(A[22]), .B(n255), .Y(n79) );
  CLKNAND2X2 U436 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U437 ( .A(A[10]), .B(n267), .Y(n176) );
  NAND2XL U438 ( .A(A[14]), .B(n263), .Y(n146) );
  NAND2XL U439 ( .A(n248), .B(n220), .Y(n29) );
  CLKNAND2X2 U440 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U441 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U442 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U443 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U444 ( .A(A[1]), .B(n276), .Y(n220) );
  NAND2XL U445 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U446 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U447 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U448 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U449 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U450 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U451 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U452 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U453 ( .A(A[19]), .B(n258), .Y(n104) );
  INVXL U454 ( .A(B[28]), .Y(n249) );
  INVXL U455 ( .A(B[10]), .Y(n267) );
  NOR2X2 U456 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U457 ( .A(n1), .Y(n128) );
  INVX2 U458 ( .A(n66), .Y(n65) );
  AOI21X1 U459 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  NAND2X2 U460 ( .A(n148), .B(n134), .Y(n132) );
  NAND2X2 U461 ( .A(n180), .B(n168), .Y(n162) );
  NAND2X2 U462 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U463 ( .A(n58), .B(n46), .Y(n44) );
  AOI21X1 U464 ( .A0(n377), .A1(n199), .B0(n200), .Y(n198) );
  OAI21X1 U465 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  NAND2X2 U466 ( .A(n67), .B(n33), .Y(n31) );
  NAND2X2 U467 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U468 ( .A(n96), .Y(n98) );
  INVX2 U469 ( .A(n116), .Y(n114) );
  INVX2 U470 ( .A(n45), .Y(n43) );
  NOR2X2 U471 ( .A(n185), .B(n182), .Y(n180) );
  OAI21X1 U472 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  OAI21X1 U473 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U474 ( .A(n110), .B(n103), .Y(n101) );
  OAI21X1 U475 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  OAI21X1 U476 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  NOR2X2 U477 ( .A(n159), .B(n154), .Y(n148) );
  AOI21X1 U478 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U479 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  NOR2X2 U480 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X2 U481 ( .A(n126), .B(n121), .Y(n115) );
  OAI21X1 U482 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  OAI21X1 U483 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2X2 U484 ( .A(n78), .B(n73), .Y(n71) );
  NOR2X2 U485 ( .A(n44), .B(n35), .Y(n33) );
  NOR2X2 U486 ( .A(n143), .B(n136), .Y(n134) );
  AOI21X1 U487 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  NOR2X2 U488 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U489 ( .A(n237), .B(n160), .Y(n18) );
  NAND2X2 U490 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U491 ( .A(n225), .B(n64), .Y(n6) );
  INVX2 U492 ( .A(n63), .Y(n225) );
  AOI21X1 U493 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  OAI21X1 U494 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  NAND2X2 U495 ( .A(n222), .B(n49), .Y(n3) );
  AOI21X1 U496 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  AOI21X1 U497 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  XOR2X1 U498 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  AOI21X1 U499 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  XOR2X1 U500 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  INVX2 U501 ( .A(n206), .Y(n245) );
  INVX2 U502 ( .A(n126), .Y(n233) );
  INVX2 U503 ( .A(n154), .Y(n236) );
  INVX2 U504 ( .A(n121), .Y(n232) );
  INVX2 U505 ( .A(n182), .Y(n240) );
  INVX2 U506 ( .A(n60), .Y(n224) );
  INVX2 U507 ( .A(n54), .Y(n52) );
  INVX2 U508 ( .A(n160), .Y(n158) );
  INVX2 U509 ( .A(n93), .Y(n91) );
  INVX2 U510 ( .A(n176), .Y(n174) );
  INVX2 U511 ( .A(n40), .Y(n38) );
  INVX2 U512 ( .A(n79), .Y(n77) );
  NOR2X2 U513 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U514 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U515 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U516 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U517 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U518 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U519 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U520 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U521 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U522 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U523 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U524 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U525 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U526 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U527 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U528 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U529 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U530 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U531 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U532 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U533 ( .A(A[3]), .B(n274), .Y(n212) );
  NAND2X2 U534 ( .A(A[4]), .B(n273), .Y(n207) );
  NAND2X2 U535 ( .A(A[16]), .B(n261), .Y(n127) );
  NAND2X2 U536 ( .A(A[2]), .B(n275), .Y(n216) );
  INVX2 U537 ( .A(B[16]), .Y(n261) );
  INVX2 U538 ( .A(B[17]), .Y(n260) );
  INVX2 U539 ( .A(B[3]), .Y(n274) );
  INVX2 U540 ( .A(B[13]), .Y(n264) );
  INVX2 U541 ( .A(B[27]), .Y(n250) );
  INVX2 U542 ( .A(B[5]), .Y(n272) );
  INVX2 U543 ( .A(B[9]), .Y(n268) );
  INVX2 U544 ( .A(B[21]), .Y(n256) );
  INVX2 U545 ( .A(B[25]), .Y(n252) );
  INVX2 U546 ( .A(B[1]), .Y(n276) );
  INVX2 U547 ( .A(B[12]), .Y(n265) );
  INVX2 U548 ( .A(B[7]), .Y(n270) );
  INVX2 U549 ( .A(B[22]), .Y(n255) );
  INVX2 U550 ( .A(B[4]), .Y(n273) );
  INVX2 U551 ( .A(B[14]), .Y(n263) );
  INVX2 U552 ( .A(B[20]), .Y(n257) );
  INVX2 U553 ( .A(B[8]), .Y(n269) );
  INVX2 U554 ( .A(B[19]), .Y(n258) );
  INVX2 U555 ( .A(B[11]), .Y(n266) );
  INVX2 U556 ( .A(B[26]), .Y(n251) );
  INVX2 U557 ( .A(B[24]), .Y(n253) );
  XNOR2X1 U558 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  AOI21X1 U559 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  XOR2XL U560 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  XNOR2XL U561 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  OAI21XL U562 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21XL U563 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U564 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
endmodule


module norm_v4_29_DW01_sub_44 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60,
         n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74,
         n75, n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n205, n206, n207, n210, n211, n212, n213, n214, n215, n216,
         n217, n218, n219, n220, n222, n224, n225, n226, n228, n230, n231,
         n232, n233, n234, n235, n236, n237, n238, n239, n240, n241, n242,
         n243, n244, n245, n246, n247, n248, n249, n250, n251, n252, n253,
         n254, n255, n256, n257, n258, n259, n260, n261, n262, n263, n264,
         n265, n266, n267, n268, n269, n270, n271, n272, n273, n274, n275,
         n276, \B[0] , n374, n375, n376, n377, n378;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U7 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U75 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  OAI21X1 U109 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U119 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  AOI21X1 U314 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  OAI21X1 U315 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  AND2X2 U316 ( .A(n377), .B(n378), .Y(n66) );
  OAI21X1 U317 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  AO21X2 U318 ( .A0(n210), .A1(n218), .B0(n211), .Y(n374) );
  AOI21X1 U319 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  AND2X2 U320 ( .A(n199), .B(n191), .Y(n375) );
  CLKNAND2X4 U321 ( .A(n374), .B(n375), .Y(n376) );
  NAND2X4 U322 ( .A(n376), .B(n190), .Y(n188) );
  NOR2X1 U323 ( .A(n78), .B(n73), .Y(n71) );
  NAND2X1 U324 ( .A(A[6]), .B(n271), .Y(n197) );
  CLKNAND2X2 U325 ( .A(A[22]), .B(n255), .Y(n79) );
  OAI21XL U326 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  OAI21X1 U327 ( .A0(n66), .A1(n56), .B0(n57), .Y(n55) );
  NAND2X2 U328 ( .A(n128), .B(n67), .Y(n377) );
  INVXL U329 ( .A(n1), .Y(n128) );
  INVXL U330 ( .A(n68), .Y(n378) );
  OAI21X1 U331 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  CLKINVX2 U332 ( .A(n66), .Y(n65) );
  NAND2XL U333 ( .A(n148), .B(n134), .Y(n132) );
  NOR2XL U334 ( .A(n206), .B(n201), .Y(n199) );
  CLKNAND2X2 U335 ( .A(A[10]), .B(n267), .Y(n176) );
  NAND2XL U336 ( .A(A[14]), .B(n263), .Y(n146) );
  NOR2X2 U337 ( .A(n162), .B(n132), .Y(n130) );
  CLKINVX2 U338 ( .A(n180), .Y(n178) );
  NAND2BXL U339 ( .AN(n95), .B(n83), .Y(n81) );
  AOI21XL U340 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  INVXL U341 ( .A(n59), .Y(n57) );
  NAND2XL U342 ( .A(n58), .B(n46), .Y(n44) );
  NAND2XL U343 ( .A(n180), .B(n168), .Y(n162) );
  AOI21X1 U344 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  AOI21XL U345 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2XL U346 ( .A(n230), .B(n104), .Y(n11) );
  NAND2BXL U347 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U348 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  INVXL U349 ( .A(n185), .Y(n241) );
  NAND2XL U350 ( .A(n234), .B(n137), .Y(n15) );
  OAI21X1 U351 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U352 ( .A(n143), .B(n136), .Y(n134) );
  INVXL U353 ( .A(n149), .Y(n151) );
  OAI21X1 U354 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NOR2X2 U355 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X1 U356 ( .A(A[28]), .B(n249), .Y(n35) );
  OAI21X2 U357 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  OAI21XL U358 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  INVXL U359 ( .A(n181), .Y(n179) );
  CLKNAND2X2 U360 ( .A(n115), .B(n101), .Y(n95) );
  CLKNAND2X2 U361 ( .A(n83), .B(n71), .Y(n69) );
  NAND2XL U362 ( .A(n115), .B(n231), .Y(n106) );
  NAND2XL U363 ( .A(n67), .B(n33), .Y(n31) );
  INVXL U364 ( .A(n162), .Y(n164) );
  INVXL U365 ( .A(n115), .Y(n113) );
  NOR2XL U366 ( .A(n212), .B(n215), .Y(n210) );
  XNOR2XL U367 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2XL U368 ( .A(n237), .B(n160), .Y(n18) );
  XNOR2XL U369 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  XNOR2XL U370 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NOR2BXL U371 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U372 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  NOR2X1 U373 ( .A(n175), .B(n170), .Y(n168) );
  NAND2XL U374 ( .A(n222), .B(n49), .Y(n3) );
  XNOR2XL U375 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U376 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U377 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U378 ( .A0(n374), .A1(n245), .B0(n205), .Y(n203) );
  AOI21XL U379 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  XNOR2XL U380 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U381 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U382 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U383 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U384 ( .A(n224), .B(n61), .Y(n5) );
  NAND2XL U385 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U386 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  XNOR2XL U387 ( .A(n374), .B(n26), .Y(DIFF[4]) );
  NAND2XL U388 ( .A(n245), .B(n207), .Y(n26) );
  AOI21XL U389 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U390 ( .A(n235), .B(n146), .Y(n16) );
  NAND2XL U391 ( .A(n76), .B(n79), .Y(n8) );
  AOI21XL U392 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U393 ( .A(n232), .B(n122), .Y(n13) );
  INVXL U394 ( .A(n196), .Y(n243) );
  NAND2XL U395 ( .A(n243), .B(n197), .Y(n24) );
  NAND2XL U396 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U397 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  NAND2XL U398 ( .A(n90), .B(n93), .Y(n10) );
  INVXL U399 ( .A(n215), .Y(n247) );
  NAND2XL U400 ( .A(n247), .B(n216), .Y(n28) );
  NOR2X1 U401 ( .A(n110), .B(n103), .Y(n101) );
  INVXL U402 ( .A(n110), .Y(n231) );
  INVXL U403 ( .A(n175), .Y(n239) );
  INVXL U404 ( .A(n53), .Y(n51) );
  INVXL U405 ( .A(n206), .Y(n245) );
  INVXL U406 ( .A(n159), .Y(n237) );
  INVXL U407 ( .A(n78), .Y(n76) );
  INVXL U408 ( .A(n126), .Y(n233) );
  INVXL U409 ( .A(n92), .Y(n90) );
  INVXL U410 ( .A(n212), .Y(n246) );
  INVXL U411 ( .A(n170), .Y(n238) );
  INVXL U412 ( .A(n193), .Y(n242) );
  INVXL U413 ( .A(n201), .Y(n244) );
  INVXL U414 ( .A(n136), .Y(n234) );
  INVXL U415 ( .A(n73), .Y(n226) );
  INVXL U416 ( .A(n87), .Y(n228) );
  INVXL U417 ( .A(n103), .Y(n230) );
  AOI2B1XL U418 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  AOI21BX1 U419 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U420 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U421 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U422 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U423 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U424 ( .A(A[27]), .B(n250), .Y(n48) );
  CLKNAND2X2 U425 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U426 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U427 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U428 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U429 ( .A(A[16]), .B(n261), .Y(n127) );
  CLKNAND2X2 U430 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U431 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U432 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2X1 U433 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U434 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U435 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U436 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U437 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U438 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U439 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U440 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U441 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U442 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U443 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U444 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U445 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U446 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U447 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U448 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U449 ( .A(B[28]), .Y(n249) );
  INVXL U450 ( .A(B[10]), .Y(n267) );
  NOR2X2 U451 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U452 ( .A(n44), .Y(n42) );
  OAI21X1 U453 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  INVX2 U454 ( .A(n58), .Y(n56) );
  AOI21X4 U455 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  AOI21X1 U456 ( .A0(n374), .A1(n199), .B0(n200), .Y(n198) );
  INVX2 U457 ( .A(n30), .Y(DIFF[30]) );
  OAI21X1 U458 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  INVX2 U459 ( .A(n188), .Y(n187) );
  INVX2 U460 ( .A(n116), .Y(n114) );
  NAND2X2 U461 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U462 ( .A(n96), .Y(n98) );
  INVX2 U463 ( .A(n45), .Y(n43) );
  OAI21X1 U464 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  NOR2X2 U465 ( .A(n92), .B(n87), .Y(n83) );
  OAI21X1 U466 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  OAI21X1 U467 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  OAI21X1 U468 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  NOR2X2 U469 ( .A(n159), .B(n154), .Y(n148) );
  OAI21X1 U470 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U471 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NOR2X2 U472 ( .A(n126), .B(n121), .Y(n115) );
  OAI21X1 U473 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  OAI21X1 U474 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NOR2X2 U475 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X2 U476 ( .A(n185), .B(n182), .Y(n180) );
  AOI21X1 U477 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  NOR2X2 U478 ( .A(n196), .B(n193), .Y(n191) );
  NOR2X2 U479 ( .A(n53), .B(n48), .Y(n46) );
  AOI21X1 U480 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  NOR2X2 U481 ( .A(n38), .B(A[29]), .Y(n36) );
  NOR2X2 U482 ( .A(n44), .B(n35), .Y(n33) );
  NAND2X2 U483 ( .A(n225), .B(n64), .Y(n6) );
  INVX2 U484 ( .A(n63), .Y(n225) );
  NAND2X2 U485 ( .A(n233), .B(n127), .Y(n14) );
  NAND2X2 U486 ( .A(n241), .B(n186), .Y(n22) );
  XNOR2X1 U487 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  NAND2X2 U488 ( .A(n238), .B(n171), .Y(n19) );
  NAND2X2 U489 ( .A(n228), .B(n88), .Y(n9) );
  AOI21X1 U490 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  AOI21X1 U491 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  NAND2X2 U492 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U493 ( .A(n244), .B(n202), .Y(n25) );
  AOI21X1 U494 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2X2 U495 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2X1 U496 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  NAND2X2 U497 ( .A(n226), .B(n74), .Y(n7) );
  INVX2 U498 ( .A(n143), .Y(n235) );
  INVX2 U499 ( .A(n182), .Y(n240) );
  INVX2 U500 ( .A(n154), .Y(n236) );
  INVX2 U501 ( .A(n60), .Y(n224) );
  INVX2 U502 ( .A(n121), .Y(n232) );
  INVX2 U503 ( .A(n207), .Y(n205) );
  INVX2 U504 ( .A(n219), .Y(n248) );
  INVX2 U505 ( .A(n48), .Y(n222) );
  INVX2 U506 ( .A(n218), .Y(n217) );
  INVX2 U507 ( .A(n160), .Y(n158) );
  INVX2 U508 ( .A(n127), .Y(n125) );
  INVX2 U509 ( .A(n54), .Y(n52) );
  INVX2 U510 ( .A(n176), .Y(n174) );
  INVX2 U511 ( .A(n93), .Y(n91) );
  INVX2 U512 ( .A(n40), .Y(n38) );
  INVX2 U513 ( .A(n79), .Y(n77) );
  NOR2X2 U514 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U515 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U516 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U517 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U518 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U519 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U520 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U521 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U522 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U523 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U524 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U525 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U526 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U527 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U528 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U529 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U530 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U531 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U532 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U533 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U534 ( .A(A[3]), .B(n274), .Y(n212) );
  NAND2X2 U535 ( .A(n248), .B(n220), .Y(n29) );
  INVX2 U536 ( .A(B[12]), .Y(n265) );
  INVX2 U537 ( .A(B[17]), .Y(n260) );
  INVX2 U538 ( .A(B[1]), .Y(n276) );
  INVX2 U539 ( .A(B[3]), .Y(n274) );
  INVX2 U540 ( .A(B[13]), .Y(n264) );
  INVX2 U541 ( .A(B[27]), .Y(n250) );
  INVX2 U542 ( .A(B[21]), .Y(n256) );
  INVX2 U543 ( .A(B[5]), .Y(n272) );
  INVX2 U544 ( .A(B[25]), .Y(n252) );
  INVX2 U545 ( .A(B[24]), .Y(n253) );
  INVX2 U546 ( .A(B[8]), .Y(n269) );
  INVX2 U547 ( .A(B[9]), .Y(n268) );
  INVX2 U548 ( .A(B[19]), .Y(n258) );
  INVX2 U549 ( .A(B[20]), .Y(n257) );
  INVX2 U550 ( .A(B[16]), .Y(n261) );
  INVX2 U551 ( .A(B[22]), .Y(n255) );
  INVX2 U552 ( .A(B[26]), .Y(n251) );
  INVX2 U553 ( .A(B[7]), .Y(n270) );
  INVX2 U554 ( .A(B[14]), .Y(n263) );
  INVX2 U555 ( .A(B[11]), .Y(n266) );
  INVX2 U556 ( .A(B[4]), .Y(n273) );
  XNOR2X1 U557 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  XNOR2X1 U558 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  XNOR2XL U559 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  AOI21X1 U560 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
endmodule


module norm_v4_29_DW01_sub_45 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n31,
         n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46, n47,
         n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n97, n101, n103, n104, n105, n106, n107,
         n110, n111, n112, n113, n114, n115, n116, n121, n122, n123, n125,
         n126, n127, n128, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n139, n140, n141, n142, n143, n146, n147, n148, n149, n151,
         n154, n155, n156, n158, n159, n160, n161, n162, n163, n164, n168,
         n169, n170, n171, n172, n174, n175, n176, n177, n178, n179, n180,
         n181, n182, n183, n184, n185, n186, n187, n188, n189, n190, n191,
         n192, n193, n194, n195, n196, n197, n198, n199, n200, n201, n202,
         n203, n205, n206, n207, n208, n209, n210, n211, n212, n213, n214,
         n215, n216, n218, n219, n220, n222, n224, n225, n226, n228, n230,
         n231, n232, n233, n234, n235, n236, n237, n238, n239, n240, n241,
         n242, n243, n244, n245, n246, n247, n248, n249, n250, n251, n252,
         n253, n254, n255, n256, n257, n258, n259, n260, n261, n262, n263,
         n264, n265, n266, n267, n268, n269, n270, n271, n272, n273, n274,
         n275, n276, \B[0] , n375, n376, n377, n378, n379, n380;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U7 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U38 ( .A0(n66), .A1(n56), .B0(n57), .Y(n55) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U61 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n376), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n376), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  OAI21X2 U314 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  AOI21X1 U315 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  AND2X2 U316 ( .A(n377), .B(n375), .Y(n96) );
  OA21X1 U317 ( .A0(n103), .A1(n111), .B0(n104), .Y(n375) );
  AOI21X1 U318 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  NOR2X2 U319 ( .A(A[14]), .B(n263), .Y(n143) );
  AOI21X1 U320 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  OA21X2 U321 ( .A0(n1), .A1(n31), .B0(n32), .Y(DIFF[30]) );
  OA21XL U322 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n376) );
  NOR2X3 U323 ( .A(A[1]), .B(n276), .Y(n219) );
  NAND2X2 U324 ( .A(A[1]), .B(n276), .Y(n220) );
  CLKNAND2X2 U325 ( .A(n101), .B(n116), .Y(n377) );
  AOI2B1X2 U326 ( .A1N(n96), .A0(n83), .B0(n86), .Y(n82) );
  OAI21XL U327 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  INVX2 U328 ( .A(n96), .Y(n378) );
  INVXL U329 ( .A(n1), .Y(n128) );
  OAI21X1 U330 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  NAND2X2 U331 ( .A(n180), .B(n168), .Y(n162) );
  NOR2X2 U332 ( .A(n196), .B(n193), .Y(n191) );
  NAND2X2 U333 ( .A(n199), .B(n191), .Y(n189) );
  INVXL U334 ( .A(n69), .Y(n379) );
  AOI21XL U335 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  NAND2X2 U336 ( .A(n378), .B(n379), .Y(n380) );
  CLKNAND2X2 U337 ( .A(n380), .B(n70), .Y(n68) );
  CLKNAND2X2 U338 ( .A(A[10]), .B(n267), .Y(n176) );
  NAND2X2 U339 ( .A(n83), .B(n71), .Y(n69) );
  AOI21X2 U340 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  CLKINVX2 U341 ( .A(n180), .Y(n178) );
  INVX1 U342 ( .A(n66), .Y(n65) );
  NOR2XL U343 ( .A(n212), .B(n215), .Y(n210) );
  NAND2XL U344 ( .A(n148), .B(n134), .Y(n132) );
  NOR2XL U345 ( .A(n63), .B(n60), .Y(n58) );
  CLKNAND2X2 U346 ( .A(A[14]), .B(n263), .Y(n146) );
  NOR2X2 U347 ( .A(A[13]), .B(n264), .Y(n154) );
  NAND2XL U348 ( .A(n97), .B(n83), .Y(n81) );
  NOR2X2 U349 ( .A(n162), .B(n132), .Y(n130) );
  NAND2XL U350 ( .A(n237), .B(n160), .Y(n18) );
  OAI21X1 U351 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  NAND2XL U352 ( .A(n51), .B(n54), .Y(n4) );
  INVXL U353 ( .A(n185), .Y(n241) );
  OAI21X1 U354 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  NOR2X2 U355 ( .A(n143), .B(n136), .Y(n134) );
  NOR2X2 U356 ( .A(n78), .B(n73), .Y(n71) );
  OAI21X1 U357 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  INVXL U358 ( .A(n149), .Y(n151) );
  NAND2BXL U359 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U360 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  OAI21X1 U361 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NAND2XL U362 ( .A(A[6]), .B(n271), .Y(n197) );
  NOR2X1 U363 ( .A(A[28]), .B(n249), .Y(n35) );
  NAND2X1 U364 ( .A(A[22]), .B(n255), .Y(n79) );
  INVXL U365 ( .A(n44), .Y(n42) );
  OAI21X2 U366 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  INVXL U367 ( .A(n181), .Y(n179) );
  INVXL U368 ( .A(n188), .Y(n187) );
  CLKNAND2X2 U369 ( .A(n115), .B(n101), .Y(n95) );
  NAND2XL U370 ( .A(n67), .B(n33), .Y(n31) );
  NAND2XL U371 ( .A(n115), .B(n231), .Y(n106) );
  INVXL U372 ( .A(n162), .Y(n164) );
  INVXL U373 ( .A(n115), .Y(n113) );
  XNOR2XL U374 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  XNOR2XL U375 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NOR2BXL U376 ( .AN(n148), .B(n143), .Y(n141) );
  AOI21X1 U377 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21XL U378 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  NOR2X1 U379 ( .A(n175), .B(n170), .Y(n168) );
  NOR2X1 U380 ( .A(n53), .B(n48), .Y(n46) );
  AOI21XL U381 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  XNOR2XL U382 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  NAND2XL U383 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U384 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  AOI21XL U385 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  XNOR2XL U386 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  NAND2XL U387 ( .A(n239), .B(n176), .Y(n20) );
  XNOR2XL U388 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  AOI21XL U389 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  NAND2XL U390 ( .A(n236), .B(n155), .Y(n17) );
  XNOR2XL U391 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  INVXL U392 ( .A(n196), .Y(n243) );
  NAND2XL U393 ( .A(n243), .B(n197), .Y(n24) );
  XNOR2XL U394 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  XNOR2XL U395 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U396 ( .A(n76), .B(n79), .Y(n8) );
  AOI21XL U397 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U398 ( .A(n235), .B(n146), .Y(n16) );
  XNOR2XL U399 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  NAND2XL U400 ( .A(n245), .B(n207), .Y(n26) );
  XNOR2XL U401 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  NAND2XL U402 ( .A(n232), .B(n122), .Y(n13) );
  XNOR2XL U403 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U404 ( .A(n90), .B(n93), .Y(n10) );
  NAND2XL U405 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U406 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  INVXL U407 ( .A(n215), .Y(n247) );
  NAND2XL U408 ( .A(n247), .B(n216), .Y(n28) );
  NOR2X1 U409 ( .A(n110), .B(n103), .Y(n101) );
  INVXL U410 ( .A(n110), .Y(n231) );
  INVXL U411 ( .A(n175), .Y(n239) );
  INVXL U412 ( .A(n53), .Y(n51) );
  INVXL U413 ( .A(n78), .Y(n76) );
  INVXL U414 ( .A(n159), .Y(n237) );
  INVXL U415 ( .A(n206), .Y(n245) );
  INVXL U416 ( .A(n126), .Y(n233) );
  INVXL U417 ( .A(n92), .Y(n90) );
  INVXL U418 ( .A(n212), .Y(n246) );
  INVXL U419 ( .A(n48), .Y(n222) );
  INVXL U420 ( .A(n193), .Y(n242) );
  INVXL U421 ( .A(n170), .Y(n238) );
  INVXL U422 ( .A(n73), .Y(n226) );
  INVXL U423 ( .A(n201), .Y(n244) );
  INVXL U424 ( .A(n136), .Y(n234) );
  INVXL U425 ( .A(n60), .Y(n224) );
  INVXL U426 ( .A(n87), .Y(n228) );
  INVXL U427 ( .A(n103), .Y(n230) );
  AOI2B1XL U428 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U429 ( .A(n143), .Y(n235) );
  AOI21BX1 U430 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  NOR2X2 U431 ( .A(A[17]), .B(n260), .Y(n121) );
  NOR2X2 U432 ( .A(A[9]), .B(n268), .Y(n182) );
  NAND2XL U433 ( .A(n248), .B(n220), .Y(n29) );
  CLKNAND2X2 U434 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U435 ( .A(A[20]), .B(n257), .Y(n93) );
  CLKNAND2X2 U436 ( .A(A[26]), .B(n251), .Y(n54) );
  CLKNAND2X2 U437 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U438 ( .A(A[16]), .B(n261), .Y(n127) );
  CLKNAND2X2 U439 ( .A(A[8]), .B(n269), .Y(n186) );
  CLKNAND2X2 U440 ( .A(A[24]), .B(n253), .Y(n64) );
  NAND2X1 U441 ( .A(A[2]), .B(n275), .Y(n216) );
  NAND2X1 U442 ( .A(A[18]), .B(n259), .Y(n111) );
  CLKNAND2X2 U443 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U444 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U445 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U446 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U447 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U448 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U449 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U450 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U451 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U452 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U453 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U454 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U455 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U456 ( .A(A[19]), .B(n258), .Y(n104) );
  INVXL U457 ( .A(B[28]), .Y(n249) );
  INVXL U458 ( .A(B[10]), .Y(n267) );
  NOR2X2 U459 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U460 ( .A(n95), .Y(n97) );
  OAI21X1 U461 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  INVX2 U462 ( .A(n59), .Y(n57) );
  INVX2 U463 ( .A(n58), .Y(n56) );
  AOI21X4 U464 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  AOI21X1 U465 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U466 ( .A(n58), .B(n46), .Y(n44) );
  INVX2 U467 ( .A(n209), .Y(n208) );
  NAND2X2 U468 ( .A(n141), .B(n164), .Y(n139) );
  INVX2 U469 ( .A(n45), .Y(n43) );
  INVX2 U470 ( .A(n116), .Y(n114) );
  NOR2X2 U471 ( .A(n126), .B(n121), .Y(n115) );
  NOR2X2 U472 ( .A(n159), .B(n154), .Y(n148) );
  NOR2X2 U473 ( .A(n92), .B(n87), .Y(n83) );
  NOR2X2 U474 ( .A(n185), .B(n182), .Y(n180) );
  OAI21X1 U475 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  OAI21X2 U476 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  AOI21X1 U477 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  OAI21X1 U478 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  OAI21X1 U479 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  OAI21X1 U480 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  NAND2X2 U481 ( .A(n224), .B(n61), .Y(n5) );
  NOR2X2 U482 ( .A(n44), .B(n35), .Y(n33) );
  AOI21X1 U483 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2X2 U484 ( .A(n238), .B(n171), .Y(n19) );
  AOI21X1 U485 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NOR2X2 U486 ( .A(n38), .B(A[29]), .Y(n36) );
  NAND2X2 U487 ( .A(n233), .B(n127), .Y(n14) );
  NAND2X2 U488 ( .A(n225), .B(n64), .Y(n6) );
  INVX2 U489 ( .A(n63), .Y(n225) );
  NAND2X2 U490 ( .A(n241), .B(n186), .Y(n22) );
  NAND2X2 U491 ( .A(n226), .B(n74), .Y(n7) );
  AOI21X1 U492 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  NAND2X2 U493 ( .A(n242), .B(n194), .Y(n23) );
  NAND2X2 U494 ( .A(n230), .B(n104), .Y(n11) );
  NAND2X2 U495 ( .A(n234), .B(n137), .Y(n15) );
  NAND2X2 U496 ( .A(n222), .B(n49), .Y(n3) );
  NAND2X2 U497 ( .A(n244), .B(n202), .Y(n25) );
  NAND2X2 U498 ( .A(n228), .B(n88), .Y(n9) );
  AOI21X1 U499 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NAND2X2 U500 ( .A(n246), .B(n213), .Y(n27) );
  INVX2 U501 ( .A(n182), .Y(n240) );
  INVX2 U502 ( .A(n160), .Y(n158) );
  INVX2 U503 ( .A(n154), .Y(n236) );
  INVX2 U504 ( .A(n121), .Y(n232) );
  INVX2 U505 ( .A(n176), .Y(n174) );
  INVX2 U506 ( .A(n219), .Y(n248) );
  INVX2 U507 ( .A(n127), .Y(n125) );
  INVX2 U508 ( .A(n207), .Y(n205) );
  INVX2 U509 ( .A(n93), .Y(n91) );
  INVX2 U510 ( .A(n79), .Y(n77) );
  INVX2 U511 ( .A(n40), .Y(n38) );
  INVX2 U512 ( .A(n54), .Y(n52) );
  NOR2X2 U513 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U514 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U515 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U516 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U517 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U518 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U519 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U520 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U521 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U522 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U523 ( .A(A[26]), .B(n251), .Y(n53) );
  NOR2X2 U524 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U525 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U526 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U527 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U528 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U529 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U530 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U531 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U532 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U533 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U534 ( .A(A[11]), .B(n266), .Y(n170) );
  INVX2 U535 ( .A(B[1]), .Y(n276) );
  INVX2 U536 ( .A(B[3]), .Y(n274) );
  INVX2 U537 ( .A(B[13]), .Y(n264) );
  INVX2 U538 ( .A(B[21]), .Y(n256) );
  INVX2 U539 ( .A(B[25]), .Y(n252) );
  INVX2 U540 ( .A(B[11]), .Y(n266) );
  INVX2 U541 ( .A(B[17]), .Y(n260) );
  INVX2 U542 ( .A(B[7]), .Y(n270) );
  INVX2 U543 ( .A(B[27]), .Y(n250) );
  INVX2 U544 ( .A(B[9]), .Y(n268) );
  INVX2 U545 ( .A(B[20]), .Y(n257) );
  INVX2 U546 ( .A(B[16]), .Y(n261) );
  INVX2 U547 ( .A(B[22]), .Y(n255) );
  INVX2 U548 ( .A(B[26]), .Y(n251) );
  INVX2 U549 ( .A(B[24]), .Y(n253) );
  INVX2 U550 ( .A(B[4]), .Y(n273) );
  INVX2 U551 ( .A(B[14]), .Y(n263) );
  INVX2 U552 ( .A(B[5]), .Y(n272) );
  INVX2 U553 ( .A(B[19]), .Y(n258) );
  INVX2 U554 ( .A(B[8]), .Y(n269) );
  INVX2 U555 ( .A(B[12]), .Y(n265) );
  OAI21XL U556 ( .A0(n1), .A1(n113), .B0(n114), .Y(n112) );
  OAI21XL U557 ( .A0(n1), .A1(n106), .B0(n107), .Y(n105) );
  NOR2X2 U558 ( .A(n206), .B(n201), .Y(n199) );
  XNOR2X1 U559 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  XNOR2X1 U560 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  AOI21X1 U561 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
endmodule


module norm_v4_29_DW01_sub_35 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n58, n59, n60, n61,
         n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75,
         n76, n77, n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n98, n101, n102, n103, n104, n105, n106,
         n107, n110, n111, n112, n113, n114, n115, n116, n121, n122, n123,
         n125, n126, n127, n128, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n146, n147, n148, n149,
         n151, n154, n155, n156, n158, n159, n160, n161, n162, n163, n164,
         n168, n169, n170, n171, n172, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n222, n224, n225, n226,
         n228, n230, n231, n232, n233, n234, n235, n236, n237, n238, n239,
         n240, n241, n242, n243, n244, n245, n246, n247, n248, n249, n250,
         n251, n252, n253, n254, n255, n256, n257, n258, n259, n260, n261,
         n262, n263, n264, n265, n266, n267, n268, n269, n270, n271, n272,
         n273, n274, n275, n276, \B[0] , n374;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  XOR2X1 U74 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  XOR2X1 U118 ( .A(n123), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U148 ( .A0(n136), .A1(n146), .B0(n137), .Y(n135) );
  XOR2X1 U153 ( .A(n147), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U154 ( .A0(n187), .A1(n139), .B0(n140), .Y(n138) );
  OAI21X1 U158 ( .A0(n151), .A1(n143), .B0(n146), .Y(n142) );
  XOR2X1 U165 ( .A(n156), .B(n17), .Y(DIFF[13]) );
  XOR2X1 U185 ( .A(n172), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U208 ( .A0(n187), .A1(n178), .B0(n179), .Y(n177) );
  XOR2X1 U217 ( .A(n187), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U218 ( .A0(n187), .A1(n185), .B0(n186), .Y(n184) );
  OAI21X1 U229 ( .A0(n193), .A1(n197), .B0(n194), .Y(n192) );
  XOR2X1 U234 ( .A(n198), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U235 ( .A0(n198), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U240 ( .A(n203), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U265 ( .A(n217), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U266 ( .A0(n217), .A1(n215), .B0(n216), .Y(n214) );
  XOR2X1 U271 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U309 ( .A(B[2]), .Y(n275) );
  INVXL U310 ( .A(B[15]), .Y(n262) );
  INVXL U311 ( .A(B[18]), .Y(n259) );
  INVXL U312 ( .A(B[23]), .Y(n254) );
  INVXL U313 ( .A(B[6]), .Y(n271) );
  INVX2 U314 ( .A(n1), .Y(n128) );
  INVX2 U315 ( .A(n128), .Y(n374) );
  AOI21X1 U316 ( .A0(n101), .A1(n116), .B0(n102), .Y(n96) );
  OAI21X1 U317 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  OAI21X1 U318 ( .A0(n121), .A1(n127), .B0(n122), .Y(n116) );
  AOI21X2 U319 ( .A0(n188), .A1(n130), .B0(n131), .Y(n1) );
  INVXL U320 ( .A(n116), .Y(n114) );
  NAND2BX1 U321 ( .AN(n95), .B(n83), .Y(n81) );
  OAI21XL U322 ( .A0(n374), .A1(n81), .B0(n82), .Y(n80) );
  NOR2X1 U323 ( .A(n110), .B(n103), .Y(n101) );
  OAI21XL U324 ( .A0(n374), .A1(n106), .B0(n107), .Y(n105) );
  XNOR2XL U325 ( .A(n112), .B(n12), .Y(DIFF[18]) );
  OAI21XL U326 ( .A0(n374), .A1(n113), .B0(n114), .Y(n112) );
  NOR2X1 U327 ( .A(n175), .B(n170), .Y(n168) );
  CLKNAND2X2 U328 ( .A(A[10]), .B(n267), .Y(n176) );
  NAND2X1 U329 ( .A(A[18]), .B(n259), .Y(n111) );
  OAI21X2 U330 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  NOR2XL U331 ( .A(n196), .B(n193), .Y(n191) );
  NOR2X2 U332 ( .A(n162), .B(n132), .Y(n130) );
  NAND2X2 U333 ( .A(n148), .B(n134), .Y(n132) );
  NOR2X2 U334 ( .A(n53), .B(n48), .Y(n46) );
  NAND2XL U335 ( .A(A[6]), .B(n271), .Y(n197) );
  NAND2X1 U336 ( .A(A[24]), .B(n253), .Y(n64) );
  OAI21XL U337 ( .A0(n187), .A1(n162), .B0(n163), .Y(n161) );
  OAI21X1 U338 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  NOR2X1 U339 ( .A(n92), .B(n87), .Y(n83) );
  AOI21X1 U340 ( .A0(n94), .A1(n90), .B0(n91), .Y(n89) );
  NOR2XL U341 ( .A(n185), .B(n182), .Y(n180) );
  NOR2XL U342 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X1 U343 ( .A(n206), .B(n201), .Y(n199) );
  NOR2XL U344 ( .A(n159), .B(n154), .Y(n148) );
  NAND2XL U345 ( .A(n245), .B(n207), .Y(n26) );
  CLKNAND2X2 U346 ( .A(A[22]), .B(n255), .Y(n79) );
  NOR2X2 U347 ( .A(A[17]), .B(n260), .Y(n121) );
  NAND2XL U348 ( .A(A[9]), .B(n268), .Y(n183) );
  NAND2XL U349 ( .A(n248), .B(n220), .Y(n29) );
  OAI21BX1 U350 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  OAI21X1 U351 ( .A0(n163), .A1(n132), .B0(n133), .Y(n131) );
  INVX2 U352 ( .A(n30), .Y(DIFF[30]) );
  INVX2 U353 ( .A(n159), .Y(n237) );
  OAI21X1 U354 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  OAI21X1 U355 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  OAI21X1 U356 ( .A0(n170), .A1(n176), .B0(n171), .Y(n169) );
  OAI21X1 U357 ( .A0(n154), .A1(n160), .B0(n155), .Y(n149) );
  NAND2BXL U358 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U359 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  OAI21X1 U360 ( .A0(n182), .A1(n186), .B0(n183), .Y(n181) );
  NAND2XL U361 ( .A(n226), .B(n74), .Y(n7) );
  NOR2X2 U362 ( .A(n78), .B(n73), .Y(n71) );
  AOI21XL U363 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  OAI21X1 U364 ( .A0(n201), .A1(n207), .B0(n202), .Y(n200) );
  OAI21X1 U365 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  INVXL U366 ( .A(n149), .Y(n151) );
  NOR2X2 U367 ( .A(n126), .B(n121), .Y(n115) );
  OAI21X1 U368 ( .A0(n219), .A1(\B[0] ), .B0(n220), .Y(n218) );
  NAND2X2 U369 ( .A(A[16]), .B(n261), .Y(n127) );
  NAND2X2 U370 ( .A(A[20]), .B(n257), .Y(n93) );
  NAND2X2 U371 ( .A(A[8]), .B(n269), .Y(n186) );
  INVXL U372 ( .A(n44), .Y(n42) );
  AOI21X1 U373 ( .A0(n128), .A1(n67), .B0(n68), .Y(n66) );
  OAI21XL U374 ( .A0(n374), .A1(n95), .B0(n96), .Y(n94) );
  INVXL U375 ( .A(n162), .Y(n164) );
  INVXL U376 ( .A(n45), .Y(n43) );
  OAI21XL U377 ( .A0(n103), .A1(n111), .B0(n104), .Y(n102) );
  AOI21X1 U378 ( .A0(n168), .A1(n181), .B0(n169), .Y(n163) );
  CLKNAND2X2 U379 ( .A(n199), .B(n191), .Y(n189) );
  NOR2X1 U380 ( .A(n212), .B(n215), .Y(n210) );
  NOR2BXL U381 ( .AN(n148), .B(n143), .Y(n141) );
  XNOR2XL U382 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U383 ( .A(n239), .B(n176), .Y(n20) );
  AOI21XL U384 ( .A0(n177), .A1(n239), .B0(n174), .Y(n172) );
  NAND2XL U385 ( .A(n238), .B(n171), .Y(n19) );
  NAND2XL U386 ( .A(n230), .B(n104), .Y(n11) );
  XNOR2XL U387 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  NAND2XL U388 ( .A(n240), .B(n183), .Y(n21) );
  XNOR2XL U389 ( .A(n184), .B(n21), .Y(DIFF[9]) );
  NAND2XL U390 ( .A(n236), .B(n155), .Y(n17) );
  NAND2XL U391 ( .A(n234), .B(n137), .Y(n15) );
  XNOR2XL U392 ( .A(n138), .B(n15), .Y(DIFF[15]) );
  AOI21XL U393 ( .A0(n128), .A1(n233), .B0(n125), .Y(n123) );
  NAND2XL U394 ( .A(n232), .B(n122), .Y(n13) );
  NAND2XL U395 ( .A(n242), .B(n194), .Y(n23) );
  XNOR2XL U396 ( .A(n195), .B(n23), .Y(DIFF[7]) );
  XNOR2XL U397 ( .A(n161), .B(n18), .Y(DIFF[12]) );
  NAND2XL U398 ( .A(n237), .B(n160), .Y(n18) );
  XNOR2XL U399 ( .A(n128), .B(n14), .Y(DIFF[16]) );
  NAND2XL U400 ( .A(n233), .B(n127), .Y(n14) );
  INVXL U401 ( .A(n185), .Y(n241) );
  NAND2XL U402 ( .A(n241), .B(n186), .Y(n22) );
  AOI21XL U403 ( .A0(n208), .A1(n245), .B0(n205), .Y(n203) );
  NAND2XL U404 ( .A(n244), .B(n202), .Y(n25) );
  NAND2XL U405 ( .A(n231), .B(n111), .Y(n12) );
  XNOR2XL U406 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  NAND2XL U407 ( .A(n224), .B(n61), .Y(n5) );
  OAI21XL U408 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  AOI21XL U409 ( .A0(n161), .A1(n148), .B0(n149), .Y(n147) );
  NAND2XL U410 ( .A(n235), .B(n146), .Y(n16) );
  XNOR2XL U411 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U412 ( .A(n76), .B(n79), .Y(n8) );
  NAND2XL U413 ( .A(n246), .B(n213), .Y(n27) );
  XNOR2XL U414 ( .A(n214), .B(n27), .Y(DIFF[3]) );
  INVXL U415 ( .A(n196), .Y(n243) );
  NAND2XL U416 ( .A(n243), .B(n197), .Y(n24) );
  XNOR2XL U417 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U418 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U419 ( .A(n225), .B(n64), .Y(n6) );
  INVXL U420 ( .A(n63), .Y(n225) );
  XNOR2XL U421 ( .A(n208), .B(n26), .Y(DIFF[4]) );
  INVXL U422 ( .A(n215), .Y(n247) );
  NAND2XL U423 ( .A(n247), .B(n216), .Y(n28) );
  AOI2B1XL U424 ( .A1N(n163), .A0(n141), .B0(n142), .Y(n140) );
  INVXL U425 ( .A(n110), .Y(n231) );
  INVXL U426 ( .A(n143), .Y(n235) );
  INVXL U427 ( .A(n175), .Y(n239) );
  INVXL U428 ( .A(n126), .Y(n233) );
  INVXL U429 ( .A(n92), .Y(n90) );
  INVXL U430 ( .A(n53), .Y(n51) );
  INVXL U431 ( .A(n78), .Y(n76) );
  INVXL U432 ( .A(n206), .Y(n245) );
  INVXL U433 ( .A(n212), .Y(n246) );
  INVXL U434 ( .A(n170), .Y(n238) );
  INVXL U435 ( .A(n182), .Y(n240) );
  INVXL U436 ( .A(n103), .Y(n230) );
  INVXL U437 ( .A(n154), .Y(n236) );
  INVXL U438 ( .A(n193), .Y(n242) );
  INVXL U439 ( .A(n136), .Y(n234) );
  INVXL U440 ( .A(n48), .Y(n222) );
  INVXL U441 ( .A(n87), .Y(n228) );
  INVXL U442 ( .A(n73), .Y(n226) );
  INVXL U443 ( .A(n201), .Y(n244) );
  INVXL U444 ( .A(n60), .Y(n224) );
  AOI21BX1 U445 ( .A0(n116), .A1(n231), .B0N(n111), .Y(n107) );
  CLKNAND2X2 U446 ( .A(A[12]), .B(n265), .Y(n160) );
  CLKNAND2X2 U447 ( .A(A[4]), .B(n273), .Y(n207) );
  CLKNAND2X2 U448 ( .A(A[26]), .B(n251), .Y(n54) );
  NAND2XL U449 ( .A(A[14]), .B(n263), .Y(n146) );
  CLKNAND2X2 U450 ( .A(A[28]), .B(n249), .Y(n40) );
  NAND2XL U451 ( .A(A[17]), .B(n260), .Y(n122) );
  NAND2XL U452 ( .A(A[11]), .B(n266), .Y(n171) );
  NAND2XL U453 ( .A(A[13]), .B(n264), .Y(n155) );
  NAND2XL U454 ( .A(A[27]), .B(n250), .Y(n49) );
  NAND2XL U455 ( .A(A[21]), .B(n256), .Y(n88) );
  NAND2XL U456 ( .A(A[19]), .B(n258), .Y(n104) );
  NAND2XL U457 ( .A(A[15]), .B(n262), .Y(n137) );
  NAND2XL U458 ( .A(A[5]), .B(n272), .Y(n202) );
  NAND2XL U459 ( .A(A[7]), .B(n270), .Y(n194) );
  NAND2XL U460 ( .A(A[23]), .B(n254), .Y(n74) );
  NAND2XL U461 ( .A(A[3]), .B(n274), .Y(n213) );
  NAND2XL U462 ( .A(A[25]), .B(n252), .Y(n61) );
  NAND2XL U463 ( .A(A[1]), .B(n276), .Y(n220) );
  INVXL U464 ( .A(B[28]), .Y(n249) );
  INVXL U465 ( .A(B[10]), .Y(n267) );
  NOR2X2 U466 ( .A(n95), .B(n69), .Y(n67) );
  INVX2 U467 ( .A(n66), .Y(n65) );
  INVX2 U468 ( .A(n181), .Y(n179) );
  INVX2 U469 ( .A(n180), .Y(n178) );
  AOI21X1 U470 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  NAND2X2 U471 ( .A(n115), .B(n101), .Y(n95) );
  NAND2X2 U472 ( .A(n180), .B(n168), .Y(n162) );
  INVX2 U473 ( .A(n58), .Y(n56) );
  NAND2X2 U474 ( .A(n58), .B(n46), .Y(n44) );
  NAND2X2 U475 ( .A(n83), .B(n71), .Y(n69) );
  AOI21X1 U476 ( .A0(n208), .A1(n199), .B0(n200), .Y(n198) );
  NAND2X2 U477 ( .A(n115), .B(n231), .Y(n106) );
  INVX2 U478 ( .A(n188), .Y(n187) );
  INVX2 U479 ( .A(n115), .Y(n113) );
  INVX2 U480 ( .A(n209), .Y(n208) );
  NAND2X2 U481 ( .A(n141), .B(n164), .Y(n139) );
  NAND2X2 U482 ( .A(n67), .B(n33), .Y(n31) );
  INVX2 U483 ( .A(n96), .Y(n98) );
  OAI21X1 U484 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  AOI21X1 U485 ( .A0(n191), .A1(n200), .B0(n192), .Y(n190) );
  AOI21X1 U486 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21X1 U487 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U488 ( .A(n38), .B(A[29]), .Y(n36) );
  AOI21X1 U489 ( .A0(n210), .A1(n218), .B0(n211), .Y(n209) );
  OAI21X1 U490 ( .A0(n212), .A1(n216), .B0(n213), .Y(n211) );
  XNOR2X1 U491 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  AOI21X1 U492 ( .A0(n134), .A1(n149), .B0(n135), .Y(n133) );
  NOR2X2 U493 ( .A(n44), .B(n35), .Y(n33) );
  NAND2X2 U494 ( .A(n90), .B(n93), .Y(n10) );
  NOR2X2 U495 ( .A(n143), .B(n136), .Y(n134) );
  NAND2X2 U496 ( .A(n222), .B(n49), .Y(n3) );
  NAND2X2 U497 ( .A(n228), .B(n88), .Y(n9) );
  AOI21X1 U498 ( .A0(n161), .A1(n237), .B0(n158), .Y(n156) );
  INVX2 U499 ( .A(n121), .Y(n232) );
  INVX2 U500 ( .A(n218), .Y(n217) );
  INVX2 U501 ( .A(n219), .Y(n248) );
  INVX2 U502 ( .A(n207), .Y(n205) );
  INVX2 U503 ( .A(n160), .Y(n158) );
  INVX2 U504 ( .A(n127), .Y(n125) );
  INVX2 U505 ( .A(n176), .Y(n174) );
  INVX2 U506 ( .A(n93), .Y(n91) );
  INVX2 U507 ( .A(n54), .Y(n52) );
  INVX2 U508 ( .A(n40), .Y(n38) );
  INVX2 U509 ( .A(n79), .Y(n77) );
  NOR2X2 U510 ( .A(A[13]), .B(n264), .Y(n154) );
  NOR2X2 U511 ( .A(A[14]), .B(n263), .Y(n143) );
  NOR2X2 U512 ( .A(A[11]), .B(n266), .Y(n170) );
  NOR2X2 U513 ( .A(A[19]), .B(n258), .Y(n103) );
  NOR2X2 U514 ( .A(A[8]), .B(n269), .Y(n185) );
  NOR2X2 U515 ( .A(A[28]), .B(n249), .Y(n35) );
  NOR2X2 U516 ( .A(A[10]), .B(n267), .Y(n175) );
  NOR2X2 U517 ( .A(A[24]), .B(n253), .Y(n63) );
  NOR2X2 U518 ( .A(A[23]), .B(n254), .Y(n73) );
  NOR2X2 U519 ( .A(A[15]), .B(n262), .Y(n136) );
  NOR2X2 U520 ( .A(A[7]), .B(n270), .Y(n193) );
  NOR2X2 U521 ( .A(A[2]), .B(n275), .Y(n215) );
  NOR2X2 U522 ( .A(A[6]), .B(n271), .Y(n196) );
  NOR2X2 U523 ( .A(A[20]), .B(n257), .Y(n92) );
  NOR2X2 U524 ( .A(A[12]), .B(n265), .Y(n159) );
  NOR2X2 U525 ( .A(A[16]), .B(n261), .Y(n126) );
  NOR2X2 U526 ( .A(A[18]), .B(n259), .Y(n110) );
  NOR2X2 U527 ( .A(A[22]), .B(n255), .Y(n78) );
  NOR2X2 U528 ( .A(A[4]), .B(n273), .Y(n206) );
  NOR2X2 U529 ( .A(A[25]), .B(n252), .Y(n60) );
  NOR2X2 U530 ( .A(A[9]), .B(n268), .Y(n182) );
  NOR2X2 U531 ( .A(A[5]), .B(n272), .Y(n201) );
  NOR2X2 U532 ( .A(A[27]), .B(n250), .Y(n48) );
  NOR2X2 U533 ( .A(A[21]), .B(n256), .Y(n87) );
  NOR2X2 U534 ( .A(A[3]), .B(n274), .Y(n212) );
  NOR2X2 U535 ( .A(A[1]), .B(n276), .Y(n219) );
  NOR2X2 U536 ( .A(A[26]), .B(n251), .Y(n53) );
  NAND2X2 U537 ( .A(A[2]), .B(n275), .Y(n216) );
  INVX2 U538 ( .A(B[26]), .Y(n251) );
  INVX2 U539 ( .A(B[1]), .Y(n276) );
  INVX2 U540 ( .A(B[3]), .Y(n274) );
  INVX2 U541 ( .A(B[27]), .Y(n250) );
  INVX2 U542 ( .A(B[21]), .Y(n256) );
  INVX2 U543 ( .A(B[5]), .Y(n272) );
  INVX2 U544 ( .A(B[9]), .Y(n268) );
  INVX2 U545 ( .A(B[17]), .Y(n260) );
  INVX2 U546 ( .A(B[25]), .Y(n252) );
  INVX2 U547 ( .A(B[20]), .Y(n257) );
  INVX2 U548 ( .A(B[16]), .Y(n261) );
  INVX2 U549 ( .A(B[22]), .Y(n255) );
  INVX2 U550 ( .A(B[7]), .Y(n270) );
  INVX2 U551 ( .A(B[13]), .Y(n264) );
  INVX2 U552 ( .A(B[14]), .Y(n263) );
  INVX2 U553 ( .A(B[8]), .Y(n269) );
  INVX2 U554 ( .A(B[19]), .Y(n258) );
  INVX2 U555 ( .A(B[12]), .Y(n265) );
  INVX2 U556 ( .A(B[11]), .Y(n266) );
  INVX2 U557 ( .A(B[4]), .Y(n273) );
  INVX2 U558 ( .A(B[24]), .Y(n253) );
  XNOR2XL U559 ( .A(n177), .B(n20), .Y(DIFF[10]) );
  AOI21X1 U560 ( .A0(n80), .A1(n76), .B0(n77), .Y(n75) );
  AOI21X1 U561 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  AOI21X1 U562 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29_DW01_sub_47 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n53, n54, n55, n56, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76,
         n78, n79, n80, n81, n82, n83, n86, n87, n88, n89, n90, n92, n93, n94,
         n95, n96, n98, n101, n102, n103, n104, n105, n108, n109, n110, n111,
         n112, n113, n114, n115, n116, n117, n120, n121, n122, n124, n125,
         n126, n127, n128, n129, n130, n131, n132, n133, n134, n135, n136,
         n137, n140, n141, n142, n143, n144, n145, n146, n147, n148, n151,
         n152, n153, n154, n155, n156, n157, n158, n161, n162, n163, n164,
         n165, n168, n169, n170, n171, n172, n173, n174, n175, n176, n177,
         n178, n179, n180, n181, n182, n183, n184, n185, n186, n187, n188,
         n189, n190, n191, n192, n193, n194, n195, n196, n199, n200, n201,
         n202, n203, n204, n205, n206, n207, n208, n209, n210, n211, n212,
         n213, n215, n217, n218, n219, n221, n223, n224, n225, n226, n227,
         n228, n229, n230, n231, n232, n233, n234, n235, n236, n237, n238,
         n239, n240, n241, n242, n243, n244, n245, n246, n247, n248, n249,
         n250, n251, n252, n253, n254, n255, n256, n257, n258, n259, n260,
         n261, n262, n263, n264, n265, n266, n267, n268, n269, \B[0] , n367,
         n368, n369, n370;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U48 ( .A0(n66), .A1(n63), .B0(n64), .Y(n62) );
  XOR2X1 U53 ( .A(n75), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U95 ( .A0(n1), .A1(n95), .B0(n96), .Y(n94) );
  XOR2X1 U116 ( .A(n117), .B(n13), .Y(DIFF[17]) );
  OAI21X1 U117 ( .A0(n1), .A1(n111), .B0(n112), .Y(n110) );
  OAI21X1 U142 ( .A0(n130), .A1(n140), .B0(n131), .Y(n129) );
  OAI21X1 U148 ( .A0(n180), .A1(n133), .B0(n134), .Y(n132) );
  OAI21X1 U152 ( .A0(n143), .A1(n137), .B0(n140), .Y(n136) );
  XOR2X1 U159 ( .A(n148), .B(n17), .Y(DIFF[13]) );
  OAI21X1 U160 ( .A0(n153), .A1(n142), .B0(n143), .Y(n141) );
  XOR2X1 U169 ( .A(n153), .B(n18), .Y(DIFF[12]) );
  XOR2X1 U177 ( .A(n165), .B(n19), .Y(DIFF[11]) );
  OAI21X1 U201 ( .A0(n180), .A1(n171), .B0(n172), .Y(n170) );
  XOR2X1 U210 ( .A(n180), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U211 ( .A0(n180), .A1(n178), .B0(n179), .Y(n177) );
  OAI21X1 U222 ( .A0(n186), .A1(n190), .B0(n187), .Y(n185) );
  XOR2X1 U227 ( .A(n191), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U228 ( .A0(n191), .A1(n189), .B0(n190), .Y(n188) );
  XOR2X1 U233 ( .A(n196), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U258 ( .A(n210), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U259 ( .A0(n210), .A1(n208), .B0(n209), .Y(n207) );
  XOR2X1 U264 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U302 ( .A(n156), .Y(n158) );
  OAI21X4 U303 ( .A0(n156), .A1(n126), .B0(n127), .Y(n125) );
  AOI21X4 U304 ( .A0(n161), .A1(n174), .B0(n162), .Y(n156) );
  INVXL U305 ( .A(B[11]), .Y(n259) );
  INVXL U306 ( .A(B[17]), .Y(n253) );
  INVX1 U307 ( .A(B[15]), .Y(n255) );
  INVXL U308 ( .A(B[16]), .Y(n254) );
  INVXL U309 ( .A(B[24]), .Y(n246) );
  INVXL U310 ( .A(B[9]), .Y(n261) );
  INVXL U311 ( .A(B[18]), .Y(n252) );
  INVXL U312 ( .A(B[23]), .Y(n247) );
  INVXL U313 ( .A(B[6]), .Y(n264) );
  CLKINVX4 U314 ( .A(n30), .Y(DIFF[30]) );
  AND2X4 U315 ( .A(n367), .B(n368), .Y(n66) );
  OAI21X2 U316 ( .A0(n96), .A1(n69), .B0(n70), .Y(n68) );
  NOR2XL U317 ( .A(n95), .B(n69), .Y(n67) );
  OAI21BX1 U318 ( .A0(n66), .A1(n56), .B0N(n59), .Y(n55) );
  NOR2X2 U319 ( .A(A[14]), .B(n256), .Y(n137) );
  AOI21X1 U320 ( .A0(n203), .A1(n211), .B0(n204), .Y(n202) );
  NAND2X2 U321 ( .A(n122), .B(n67), .Y(n367) );
  INVX2 U322 ( .A(n68), .Y(n368) );
  CLKINVX1 U323 ( .A(n1), .Y(n122) );
  INVXL U324 ( .A(n66), .Y(n65) );
  NAND2X2 U325 ( .A(n173), .B(n161), .Y(n155) );
  NOR2X2 U326 ( .A(n155), .B(n126), .Y(n124) );
  INVX2 U327 ( .A(n174), .Y(n172) );
  INVXL U328 ( .A(n173), .Y(n171) );
  NOR2X1 U329 ( .A(n189), .B(n186), .Y(n184) );
  NAND2X2 U330 ( .A(n233), .B(n369), .Y(n370) );
  NAND2X2 U331 ( .A(n370), .B(n176), .Y(n174) );
  NAND2X1 U332 ( .A(A[14]), .B(n256), .Y(n140) );
  NAND2XL U333 ( .A(A[8]), .B(n262), .Y(n179) );
  NOR2X1 U334 ( .A(A[9]), .B(n261), .Y(n175) );
  INVX2 U335 ( .A(n179), .Y(n369) );
  OAI21X2 U336 ( .A0(n212), .A1(\B[0] ), .B0(n213), .Y(n211) );
  NAND2X1 U337 ( .A(n58), .B(n46), .Y(n44) );
  NOR2XL U338 ( .A(n178), .B(n175), .Y(n173) );
  CLKNAND2X2 U339 ( .A(n228), .B(n140), .Y(n16) );
  NAND2X1 U340 ( .A(n83), .B(n71), .Y(n69) );
  NAND2XL U341 ( .A(n221), .B(n88), .Y(n9) );
  NAND2XL U342 ( .A(n231), .B(n164), .Y(n19) );
  NAND2XL U343 ( .A(n240), .B(n209), .Y(n28) );
  CLKNAND2X2 U344 ( .A(A[22]), .B(n248), .Y(n79) );
  NAND2XL U345 ( .A(n223), .B(n104), .Y(n11) );
  NAND2XL U346 ( .A(n217), .B(n61), .Y(n5) );
  NAND2XL U347 ( .A(n229), .B(n147), .Y(n17) );
  CLKINVX2 U348 ( .A(n113), .Y(n111) );
  INVXL U349 ( .A(n114), .Y(n112) );
  NAND2XL U350 ( .A(n113), .B(n101), .Y(n95) );
  NOR2XL U351 ( .A(n199), .B(n194), .Y(n192) );
  CLKNAND2X2 U352 ( .A(A[2]), .B(n268), .Y(n209) );
  NAND2XL U353 ( .A(A[25]), .B(n245), .Y(n61) );
  NAND2XL U354 ( .A(A[15]), .B(n255), .Y(n131) );
  NAND2XL U355 ( .A(A[13]), .B(n257), .Y(n147) );
  NAND2XL U356 ( .A(A[21]), .B(n249), .Y(n88) );
  NAND2XL U357 ( .A(A[19]), .B(n251), .Y(n104) );
  NAND2XL U358 ( .A(A[27]), .B(n243), .Y(n49) );
  NAND2XL U359 ( .A(A[11]), .B(n259), .Y(n164) );
  NAND2XL U360 ( .A(A[23]), .B(n247), .Y(n74) );
  NAND2BXL U361 ( .AN(n95), .B(n83), .Y(n81) );
  AOI21XL U362 ( .A0(n98), .A1(n83), .B0(n86), .Y(n82) );
  AOI21X1 U363 ( .A0(n101), .A1(n114), .B0(n102), .Y(n96) );
  OAI21X1 U364 ( .A0(n205), .A1(n209), .B0(n206), .Y(n204) );
  NAND2BXL U365 ( .AN(n35), .B(n40), .Y(n2) );
  AOI21XL U366 ( .A0(n65), .A1(n42), .B0(n43), .Y(n41) );
  OAI21X1 U367 ( .A0(n194), .A1(n200), .B0(n195), .Y(n193) );
  AOI21BXL U368 ( .A0(n201), .A1(n238), .B0N(n200), .Y(n196) );
  NOR2X2 U369 ( .A(A[17]), .B(n253), .Y(n115) );
  NOR2X2 U370 ( .A(A[23]), .B(n247), .Y(n73) );
  NOR2X2 U371 ( .A(A[15]), .B(n255), .Y(n130) );
  NOR2X2 U372 ( .A(A[21]), .B(n249), .Y(n87) );
  NOR2X2 U373 ( .A(A[25]), .B(n245), .Y(n60) );
  NOR2X2 U374 ( .A(A[27]), .B(n243), .Y(n48) );
  NOR2X2 U375 ( .A(A[13]), .B(n257), .Y(n146) );
  NOR2X2 U376 ( .A(A[19]), .B(n251), .Y(n103) );
  NOR2X2 U377 ( .A(A[11]), .B(n259), .Y(n163) );
  NOR2X1 U378 ( .A(A[24]), .B(n246), .Y(n63) );
  CLKNAND2X2 U379 ( .A(A[26]), .B(n244), .Y(n54) );
  NOR2X1 U380 ( .A(A[28]), .B(n242), .Y(n35) );
  NAND2XL U381 ( .A(n239), .B(n206), .Y(n27) );
  AOI21X4 U382 ( .A0(n181), .A1(n124), .B0(n125), .Y(n1) );
  NAND2XL U383 ( .A(n144), .B(n128), .Y(n126) );
  OAI21XL U384 ( .A0(n180), .A1(n155), .B0(n156), .Y(n154) );
  INVXL U385 ( .A(n145), .Y(n143) );
  INVXL U386 ( .A(n144), .Y(n142) );
  INVXL U387 ( .A(n45), .Y(n43) );
  OAI21X2 U388 ( .A0(n202), .A1(n182), .B0(n183), .Y(n181) );
  NAND2XL U389 ( .A(n67), .B(n33), .Y(n31) );
  INVXL U390 ( .A(n151), .Y(n230) );
  INVXL U391 ( .A(n78), .Y(n76) );
  INVXL U392 ( .A(n92), .Y(n90) );
  INVXL U393 ( .A(n108), .Y(n224) );
  INVXL U394 ( .A(n199), .Y(n238) );
  INVXL U395 ( .A(n53), .Y(n51) );
  INVXL U396 ( .A(n120), .Y(n226) );
  INVXL U397 ( .A(n168), .Y(n232) );
  INVXL U398 ( .A(n205), .Y(n239) );
  INVXL U399 ( .A(n186), .Y(n235) );
  INVXL U400 ( .A(n194), .Y(n237) );
  INVXL U401 ( .A(n175), .Y(n233) );
  INVXL U402 ( .A(n178), .Y(n234) );
  INVXL U403 ( .A(n189), .Y(n236) );
  INVXL U404 ( .A(n208), .Y(n240) );
  INVXL U405 ( .A(n212), .Y(n241) );
  XNOR2XL U406 ( .A(n94), .B(n10), .Y(DIFF[20]) );
  NAND2XL U407 ( .A(n90), .B(n93), .Y(n10) );
  NAND2XL U408 ( .A(n215), .B(n49), .Y(n3) );
  XNOR2XL U409 ( .A(n188), .B(n23), .Y(DIFF[7]) );
  NAND2XL U410 ( .A(n235), .B(n187), .Y(n23) );
  XNOR2XL U411 ( .A(n62), .B(n5), .Y(DIFF[25]) );
  XNOR2XL U412 ( .A(n177), .B(n21), .Y(DIFF[9]) );
  NAND2XL U413 ( .A(n233), .B(n176), .Y(n21) );
  XNOR2XL U414 ( .A(n170), .B(n20), .Y(DIFF[10]) );
  NAND2XL U415 ( .A(n232), .B(n169), .Y(n20) );
  NAND2XL U416 ( .A(n227), .B(n131), .Y(n15) );
  NAND2XL U417 ( .A(n241), .B(n213), .Y(n29) );
  XNOR2XL U418 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  NAND2XL U419 ( .A(n51), .B(n54), .Y(n4) );
  XNOR2XL U420 ( .A(n80), .B(n8), .Y(DIFF[22]) );
  NAND2XL U421 ( .A(n76), .B(n79), .Y(n8) );
  NAND2XL U422 ( .A(n219), .B(n74), .Y(n7) );
  XNOR2XL U423 ( .A(n65), .B(n6), .Y(DIFF[24]) );
  NAND2XL U424 ( .A(n218), .B(n64), .Y(n6) );
  NAND2XL U425 ( .A(n234), .B(n179), .Y(n22) );
  XNOR2XL U426 ( .A(n141), .B(n16), .Y(DIFF[14]) );
  NAND2XL U427 ( .A(n225), .B(n116), .Y(n13) );
  XNOR2XL U428 ( .A(n110), .B(n12), .Y(DIFF[18]) );
  NAND2XL U429 ( .A(n224), .B(n109), .Y(n12) );
  XNOR2XL U430 ( .A(n122), .B(n14), .Y(DIFF[16]) );
  NAND2XL U431 ( .A(n226), .B(n121), .Y(n14) );
  CLKNAND2X2 U432 ( .A(A[24]), .B(n246), .Y(n64) );
  NAND2XL U433 ( .A(A[6]), .B(n264), .Y(n190) );
  CLKNAND2X2 U434 ( .A(A[20]), .B(n250), .Y(n93) );
  CLKNAND2X2 U435 ( .A(A[12]), .B(n258), .Y(n152) );
  NAND2X1 U436 ( .A(A[18]), .B(n252), .Y(n109) );
  CLKNAND2X2 U437 ( .A(A[4]), .B(n266), .Y(n200) );
  CLKNAND2X2 U438 ( .A(A[16]), .B(n254), .Y(n121) );
  CLKNAND2X2 U439 ( .A(A[10]), .B(n260), .Y(n169) );
  CLKNAND2X2 U440 ( .A(A[28]), .B(n242), .Y(n40) );
  NAND2XL U441 ( .A(n230), .B(n152), .Y(n18) );
  XNOR2XL U442 ( .A(n201), .B(n26), .Y(DIFF[4]) );
  NAND2XL U443 ( .A(n238), .B(n200), .Y(n26) );
  NAND2XL U444 ( .A(n236), .B(n190), .Y(n24) );
  NAND2XL U445 ( .A(A[9]), .B(n261), .Y(n176) );
  NAND2XL U446 ( .A(A[3]), .B(n267), .Y(n206) );
  NAND2XL U447 ( .A(A[7]), .B(n263), .Y(n187) );
  NAND2XL U448 ( .A(A[1]), .B(n269), .Y(n213) );
  NAND2XL U449 ( .A(A[5]), .B(n265), .Y(n195) );
  NAND2XL U450 ( .A(A[17]), .B(n253), .Y(n116) );
  INVXL U451 ( .A(B[28]), .Y(n242) );
  INVXL U452 ( .A(B[10]), .Y(n260) );
  INVX2 U453 ( .A(n154), .Y(n153) );
  INVX2 U454 ( .A(n44), .Y(n42) );
  INVX2 U455 ( .A(n58), .Y(n56) );
  OAI21X1 U456 ( .A0(n1), .A1(n81), .B0(n82), .Y(n80) );
  NAND2X2 U457 ( .A(n135), .B(n157), .Y(n133) );
  AOI21X1 U458 ( .A0(n158), .A1(n135), .B0(n136), .Y(n134) );
  INVX2 U459 ( .A(n155), .Y(n157) );
  INVX2 U460 ( .A(n181), .Y(n180) );
  AOI21X1 U461 ( .A0(n201), .A1(n192), .B0(n193), .Y(n191) );
  INVX2 U462 ( .A(n202), .Y(n201) );
  INVX2 U463 ( .A(n96), .Y(n98) );
  INVX2 U464 ( .A(n211), .Y(n210) );
  OAI21X1 U465 ( .A0(n60), .A1(n64), .B0(n61), .Y(n59) );
  NOR2X2 U466 ( .A(n63), .B(n60), .Y(n58) );
  NOR2X2 U467 ( .A(n151), .B(n146), .Y(n144) );
  AOI21X1 U468 ( .A0(n46), .A1(n59), .B0(n47), .Y(n45) );
  OAI21X1 U469 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  AOI21X1 U470 ( .A0(n184), .A1(n193), .B0(n185), .Y(n183) );
  NAND2X2 U471 ( .A(n192), .B(n184), .Y(n182) );
  NOR2X2 U472 ( .A(n108), .B(n103), .Y(n101) );
  OAI21X1 U473 ( .A0(n103), .A1(n109), .B0(n104), .Y(n102) );
  NOR2X2 U474 ( .A(n142), .B(n137), .Y(n135) );
  NOR2X2 U475 ( .A(n92), .B(n87), .Y(n83) );
  OAI21X1 U476 ( .A0(n163), .A1(n169), .B0(n164), .Y(n162) );
  NOR2X2 U477 ( .A(n168), .B(n163), .Y(n161) );
  OAI21X1 U478 ( .A0(n146), .A1(n152), .B0(n147), .Y(n145) );
  OAI21X1 U479 ( .A0(n115), .A1(n121), .B0(n116), .Y(n114) );
  NOR2X2 U480 ( .A(n137), .B(n130), .Y(n128) );
  OAI21X1 U481 ( .A0(n87), .A1(n93), .B0(n88), .Y(n86) );
  NOR2X2 U482 ( .A(n208), .B(n205), .Y(n203) );
  NOR2X2 U483 ( .A(n120), .B(n115), .Y(n113) );
  AOI21X1 U484 ( .A0(n71), .A1(n86), .B0(n72), .Y(n70) );
  OAI21X1 U485 ( .A0(n73), .A1(n79), .B0(n74), .Y(n72) );
  AOI21BX2 U486 ( .A0(n94), .A1(n90), .B0N(n93), .Y(n89) );
  NOR2X2 U487 ( .A(n53), .B(n48), .Y(n46) );
  NOR2X2 U488 ( .A(n44), .B(n35), .Y(n33) );
  AOI21BX2 U489 ( .A0(n110), .A1(n224), .B0N(n109), .Y(n105) );
  NOR2X2 U490 ( .A(n78), .B(n73), .Y(n71) );
  AOI21X1 U491 ( .A0(n128), .A1(n145), .B0(n129), .Y(n127) );
  AOI21BX2 U492 ( .A0(n170), .A1(n232), .B0N(n169), .Y(n165) );
  AOI21BX2 U493 ( .A0(n154), .A1(n230), .B0N(n152), .Y(n148) );
  AOI21BX2 U494 ( .A0(n55), .A1(n51), .B0N(n54), .Y(n50) );
  AOI21BX2 U495 ( .A0(n80), .A1(n76), .B0N(n79), .Y(n75) );
  AOI21BX2 U496 ( .A0(n122), .A1(n226), .B0N(n121), .Y(n117) );
  INVX2 U497 ( .A(n73), .Y(n219) );
  INVX2 U498 ( .A(n48), .Y(n215) );
  INVX2 U499 ( .A(n130), .Y(n227) );
  INVX2 U500 ( .A(n103), .Y(n223) );
  INVX2 U501 ( .A(n63), .Y(n218) );
  INVX2 U502 ( .A(n137), .Y(n228) );
  INVX2 U503 ( .A(n115), .Y(n225) );
  INVX2 U504 ( .A(n146), .Y(n229) );
  INVX2 U505 ( .A(n163), .Y(n231) );
  INVX2 U506 ( .A(n87), .Y(n221) );
  INVX2 U507 ( .A(n60), .Y(n217) );
  INVX2 U508 ( .A(n40), .Y(n38) );
  NOR2X2 U509 ( .A(A[26]), .B(n244), .Y(n53) );
  NOR2X2 U510 ( .A(A[22]), .B(n248), .Y(n78) );
  NOR2X2 U511 ( .A(A[8]), .B(n262), .Y(n178) );
  NOR2X2 U512 ( .A(A[2]), .B(n268), .Y(n208) );
  NOR2X2 U513 ( .A(A[20]), .B(n250), .Y(n92) );
  NOR2X2 U514 ( .A(A[12]), .B(n258), .Y(n151) );
  NOR2X2 U515 ( .A(A[4]), .B(n266), .Y(n199) );
  NOR2X2 U516 ( .A(A[18]), .B(n252), .Y(n108) );
  NOR2X2 U517 ( .A(A[16]), .B(n254), .Y(n120) );
  NOR2X2 U518 ( .A(A[7]), .B(n263), .Y(n186) );
  NOR2X2 U519 ( .A(A[6]), .B(n264), .Y(n189) );
  NOR2X2 U520 ( .A(A[1]), .B(n269), .Y(n212) );
  NOR2X2 U521 ( .A(A[5]), .B(n265), .Y(n194) );
  NOR2X2 U522 ( .A(A[3]), .B(n267), .Y(n205) );
  NOR2X2 U523 ( .A(A[10]), .B(n260), .Y(n168) );
  AOI21X1 U524 ( .A0(n68), .A1(n33), .B0(n34), .Y(n32) );
  OAI21X1 U525 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U526 ( .A(n38), .B(A[29]), .Y(n36) );
  XOR2X1 U527 ( .A(n105), .B(n11), .Y(DIFF[19]) );
  XNOR2X1 U528 ( .A(n132), .B(n15), .Y(DIFF[15]) );
  NAND2X2 U529 ( .A(n237), .B(n195), .Y(n25) );
  XOR2X1 U530 ( .A(n89), .B(n9), .Y(DIFF[21]) );
  XNOR2X1 U531 ( .A(n207), .B(n27), .Y(DIFF[3]) );
  INVX2 U532 ( .A(B[1]), .Y(n269) );
  INVX2 U533 ( .A(B[3]), .Y(n267) );
  INVX2 U534 ( .A(B[7]), .Y(n263) );
  INVX2 U535 ( .A(B[13]), .Y(n257) );
  INVX2 U536 ( .A(B[21]), .Y(n249) );
  INVX2 U537 ( .A(B[5]), .Y(n265) );
  INVX2 U538 ( .A(B[25]), .Y(n245) );
  INVX2 U539 ( .A(B[14]), .Y(n256) );
  INVX2 U540 ( .A(B[4]), .Y(n266) );
  INVX2 U541 ( .A(B[20]), .Y(n250) );
  INVX2 U542 ( .A(B[22]), .Y(n248) );
  INVX2 U543 ( .A(B[26]), .Y(n244) );
  INVX2 U544 ( .A(B[27]), .Y(n243) );
  INVX2 U545 ( .A(B[8]), .Y(n262) );
  INVX2 U546 ( .A(B[19]), .Y(n251) );
  INVX2 U547 ( .A(B[2]), .Y(n268) );
  INVX2 U548 ( .A(B[12]), .Y(n258) );
  OAI21X2 U549 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
endmodule


module norm_v4_29_DW01_sub_41 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n31,
         n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46, n47,
         n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61,
         n62, n63, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76,
         n77, n78, n79, n80, n81, n84, n85, n86, n87, n88, n89, n90, n91, n92,
         n93, n94, n96, n99, n100, n101, n102, n103, n104, n105, n108, n109,
         n110, n111, n112, n113, n114, n119, n120, n121, n122, n123, n126,
         n127, n128, n129, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n141, n142, n143, n144, n146, n149, n150, n151, n153, n154,
         n155, n156, n157, n158, n159, n163, n164, n165, n166, n167, n168,
         n169, n172, n173, n174, n175, n176, n177, n178, n183, n184, n185,
         n186, n187, n188, n189, n190, n191, n192, n193, n194, n195, n196,
         n197, n198, n199, n200, n201, n202, n203, n204, n206, n207, n208,
         n209, n210, n211, n212, n213, n214, n215, n216, n217, n218, n219,
         n220, n221, n222, n223, n224, n225, n227, n229, n231, n232, n233,
         n234, n235, n236, n237, n238, n239, n240, n241, n242, n243, n244,
         n245, n246, n247, n248, n249, n250, n251, n252, n253, n254, n255,
         n256, n257, n258, n259, n260, n261, n262, n263, n264, n265, n266,
         n267, n268, n269, n270, n271, n272, n273, n274, n275, n276, n277,
         \B[0] , n376, n377, n378;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  OAI21X1 U18 ( .A0(n61), .A1(n42), .B0(n43), .Y(n41) );
  OAI21X1 U22 ( .A0(n46), .A1(n50), .B0(n47), .Y(n45) );
  XOR2X1 U27 ( .A(n51), .B(n4), .Y(DIFF[26]) );
  OAI21X1 U28 ( .A0(n51), .A1(n49), .B0(n50), .Y(n48) );
  XOR2X1 U33 ( .A(n56), .B(n5), .Y(DIFF[25]) );
  XOR2X1 U41 ( .A(n61), .B(n6), .Y(DIFF[24]) );
  XOR2X1 U49 ( .A(n73), .B(n7), .Y(DIFF[23]) );
  OAI21X1 U59 ( .A0(n71), .A1(n77), .B0(n72), .Y(n70) );
  XOR2X1 U72 ( .A(n87), .B(n9), .Y(DIFF[21]) );
  OAI21X1 U101 ( .A0(n101), .A1(n109), .B0(n102), .Y(n100) );
  OAI21X1 U117 ( .A0(n1), .A1(n111), .B0(n112), .Y(n110) );
  XOR2X1 U130 ( .A(n1), .B(n14), .Y(DIFF[16]) );
  OAI21X1 U143 ( .A0(n131), .A1(n141), .B0(n132), .Y(n130) );
  XOR2X1 U148 ( .A(n142), .B(n16), .Y(DIFF[14]) );
  OAI21X1 U149 ( .A0(n188), .A1(n134), .B0(n135), .Y(n133) );
  OAI21X1 U153 ( .A0(n146), .A1(n138), .B0(n141), .Y(n137) );
  XOR2X1 U160 ( .A(n151), .B(n17), .Y(DIFF[13]) );
  OAI21X1 U195 ( .A0(n188), .A1(n168), .B0(n169), .Y(n167) );
  OAI21X1 U205 ( .A0(n188), .A1(n175), .B0(n176), .Y(n174) );
  XOR2X1 U218 ( .A(n188), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U219 ( .A0(n188), .A1(n186), .B0(n187), .Y(n185) );
  OAI21X1 U230 ( .A0(n194), .A1(n198), .B0(n195), .Y(n193) );
  XOR2X1 U235 ( .A(n199), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U236 ( .A0(n199), .A1(n197), .B0(n198), .Y(n196) );
  XOR2X1 U241 ( .A(n204), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U266 ( .A(n218), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U267 ( .A0(n218), .A1(n216), .B0(n217), .Y(n215) );
  XOR2X1 U272 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U310 ( .A(n219), .Y(n218) );
  NAND2X1 U311 ( .A(A[1]), .B(n277), .Y(n221) );
  CLKINVX2 U312 ( .A(B[2]), .Y(n276) );
  INVXL U313 ( .A(B[11]), .Y(n267) );
  INVXL U314 ( .A(B[17]), .Y(n261) );
  INVXL U315 ( .A(B[15]), .Y(n263) );
  INVXL U316 ( .A(B[16]), .Y(n262) );
  INVXL U317 ( .A(B[24]), .Y(n254) );
  INVXL U318 ( .A(B[9]), .Y(n269) );
  INVXL U319 ( .A(B[18]), .Y(n260) );
  INVXL U320 ( .A(B[23]), .Y(n255) );
  INVXL U321 ( .A(B[6]), .Y(n272) );
  OAI21X1 U322 ( .A0(n119), .A1(n123), .B0(n120), .Y(n114) );
  OAI21X1 U323 ( .A0(n210), .A1(n190), .B0(n191), .Y(n189) );
  NOR2X2 U324 ( .A(n154), .B(n149), .Y(n143) );
  OAI21X1 U325 ( .A0(n149), .A1(n155), .B0(n150), .Y(n144) );
  AOI21X1 U326 ( .A0(n163), .A1(n178), .B0(n164), .Y(n158) );
  AOI21X1 U327 ( .A0(n66), .A1(n33), .B0(n34), .Y(n32) );
  OA21X1 U328 ( .A0(n1), .A1(n31), .B0(n32), .Y(DIFF[30]) );
  NOR2X6 U329 ( .A(n378), .B(n126), .Y(n1) );
  OR2X2 U330 ( .A(n157), .B(n127), .Y(n376) );
  INVXL U331 ( .A(n35), .Y(n222) );
  INVXL U332 ( .A(n114), .Y(n112) );
  AOI21X4 U333 ( .A0(n99), .A1(n114), .B0(n100), .Y(n94) );
  NAND2X2 U334 ( .A(n143), .B(n129), .Y(n127) );
  OAI21X4 U335 ( .A0(n158), .A1(n127), .B0(n128), .Y(n126) );
  INVX2 U336 ( .A(n189), .Y(n377) );
  OAI21XL U337 ( .A0(n165), .A1(n173), .B0(n166), .Y(n164) );
  OAI21X1 U338 ( .A0(n85), .A1(n91), .B0(n86), .Y(n84) );
  NOR2X2 U339 ( .A(A[24]), .B(n254), .Y(n59) );
  NOR2X1 U340 ( .A(A[28]), .B(n250), .Y(n35) );
  XNOR2XL U341 ( .A(n103), .B(n11), .Y(DIFF[19]) );
  AOI21X1 U342 ( .A0(n156), .A1(n238), .B0(n153), .Y(n151) );
  XNOR2X1 U343 ( .A(n133), .B(n15), .Y(DIFF[15]) );
  OAI21XL U344 ( .A0(n1), .A1(n104), .B0(n105), .Y(n103) );
  OAI21X1 U345 ( .A0(n1), .A1(n79), .B0(n80), .Y(n78) );
  NOR2X4 U346 ( .A(n377), .B(n376), .Y(n378) );
  OAI21XL U347 ( .A0(n1), .A1(n122), .B0(n123), .Y(n121) );
  OAI21XL U348 ( .A0(n1), .A1(n93), .B0(n94), .Y(n92) );
  NOR2X2 U349 ( .A(n42), .B(n35), .Y(n33) );
  AOI21XL U350 ( .A0(n69), .A1(n84), .B0(n70), .Y(n68) );
  AOI21X2 U351 ( .A0(n219), .A1(n211), .B0(n212), .Y(n210) );
  AOI21BX1 U352 ( .A0(n178), .A1(n240), .B0N(n173), .Y(n169) );
  NAND2XL U353 ( .A(n224), .B(n50), .Y(n4) );
  NOR2X2 U354 ( .A(n93), .B(n67), .Y(n65) );
  NAND2BX1 U355 ( .AN(n93), .B(n81), .Y(n79) );
  AOI21XL U356 ( .A0(n96), .A1(n81), .B0(n84), .Y(n80) );
  OAI21X2 U357 ( .A0(n94), .A1(n67), .B0(n68), .Y(n66) );
  INVXL U358 ( .A(n144), .Y(n146) );
  NAND2XL U359 ( .A(n237), .B(n150), .Y(n17) );
  OAI21X1 U360 ( .A0(n220), .A1(\B[0] ), .B0(n221), .Y(n219) );
  NAND2XL U361 ( .A(n57), .B(n60), .Y(n6) );
  AOI21X1 U362 ( .A0(n92), .A1(n88), .B0(n89), .Y(n87) );
  NOR2X2 U363 ( .A(A[14]), .B(n264), .Y(n138) );
  NAND2XL U364 ( .A(n242), .B(n187), .Y(n22) );
  OAI21BXL U365 ( .A0(n1), .A1(n63), .B0N(n66), .Y(n62) );
  OAI21XL U366 ( .A0(n188), .A1(n157), .B0(n158), .Y(n156) );
  AOI21XL U367 ( .A0(n209), .A1(n200), .B0(n201), .Y(n199) );
  INVXL U368 ( .A(n189), .Y(n188) );
  NAND2XL U369 ( .A(n52), .B(n44), .Y(n42) );
  NAND2XL U370 ( .A(n177), .B(n240), .Y(n168) );
  INVXL U371 ( .A(n157), .Y(n159) );
  INVXL U372 ( .A(n177), .Y(n175) );
  OAI21X2 U373 ( .A0(n183), .A1(n187), .B0(n184), .Y(n178) );
  NOR2XL U374 ( .A(n122), .B(n119), .Y(n113) );
  NOR2X1 U375 ( .A(n59), .B(n54), .Y(n52) );
  AOI2B1XL U376 ( .A1N(n158), .A0(n136), .B0(n137), .Y(n135) );
  INVXL U377 ( .A(n172), .Y(n240) );
  INVXL U378 ( .A(n108), .Y(n232) );
  INVXL U379 ( .A(n76), .Y(n74) );
  INVXL U380 ( .A(n90), .Y(n88) );
  INVXL U381 ( .A(n154), .Y(n238) );
  INVXL U382 ( .A(n46), .Y(n223) );
  INVXL U383 ( .A(n71), .Y(n227) );
  INVXL U384 ( .A(n119), .Y(n233) );
  INVXL U385 ( .A(n194), .Y(n243) );
  INVXL U386 ( .A(n165), .Y(n239) );
  INVXL U387 ( .A(n202), .Y(n245) );
  INVXL U388 ( .A(n54), .Y(n225) );
  INVXL U389 ( .A(n131), .Y(n235) );
  INVXL U390 ( .A(n85), .Y(n229) );
  INVXL U391 ( .A(n101), .Y(n231) );
  INVXL U392 ( .A(n183), .Y(n241) );
  INVXL U393 ( .A(n149), .Y(n237) );
  INVXL U394 ( .A(n213), .Y(n247) );
  AOI21BX1 U395 ( .A0(n114), .A1(n232), .B0N(n109), .Y(n105) );
  INVXL U396 ( .A(n208), .Y(n206) );
  INVXL U397 ( .A(n60), .Y(n58) );
  NOR2XL U398 ( .A(A[16]), .B(n262), .Y(n122) );
  NOR2X1 U399 ( .A(A[2]), .B(n276), .Y(n216) );
  INVXL U400 ( .A(n49), .Y(n224) );
  AOI21XL U401 ( .A0(n62), .A1(n57), .B0(n58), .Y(n56) );
  NAND2XL U402 ( .A(n225), .B(n55), .Y(n5) );
  NOR2XL U403 ( .A(A[4]), .B(n274), .Y(n207) );
  NAND2XL U404 ( .A(n223), .B(n47), .Y(n3) );
  XNOR2XL U405 ( .A(n48), .B(n3), .Y(DIFF[27]) );
  CLKNAND2X2 U406 ( .A(n243), .B(n195), .Y(n23) );
  AOI21XL U407 ( .A0(n209), .A1(n246), .B0(n206), .Y(n204) );
  CLKNAND2X2 U408 ( .A(n245), .B(n203), .Y(n25) );
  NAND2XL U409 ( .A(n241), .B(n184), .Y(n21) );
  XNOR2XL U410 ( .A(n185), .B(n21), .Y(DIFF[9]) );
  NAND2XL U411 ( .A(n239), .B(n166), .Y(n19) );
  XNOR2XL U412 ( .A(n167), .B(n19), .Y(DIFF[11]) );
  NAND2XL U413 ( .A(n240), .B(n173), .Y(n20) );
  XNOR2XL U414 ( .A(n174), .B(n20), .Y(DIFF[10]) );
  NAND2XL U415 ( .A(n74), .B(n77), .Y(n8) );
  AOI21XL U416 ( .A0(n156), .A1(n143), .B0(n144), .Y(n142) );
  CLKNAND2X2 U417 ( .A(n236), .B(n141), .Y(n16) );
  INVXL U418 ( .A(n197), .Y(n244) );
  NAND2XL U419 ( .A(n244), .B(n198), .Y(n24) );
  XNOR2XL U420 ( .A(n121), .B(n13), .Y(DIFF[17]) );
  INVXL U421 ( .A(n122), .Y(n234) );
  NAND2XL U422 ( .A(n234), .B(n123), .Y(n14) );
  XNOR2XL U423 ( .A(n92), .B(n10), .Y(DIFF[20]) );
  NAND2XL U424 ( .A(n232), .B(n109), .Y(n12) );
  XNOR2XL U425 ( .A(n110), .B(n12), .Y(DIFF[18]) );
  INVXL U426 ( .A(n216), .Y(n248) );
  NAND2XL U427 ( .A(n248), .B(n217), .Y(n28) );
  CLKNAND2X2 U428 ( .A(A[12]), .B(n266), .Y(n155) );
  NAND2X1 U429 ( .A(A[22]), .B(n256), .Y(n77) );
  CLKNAND2X2 U430 ( .A(A[20]), .B(n258), .Y(n91) );
  INVXL U431 ( .A(n186), .Y(n242) );
  CLKNAND2X2 U432 ( .A(A[8]), .B(n270), .Y(n187) );
  NAND2XL U433 ( .A(A[14]), .B(n264), .Y(n141) );
  NAND2XL U434 ( .A(A[26]), .B(n252), .Y(n50) );
  NAND2X1 U435 ( .A(A[6]), .B(n272), .Y(n198) );
  CLKNAND2X2 U436 ( .A(A[18]), .B(n260), .Y(n109) );
  CLKNAND2X2 U437 ( .A(A[28]), .B(n250), .Y(n40) );
  NAND2XL U438 ( .A(A[9]), .B(n269), .Y(n184) );
  NAND2XL U439 ( .A(A[13]), .B(n265), .Y(n150) );
  NAND2XL U440 ( .A(A[3]), .B(n275), .Y(n214) );
  NAND2XL U441 ( .A(A[11]), .B(n267), .Y(n166) );
  NAND2XL U442 ( .A(A[5]), .B(n273), .Y(n203) );
  NAND2XL U443 ( .A(A[27]), .B(n251), .Y(n47) );
  NAND2XL U444 ( .A(A[23]), .B(n255), .Y(n72) );
  NAND2XL U445 ( .A(A[7]), .B(n271), .Y(n195) );
  NAND2XL U446 ( .A(A[25]), .B(n253), .Y(n55) );
  NAND2XL U447 ( .A(A[21]), .B(n257), .Y(n86) );
  NAND2XL U448 ( .A(A[15]), .B(n263), .Y(n132) );
  NAND2XL U449 ( .A(A[19]), .B(n259), .Y(n102) );
  NAND2XL U450 ( .A(A[17]), .B(n261), .Y(n120) );
  INVXL U451 ( .A(B[28]), .Y(n250) );
  INVXL U452 ( .A(B[10]), .Y(n268) );
  INVX2 U453 ( .A(n65), .Y(n63) );
  NAND2X2 U454 ( .A(n177), .B(n163), .Y(n157) );
  NAND2X2 U455 ( .A(n113), .B(n99), .Y(n93) );
  NAND2X2 U456 ( .A(n81), .B(n69), .Y(n67) );
  AOI21X1 U457 ( .A0(n62), .A1(n52), .B0(n53), .Y(n51) );
  NAND2X2 U458 ( .A(n65), .B(n33), .Y(n31) );
  INVX2 U459 ( .A(n210), .Y(n209) );
  INVX2 U460 ( .A(n94), .Y(n96) );
  NAND2X2 U461 ( .A(n136), .B(n159), .Y(n134) );
  NAND2X2 U462 ( .A(n113), .B(n232), .Y(n104) );
  INVX2 U463 ( .A(n178), .Y(n176) );
  INVX2 U464 ( .A(n113), .Y(n111) );
  NOR2X2 U465 ( .A(n90), .B(n85), .Y(n81) );
  AOI21X1 U466 ( .A0(n192), .A1(n201), .B0(n193), .Y(n191) );
  NOR2X2 U467 ( .A(n197), .B(n194), .Y(n192) );
  NOR2BX1 U468 ( .AN(n143), .B(n138), .Y(n136) );
  NOR2X2 U469 ( .A(n108), .B(n101), .Y(n99) );
  NOR2X2 U470 ( .A(n138), .B(n131), .Y(n129) );
  OAI21X1 U471 ( .A0(n54), .A1(n60), .B0(n55), .Y(n53) );
  OAI21X1 U472 ( .A0(n202), .A1(n208), .B0(n203), .Y(n201) );
  NOR2X2 U473 ( .A(n186), .B(n183), .Y(n177) );
  NOR2X2 U474 ( .A(n76), .B(n71), .Y(n69) );
  OAI21X1 U475 ( .A0(n213), .A1(n217), .B0(n214), .Y(n212) );
  NOR2X2 U476 ( .A(n216), .B(n213), .Y(n211) );
  NOR2X2 U477 ( .A(n172), .B(n165), .Y(n163) );
  XNOR2X1 U478 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  NAND2X2 U479 ( .A(n222), .B(n40), .Y(n2) );
  NOR2X2 U480 ( .A(n49), .B(n46), .Y(n44) );
  NOR2X2 U481 ( .A(n207), .B(n202), .Y(n200) );
  AOI21X1 U482 ( .A0(n129), .A1(n144), .B0(n130), .Y(n128) );
  INVX2 U483 ( .A(n207), .Y(n246) );
  INVX2 U484 ( .A(n138), .Y(n236) );
  INVX2 U485 ( .A(n59), .Y(n57) );
  INVX2 U486 ( .A(n220), .Y(n249) );
  INVX2 U487 ( .A(n77), .Y(n75) );
  INVX2 U488 ( .A(n155), .Y(n153) );
  INVX2 U489 ( .A(n91), .Y(n89) );
  INVX2 U490 ( .A(n40), .Y(n38) );
  NOR2X2 U491 ( .A(A[3]), .B(n275), .Y(n213) );
  NOR2X2 U492 ( .A(A[5]), .B(n273), .Y(n202) );
  NOR2X2 U493 ( .A(A[11]), .B(n267), .Y(n165) );
  NOR2X2 U494 ( .A(A[15]), .B(n263), .Y(n131) );
  NOR2X2 U495 ( .A(A[7]), .B(n271), .Y(n194) );
  NOR2X2 U496 ( .A(A[23]), .B(n255), .Y(n71) );
  NOR2X2 U497 ( .A(A[27]), .B(n251), .Y(n46) );
  NOR2X2 U498 ( .A(A[26]), .B(n252), .Y(n49) );
  NOR2X2 U499 ( .A(A[6]), .B(n272), .Y(n197) );
  NOR2X2 U500 ( .A(A[19]), .B(n259), .Y(n101) );
  NOR2X2 U501 ( .A(A[12]), .B(n266), .Y(n154) );
  NOR2X2 U502 ( .A(A[10]), .B(n268), .Y(n172) );
  NOR2X2 U503 ( .A(A[20]), .B(n258), .Y(n90) );
  NOR2X2 U504 ( .A(A[22]), .B(n256), .Y(n76) );
  NOR2X2 U505 ( .A(A[18]), .B(n260), .Y(n108) );
  NOR2X2 U506 ( .A(A[9]), .B(n269), .Y(n183) );
  NOR2X2 U507 ( .A(A[21]), .B(n257), .Y(n85) );
  NOR2X2 U508 ( .A(A[17]), .B(n261), .Y(n119) );
  NOR2X2 U509 ( .A(A[13]), .B(n265), .Y(n149) );
  NOR2X2 U510 ( .A(A[8]), .B(n270), .Y(n186) );
  NOR2X2 U511 ( .A(A[1]), .B(n277), .Y(n220) );
  NOR2X2 U512 ( .A(A[25]), .B(n253), .Y(n54) );
  NAND2X2 U513 ( .A(A[4]), .B(n274), .Y(n208) );
  NAND2X2 U514 ( .A(A[10]), .B(n268), .Y(n173) );
  XNOR2X1 U515 ( .A(n156), .B(n18), .Y(DIFF[12]) );
  NAND2X2 U516 ( .A(n238), .B(n155), .Y(n18) );
  NAND2X2 U517 ( .A(n88), .B(n91), .Y(n10) );
  NAND2X2 U518 ( .A(n235), .B(n132), .Y(n15) );
  NAND2X2 U519 ( .A(n229), .B(n86), .Y(n9) );
  NAND2X2 U520 ( .A(n231), .B(n102), .Y(n11) );
  XNOR2X1 U521 ( .A(n196), .B(n23), .Y(DIFF[7]) );
  NAND2X2 U522 ( .A(n227), .B(n72), .Y(n7) );
  AOI21X1 U523 ( .A0(n78), .A1(n74), .B0(n75), .Y(n73) );
  XNOR2X1 U524 ( .A(n209), .B(n26), .Y(DIFF[4]) );
  NAND2X2 U525 ( .A(n246), .B(n208), .Y(n26) );
  XNOR2X1 U526 ( .A(n215), .B(n27), .Y(DIFF[3]) );
  NAND2X2 U527 ( .A(n247), .B(n214), .Y(n27) );
  NAND2X2 U528 ( .A(n233), .B(n120), .Y(n13) );
  NAND2X2 U529 ( .A(A[24]), .B(n254), .Y(n60) );
  NAND2X2 U530 ( .A(A[16]), .B(n262), .Y(n123) );
  NAND2X2 U531 ( .A(A[2]), .B(n276), .Y(n217) );
  NAND2X2 U532 ( .A(n249), .B(n221), .Y(n29) );
  OAI21X1 U533 ( .A0(n43), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U534 ( .A(A[29]), .B(n38), .Y(n36) );
  INVX2 U535 ( .A(B[20]), .Y(n258) );
  INVX2 U536 ( .A(B[1]), .Y(n277) );
  INVX2 U537 ( .A(B[13]), .Y(n265) );
  INVX2 U538 ( .A(B[8]), .Y(n270) );
  INVX2 U539 ( .A(B[25]), .Y(n253) );
  INVX2 U540 ( .A(B[12]), .Y(n266) );
  INVX2 U541 ( .A(B[21]), .Y(n257) );
  INVX2 U542 ( .A(B[22]), .Y(n256) );
  INVX2 U543 ( .A(B[3]), .Y(n275) );
  INVX2 U544 ( .A(B[7]), .Y(n271) );
  INVX2 U545 ( .A(B[26]), .Y(n252) );
  INVX2 U546 ( .A(B[27]), .Y(n251) );
  INVX2 U547 ( .A(B[4]), .Y(n274) );
  INVX2 U548 ( .A(B[14]), .Y(n264) );
  INVX2 U549 ( .A(B[5]), .Y(n273) );
  INVX2 U550 ( .A(B[19]), .Y(n259) );
  NAND2X1 U551 ( .A(n200), .B(n192), .Y(n190) );
  XNOR2X1 U552 ( .A(n78), .B(n8), .Y(DIFF[22]) );
  AOI21X1 U553 ( .A0(n44), .A1(n53), .B0(n45), .Y(n43) );
  INVX2 U554 ( .A(n62), .Y(n61) );
endmodule


module norm_v4_29_DW01_sub_38 ( A, B, CI, DIFF, CO );
  input [30:0] A;
  input [30:0] B;
  output [30:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n38, n40, n41, n42, n43, n44, n45, n46,
         n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n61, n62,
         n63, n64, n65, n66, n67, n69, n70, n71, n72, n74, n75, n76, n77, n78,
         n79, n80, n81, n82, n83, n84, n85, n86, n87, n90, n91, n92, n93, n94,
         n95, n97, n100, n101, n102, n103, n104, n107, n108, n109, n110, n111,
         n112, n113, n116, n117, n118, n119, n120, n121, n122, n125, n126,
         n127, n128, n129, n130, n131, n136, n137, n138, n139, n140, n142,
         n144, n145, n146, n147, n148, n149, n150, n151, n152, n153, n154,
         n155, n158, n159, n160, n161, n162, n163, n165, n168, n169, n170,
         n171, n172, n175, n176, n177, n178, n179, n180, n181, n184, n185,
         n186, n187, n188, n189, n190, n193, n194, n195, n196, n197, n198,
         n199, n204, n205, n206, n207, n208, n209, n210, n211, n212, n213,
         n214, n215, n216, n217, n218, n219, n220, n221, n222, n223, n224,
         n225, n227, n228, n229, n230, n231, n232, n233, n234, n235, n236,
         n237, n238, n239, n240, n241, n242, n243, n244, n246, n248, n249,
         n250, n251, n252, n253, n254, n255, n256, n257, n258, n259, n260,
         n261, n262, n263, n264, n265, n266, n267, n268, n269, n270, n271,
         n272, n273, n274, n275, n276, n277, n278, n279, n280, n281, n282,
         n283, n284, n285, n286, n287, n288, n289, n290, n291, n292, n293,
         n294, n295, n296, n297, n298, \B[0] , n396;
  assign DIFF[0] = \B[0] ;
  assign \B[0]  = B[0];

  XOR2X1 U10 ( .A(n41), .B(n2), .Y(DIFF[28]) );
  XOR2X1 U17 ( .A(n50), .B(n3), .Y(DIFF[27]) );
  OAI21X1 U24 ( .A0(n48), .A1(n54), .B0(n49), .Y(n47) );
  OAI21X1 U68 ( .A0(n80), .A1(n90), .B0(n81), .Y(n79) );
  OAI21X1 U78 ( .A0(n97), .A1(n87), .B0(n90), .Y(n86) );
  OAI21X1 U166 ( .A0(n209), .A1(n151), .B0(n152), .Y(n150) );
  OAI21X1 U170 ( .A0(n165), .A1(n155), .B0(n158), .Y(n154) );
  OAI21X1 U178 ( .A0(n209), .A1(n160), .B0(n161), .Y(n159) );
  OAI21X1 U192 ( .A0(n209), .A1(n171), .B0(n172), .Y(n170) );
  OAI21X1 U202 ( .A0(n209), .A1(n178), .B0(n179), .Y(n177) );
  OAI21X1 U216 ( .A0(n209), .A1(n189), .B0(n190), .Y(n188) );
  OAI21X1 U226 ( .A0(n209), .A1(n196), .B0(n197), .Y(n195) );
  XOR2X1 U239 ( .A(n209), .B(n22), .Y(DIFF[8]) );
  OAI21X1 U240 ( .A0(n209), .A1(n207), .B0(n208), .Y(n206) );
  OAI21X1 U251 ( .A0(n215), .A1(n219), .B0(n216), .Y(n214) );
  XOR2X1 U256 ( .A(n220), .B(n24), .Y(DIFF[6]) );
  OAI21X1 U257 ( .A0(n220), .A1(n218), .B0(n219), .Y(n217) );
  XOR2X1 U262 ( .A(n225), .B(n25), .Y(DIFF[5]) );
  XOR2X1 U287 ( .A(n239), .B(n28), .Y(DIFF[2]) );
  OAI21X1 U288 ( .A0(n239), .A1(n237), .B0(n238), .Y(n236) );
  XOR2X1 U293 ( .A(n29), .B(\B[0] ), .Y(DIFF[1]) );
  INVXL U331 ( .A(B[2]), .Y(n297) );
  INVXL U332 ( .A(B[15]), .Y(n284) );
  INVXL U333 ( .A(B[18]), .Y(n281) );
  INVXL U334 ( .A(B[23]), .Y(n276) );
  INVXL U335 ( .A(B[6]), .Y(n293) );
  AOI21X1 U336 ( .A0(n116), .A1(n131), .B0(n117), .Y(n111) );
  AOI21BX2 U337 ( .A0(n210), .A1(n142), .B0N(n396), .Y(n1) );
  NAND2X1 U338 ( .A(A[6]), .B(n293), .Y(n219) );
  NOR2XL U339 ( .A(A[4]), .B(n295), .Y(n228) );
  NAND2X1 U340 ( .A(A[12]), .B(n287), .Y(n176) );
  NOR2X2 U341 ( .A(n175), .B(n168), .Y(n162) );
  NAND2X2 U342 ( .A(A[8]), .B(n291), .Y(n208) );
  CLKINVX2 U343 ( .A(n30), .Y(DIFF[30]) );
  OA21X2 U344 ( .A0(n179), .A1(n144), .B0(n145), .Y(n396) );
  OAI21X2 U345 ( .A0(n204), .A1(n208), .B0(n205), .Y(n199) );
  AOI21BX1 U346 ( .A0(n199), .A1(n261), .B0N(n194), .Y(n190) );
  NAND2XL U347 ( .A(A[1]), .B(n298), .Y(n242) );
  CLKNAND2X2 U348 ( .A(n180), .B(n259), .Y(n171) );
  NAND2XL U349 ( .A(n74), .B(n58), .Y(n56) );
  NAND2XL U350 ( .A(n94), .B(n78), .Y(n76) );
  INVX2 U351 ( .A(n175), .Y(n259) );
  NAND2XL U352 ( .A(n112), .B(n251), .Y(n103) );
  OAI21X1 U353 ( .A0(n168), .A1(n176), .B0(n169), .Y(n163) );
  NOR2XL U354 ( .A(n139), .B(n136), .Y(n130) );
  NOR2XL U355 ( .A(n69), .B(n62), .Y(n58) );
  AOI21X2 U356 ( .A0(n184), .A1(n199), .B0(n185), .Y(n179) );
  NOR2XL U357 ( .A(n228), .B(n223), .Y(n221) );
  CLKNAND2X2 U358 ( .A(A[16]), .B(n283), .Y(n140) );
  CLKNAND2X2 U359 ( .A(A[24]), .B(n275), .Y(n70) );
  INVXL U360 ( .A(n199), .Y(n197) );
  NOR2X2 U361 ( .A(n110), .B(n76), .Y(n74) );
  NOR2X2 U362 ( .A(n207), .B(n204), .Y(n198) );
  OAI21X1 U363 ( .A0(n136), .A1(n140), .B0(n137), .Y(n131) );
  OAI21X1 U364 ( .A0(n223), .A1(n229), .B0(n224), .Y(n222) );
  INVXL U365 ( .A(n178), .Y(n180) );
  INVXL U366 ( .A(n110), .Y(n112) );
  AOI21XL U367 ( .A0(n75), .A1(n58), .B0(n61), .Y(n57) );
  OAI21BXL U368 ( .A0(n1), .A1(n72), .B0N(n75), .Y(n71) );
  NAND2XL U369 ( .A(n74), .B(n33), .Y(n31) );
  AOI21XL U370 ( .A0(n181), .A1(n162), .B0(n163), .Y(n161) );
  AOI21XL U371 ( .A0(n113), .A1(n94), .B0(n95), .Y(n93) );
  NAND2XL U372 ( .A(n58), .B(n46), .Y(n44) );
  INVXL U373 ( .A(n111), .Y(n113) );
  NAND2XL U374 ( .A(n74), .B(n67), .Y(n65) );
  INVXL U375 ( .A(n45), .Y(n43) );
  NAND2XL U376 ( .A(n112), .B(n94), .Y(n92) );
  OAI21X2 U377 ( .A0(n231), .A1(n211), .B0(n212), .Y(n210) );
  NAND2XL U378 ( .A(n221), .B(n213), .Y(n211) );
  NOR2XL U379 ( .A(n218), .B(n215), .Y(n213) );
  NOR2XL U380 ( .A(n234), .B(n237), .Y(n232) );
  NOR2BXL U381 ( .AN(n162), .B(n155), .Y(n153) );
  NOR2BXL U382 ( .AN(n94), .B(n87), .Y(n85) );
  NOR2X1 U383 ( .A(n125), .B(n118), .Y(n116) );
  NOR2X1 U384 ( .A(n193), .B(n186), .Y(n184) );
  INVXL U385 ( .A(n163), .Y(n165) );
  AOI21XL U386 ( .A0(n181), .A1(n153), .B0(n154), .Y(n152) );
  NAND2XL U387 ( .A(n261), .B(n194), .Y(n20) );
  INVXL U388 ( .A(n218), .Y(n265) );
  NAND2XL U389 ( .A(n265), .B(n219), .Y(n24) );
  NAND2XL U390 ( .A(n253), .B(n126), .Y(n12) );
  NAND2XL U391 ( .A(n257), .B(n158), .Y(n16) );
  INVXL U392 ( .A(n207), .Y(n263) );
  NAND2XL U393 ( .A(n263), .B(n208), .Y(n22) );
  NAND2XL U394 ( .A(n249), .B(n90), .Y(n8) );
  XNOR2XL U395 ( .A(n230), .B(n26), .Y(DIFF[4]) );
  NAND2XL U396 ( .A(n267), .B(n229), .Y(n26) );
  INVXL U397 ( .A(n139), .Y(n255) );
  NAND2XL U398 ( .A(n255), .B(n140), .Y(n14) );
  NAND2XL U399 ( .A(n259), .B(n176), .Y(n18) );
  NAND2XL U400 ( .A(n51), .B(n54), .Y(n4) );
  NAND2XL U401 ( .A(n251), .B(n108), .Y(n10) );
  NAND2XL U402 ( .A(n67), .B(n70), .Y(n6) );
  NAND2XL U403 ( .A(n264), .B(n216), .Y(n23) );
  NAND2XL U404 ( .A(n262), .B(n205), .Y(n21) );
  NAND2XL U405 ( .A(n268), .B(n235), .Y(n27) );
  AOI21XL U406 ( .A0(n230), .A1(n267), .B0(n227), .Y(n225) );
  NAND2XL U407 ( .A(n266), .B(n224), .Y(n25) );
  NAND2XL U408 ( .A(n256), .B(n149), .Y(n15) );
  NAND2XL U409 ( .A(n254), .B(n137), .Y(n13) );
  NAND2XL U410 ( .A(n258), .B(n169), .Y(n17) );
  NAND2XL U411 ( .A(n250), .B(n101), .Y(n9) );
  NAND2XL U412 ( .A(n246), .B(n63), .Y(n5) );
  NAND2XL U413 ( .A(n260), .B(n187), .Y(n19) );
  NAND2XL U414 ( .A(n248), .B(n81), .Y(n7) );
  NAND2XL U415 ( .A(n252), .B(n119), .Y(n11) );
  INVXL U416 ( .A(n237), .Y(n269) );
  NAND2XL U417 ( .A(n269), .B(n238), .Y(n28) );
  INVXL U418 ( .A(n95), .Y(n97) );
  AOI21XL U419 ( .A0(n113), .A1(n85), .B0(n86), .Y(n84) );
  AOI21XL U420 ( .A0(n55), .A1(n51), .B0(n52), .Y(n50) );
  NAND2XL U421 ( .A(n244), .B(n49), .Y(n3) );
  INVXL U422 ( .A(n69), .Y(n67) );
  INVXL U423 ( .A(n107), .Y(n251) );
  INVXL U424 ( .A(n125), .Y(n253) );
  INVXL U425 ( .A(n193), .Y(n261) );
  AOI21XL U426 ( .A0(n71), .A1(n42), .B0(n43), .Y(n41) );
  NAND2XL U427 ( .A(n243), .B(n40), .Y(n2) );
  INVXL U428 ( .A(n240), .Y(n239) );
  INVXL U429 ( .A(n87), .Y(n249) );
  INVXL U430 ( .A(n155), .Y(n257) );
  INVXL U431 ( .A(n53), .Y(n51) );
  INVXL U432 ( .A(n234), .Y(n268) );
  INVXL U433 ( .A(n62), .Y(n246) );
  INVXL U434 ( .A(n215), .Y(n264) );
  INVXL U435 ( .A(n204), .Y(n262) );
  INVXL U436 ( .A(n148), .Y(n256) );
  INVXL U437 ( .A(n223), .Y(n266) );
  INVXL U438 ( .A(n136), .Y(n254) );
  INVXL U439 ( .A(n168), .Y(n258) );
  INVXL U440 ( .A(n186), .Y(n260) );
  INVXL U441 ( .A(n80), .Y(n248) );
  INVXL U442 ( .A(n118), .Y(n252) );
  INVXL U443 ( .A(n48), .Y(n244) );
  INVXL U444 ( .A(n35), .Y(n243) );
  INVXL U445 ( .A(n229), .Y(n227) );
  AOI21BX1 U446 ( .A0(n131), .A1(n253), .B0N(n126), .Y(n122) );
  AOI21BX1 U447 ( .A0(n75), .A1(n67), .B0N(n70), .Y(n66) );
  NOR2X2 U448 ( .A(A[21]), .B(n278), .Y(n100) );
  INVXL U449 ( .A(n241), .Y(n270) );
  NAND2XL U450 ( .A(n270), .B(n242), .Y(n29) );
  CLKNAND2X2 U451 ( .A(A[26]), .B(n273), .Y(n54) );
  NAND2XL U452 ( .A(A[14]), .B(n285), .Y(n158) );
  NAND2XL U453 ( .A(A[22]), .B(n277), .Y(n90) );
  NAND2X1 U454 ( .A(A[2]), .B(n297), .Y(n238) );
  CLKNAND2X2 U455 ( .A(A[20]), .B(n279), .Y(n108) );
  NAND2X1 U456 ( .A(A[18]), .B(n281), .Y(n126) );
  NAND2X1 U457 ( .A(A[10]), .B(n289), .Y(n194) );
  CLKNAND2X2 U458 ( .A(A[28]), .B(n271), .Y(n40) );
  NAND2XL U459 ( .A(A[21]), .B(n278), .Y(n101) );
  NAND2XL U460 ( .A(A[9]), .B(n290), .Y(n205) );
  NAND2XL U461 ( .A(A[13]), .B(n286), .Y(n169) );
  NAND2XL U462 ( .A(A[3]), .B(n296), .Y(n235) );
  NAND2XL U463 ( .A(A[11]), .B(n288), .Y(n187) );
  NAND2XL U464 ( .A(A[5]), .B(n294), .Y(n224) );
  NAND2XL U465 ( .A(A[7]), .B(n292), .Y(n216) );
  NAND2XL U466 ( .A(A[15]), .B(n284), .Y(n149) );
  NAND2XL U467 ( .A(A[17]), .B(n282), .Y(n137) );
  NAND2XL U468 ( .A(A[27]), .B(n272), .Y(n49) );
  NAND2XL U469 ( .A(A[25]), .B(n274), .Y(n63) );
  NAND2XL U470 ( .A(A[19]), .B(n280), .Y(n119) );
  NAND2XL U471 ( .A(A[23]), .B(n276), .Y(n81) );
  INVXL U472 ( .A(B[28]), .Y(n271) );
  INVXL U473 ( .A(B[10]), .Y(n289) );
  INVX2 U474 ( .A(n44), .Y(n42) );
  INVX2 U475 ( .A(n74), .Y(n72) );
  NOR2X2 U476 ( .A(n178), .B(n144), .Y(n142) );
  NAND2X2 U477 ( .A(n162), .B(n146), .Y(n144) );
  NAND2X2 U478 ( .A(n130), .B(n116), .Y(n110) );
  AOI21X1 U479 ( .A0(n230), .A1(n221), .B0(n222), .Y(n220) );
  NAND2X2 U480 ( .A(n198), .B(n184), .Y(n178) );
  INVX2 U481 ( .A(n179), .Y(n181) );
  INVX2 U482 ( .A(n210), .Y(n209) );
  NAND2X2 U483 ( .A(n180), .B(n162), .Y(n160) );
  NAND2X2 U484 ( .A(n198), .B(n261), .Y(n189) );
  NAND2X2 U485 ( .A(n130), .B(n253), .Y(n121) );
  INVX2 U486 ( .A(n198), .Y(n196) );
  INVX2 U487 ( .A(n130), .Y(n128) );
  NAND2X2 U488 ( .A(n153), .B(n180), .Y(n151) );
  NAND2X2 U489 ( .A(n85), .B(n112), .Y(n83) );
  INVX2 U490 ( .A(n231), .Y(n230) );
  INVX2 U491 ( .A(n131), .Y(n129) );
  OAI21X1 U492 ( .A0(n100), .A1(n108), .B0(n101), .Y(n95) );
  AOI21X1 U493 ( .A0(n213), .A1(n222), .B0(n214), .Y(n212) );
  OAI21X1 U494 ( .A0(n186), .A1(n194), .B0(n187), .Y(n185) );
  OAI21X1 U495 ( .A0(n62), .A1(n70), .B0(n63), .Y(n61) );
  OAI21X2 U496 ( .A0(n111), .A1(n76), .B0(n77), .Y(n75) );
  AOI21X1 U497 ( .A0(n78), .A1(n95), .B0(n79), .Y(n77) );
  AOI21X1 U498 ( .A0(n46), .A1(n61), .B0(n47), .Y(n45) );
  NOR2X2 U499 ( .A(n107), .B(n100), .Y(n94) );
  NOR2X2 U500 ( .A(n155), .B(n148), .Y(n146) );
  OAI21X1 U501 ( .A0(n118), .A1(n126), .B0(n119), .Y(n117) );
  AOI21X1 U502 ( .A0(n232), .A1(n240), .B0(n233), .Y(n231) );
  OAI21X1 U503 ( .A0(n234), .A1(n238), .B0(n235), .Y(n233) );
  NOR2X2 U504 ( .A(n87), .B(n80), .Y(n78) );
  NOR2X2 U505 ( .A(n44), .B(n35), .Y(n33) );
  OAI21X1 U506 ( .A0(n45), .A1(n35), .B0(n36), .Y(n34) );
  NOR2X2 U507 ( .A(n38), .B(A[29]), .Y(n36) );
  XNOR2X1 U508 ( .A(n177), .B(n18), .Y(DIFF[12]) );
  XNOR2X1 U509 ( .A(n71), .B(n6), .Y(DIFF[24]) );
  XNOR2X1 U510 ( .A(n159), .B(n16), .Y(DIFF[14]) );
  XNOR2X1 U511 ( .A(n195), .B(n20), .Y(DIFF[10]) );
  XNOR2X1 U512 ( .A(n91), .B(n8), .Y(DIFF[22]) );
  XNOR2X1 U513 ( .A(n109), .B(n10), .Y(DIFF[20]) );
  XNOR2X1 U514 ( .A(n170), .B(n17), .Y(DIFF[13]) );
  XNOR2X1 U515 ( .A(n206), .B(n21), .Y(DIFF[9]) );
  XNOR2X1 U516 ( .A(n120), .B(n11), .Y(DIFF[19]) );
  XNOR2X1 U517 ( .A(n138), .B(n13), .Y(DIFF[17]) );
  XNOR2X1 U518 ( .A(n64), .B(n5), .Y(DIFF[25]) );
  AOI21X1 U519 ( .A0(n146), .A1(n163), .B0(n147), .Y(n145) );
  OAI21X1 U520 ( .A0(n148), .A1(n158), .B0(n149), .Y(n147) );
  XNOR2X1 U521 ( .A(n127), .B(n12), .Y(DIFF[18]) );
  XNOR2X1 U522 ( .A(n188), .B(n19), .Y(DIFF[11]) );
  XNOR2X1 U523 ( .A(n236), .B(n27), .Y(DIFF[3]) );
  XNOR2X1 U524 ( .A(n217), .B(n23), .Y(DIFF[7]) );
  XNOR2X1 U525 ( .A(n102), .B(n9), .Y(DIFF[21]) );
  XNOR2X1 U526 ( .A(n150), .B(n15), .Y(DIFF[15]) );
  XNOR2X1 U527 ( .A(n82), .B(n7), .Y(DIFF[23]) );
  INVX2 U528 ( .A(n228), .Y(n267) );
  AOI21BX2 U529 ( .A0(n181), .A1(n259), .B0N(n176), .Y(n172) );
  AOI21BX2 U530 ( .A0(n113), .A1(n251), .B0N(n108), .Y(n104) );
  INVX2 U531 ( .A(n100), .Y(n250) );
  INVX2 U532 ( .A(n40), .Y(n38) );
  INVX2 U533 ( .A(n54), .Y(n52) );
  NOR2X2 U534 ( .A(A[22]), .B(n277), .Y(n87) );
  NOR2X2 U535 ( .A(A[14]), .B(n285), .Y(n155) );
  NOR2X2 U536 ( .A(A[20]), .B(n279), .Y(n107) );
  NOR2X2 U537 ( .A(A[28]), .B(n271), .Y(n35) );
  NOR2X2 U538 ( .A(A[18]), .B(n281), .Y(n125) );
  NOR2X2 U539 ( .A(A[23]), .B(n276), .Y(n80) );
  NOR2X2 U540 ( .A(A[7]), .B(n292), .Y(n215) );
  NOR2X2 U541 ( .A(A[2]), .B(n297), .Y(n237) );
  NOR2X2 U542 ( .A(A[11]), .B(n288), .Y(n186) );
  NOR2X2 U543 ( .A(A[6]), .B(n293), .Y(n218) );
  NOR2X2 U544 ( .A(A[8]), .B(n291), .Y(n207) );
  NOR2X2 U545 ( .A(A[16]), .B(n283), .Y(n139) );
  OAI21X1 U546 ( .A0(n241), .A1(\B[0] ), .B0(n242), .Y(n240) );
  NOR2X2 U547 ( .A(A[12]), .B(n287), .Y(n175) );
  NOR2X2 U548 ( .A(A[19]), .B(n280), .Y(n118) );
  NOR2X2 U549 ( .A(A[10]), .B(n289), .Y(n193) );
  NOR2X2 U550 ( .A(A[24]), .B(n275), .Y(n69) );
  NOR2X2 U551 ( .A(A[13]), .B(n286), .Y(n168) );
  NOR2X2 U552 ( .A(A[26]), .B(n273), .Y(n53) );
  NOR2X2 U553 ( .A(A[15]), .B(n284), .Y(n148) );
  NOR2X2 U554 ( .A(A[17]), .B(n282), .Y(n136) );
  NOR2X2 U555 ( .A(A[9]), .B(n290), .Y(n204) );
  NOR2X2 U556 ( .A(A[5]), .B(n294), .Y(n223) );
  NOR2X2 U557 ( .A(A[27]), .B(n272), .Y(n48) );
  NOR2X2 U558 ( .A(A[3]), .B(n296), .Y(n234) );
  NOR2X2 U559 ( .A(A[25]), .B(n274), .Y(n62) );
  NOR2X2 U560 ( .A(A[1]), .B(n298), .Y(n241) );
  INVX2 U561 ( .A(B[17]), .Y(n282) );
  INVX2 U562 ( .A(B[3]), .Y(n296) );
  INVX2 U563 ( .A(B[1]), .Y(n298) );
  INVX2 U564 ( .A(B[21]), .Y(n278) );
  INVX2 U565 ( .A(B[9]), .Y(n290) );
  INVX2 U566 ( .A(B[25]), .Y(n274) );
  INVX2 U567 ( .A(B[5]), .Y(n294) );
  INVX2 U568 ( .A(B[16]), .Y(n283) );
  INVX2 U569 ( .A(B[24]), .Y(n275) );
  INVX2 U570 ( .A(B[20]), .Y(n279) );
  INVX2 U571 ( .A(B[13]), .Y(n286) );
  INVX2 U572 ( .A(B[27]), .Y(n272) );
  INVX2 U573 ( .A(B[19]), .Y(n280) );
  INVX2 U574 ( .A(B[26]), .Y(n273) );
  INVX2 U575 ( .A(B[7]), .Y(n292) );
  INVX2 U576 ( .A(B[12]), .Y(n287) );
  INVX2 U577 ( .A(B[11]), .Y(n288) );
  INVX2 U578 ( .A(B[22]), .Y(n277) );
  INVX2 U579 ( .A(B[14]), .Y(n285) );
  INVX2 U580 ( .A(B[8]), .Y(n291) );
  INVX2 U581 ( .A(B[4]), .Y(n295) );
  NOR2X2 U582 ( .A(n53), .B(n48), .Y(n46) );
  NAND2X2 U583 ( .A(A[4]), .B(n295), .Y(n229) );
  XOR2XL U584 ( .A(n1), .B(n14), .Y(DIFF[16]) );
  OAI21XL U585 ( .A0(n1), .A1(n83), .B0(n84), .Y(n82) );
  OAI21XL U586 ( .A0(n1), .A1(n121), .B0(n122), .Y(n120) );
  OAI21XL U587 ( .A0(n1), .A1(n103), .B0(n104), .Y(n102) );
  OAI21XL U588 ( .A0(n1), .A1(n110), .B0(n111), .Y(n109) );
  OAI21XL U589 ( .A0(n1), .A1(n65), .B0(n66), .Y(n64) );
  OAI21XL U590 ( .A0(n1), .A1(n139), .B0(n140), .Y(n138) );
  OAI21XL U591 ( .A0(n1), .A1(n92), .B0(n93), .Y(n91) );
  OAI21XL U592 ( .A0(n1), .A1(n128), .B0(n129), .Y(n127) );
  OAI21XL U593 ( .A0(n1), .A1(n56), .B0(n57), .Y(n55) );
  OAI21X1 U594 ( .A0(n1), .A1(n31), .B0(n32), .Y(n30) );
  XNOR2X1 U595 ( .A(n55), .B(n4), .Y(DIFF[26]) );
  AOI21X1 U596 ( .A0(n75), .A1(n33), .B0(n34), .Y(n32) );
endmodule


module norm_v4_29 ( clk, reset_n, magnitude, denominator, result, 
        combinational_result );
  input [28:0] magnitude;
  input [28:0] denominator;
  output [16:0] result;
  output [16:0] combinational_result;
  input clk, reset_n;
  wire   N48, N49, N50, N51, N52, N53, N54, N55, N56, N57, N58, N59, N60, N61,
         N62, N63, N64, N65, N66, N67, N68, N69, N70, N71, N72, N73, N74, N75,
         N76, N77, N78, N81, N105, N109, N110, N111, N112, N113, N114, N115,
         N116, N117, N118, N119, N120, N121, N122, N123, N124, N125, N126,
         N127, N128, N129, N130, N131, N132, N133, N134, N135, N136, N137,
         N138, N139, N142, N144, N145, N146, N147, N148, N149, N150, N151,
         N152, N153, N154, N155, N156, N157, N158, N159, N160, N161, N162,
         N163, N164, N165, N166, N167, N168, N170, N171, N172, N173, N174,
         N175, N176, N177, N178, N179, N180, N181, N182, N183, N184, N185,
         N186, N187, N188, N189, N190, N191, N192, N193, N194, N195, N196,
         N197, N198, N199, N200, N203, N205, N206, N207, N208, N209, N210,
         N211, N212, N213, N214, N215, N216, N217, N218, N219, N220, N221,
         N222, N223, N224, N225, N226, N227, N228, N229, N231, N232, N233,
         N234, N235, N236, N237, N238, N239, N240, N241, N242, N243, N244,
         N245, N246, N247, N248, N249, N250, N251, N252, N253, N254, N255,
         N256, N257, N258, N259, N260, N261, N264, N266, N267, N268, N269,
         N270, N271, N272, N273, N274, N275, N276, N277, N278, N279, N280,
         N281, N282, N283, N284, N285, N286, N287, N288, N289, N290, N292,
         N293, N294, N295, N296, N297, N298, N299, N300, N301, N302, N303,
         N304, N305, N306, N307, N308, N309, N310, N311, N312, N313, N314,
         N315, N316, N317, N318, N319, N320, N321, N322, N325, N327, N328,
         N329, N330, N331, N332, N333, N334, N335, N336, N337, N338, N339,
         N340, N341, N342, N343, N344, N345, N346, N347, N348, N349, N350,
         N351, N353, N354, N355, N356, N357, N358, N359, N360, N361, N362,
         N363, N364, N365, N366, N367, N368, N369, N370, N371, N372, N373,
         N374, N375, N376, N377, N378, N379, N380, N381, N382, N383, N386,
         N388, N389, N390, N391, N392, N393, N394, N395, N396, N397, N398,
         N399, N400, N401, N402, N403, N404, N405, N406, N407, N408, N409,
         N410, N411, N412, N414, N415, N416, N417, N418, N419, N420, N421,
         N422, N423, N424, N425, N426, N427, N428, N429, N430, N431, N432,
         N433, N434, N435, N436, N437, N438, N439, N440, N441, N442, N443,
         N444, N447, N449, N450, N451, N452, N453, N454, N455, N456, N457,
         N458, N459, N460, N461, N462, N463, N464, N465, N466, N467, N468,
         N469, N470, N471, N472, N473, N475, N476, N477, N478, N479, N480,
         N481, N482, N483, N484, N485, N486, N487, N488, N489, N490, N491,
         N492, N493, N494, N495, N496, N497, N498, N499, N500, N501, N502,
         N503, N504, N505, N508, N510, N511, N512, N513, N514, N515, N516,
         N517, N518, N519, N520, N521, N522, N523, N524, N525, N526, N527,
         N528, N529, N530, N531, N532, N533, N534, N536, N537, N538, N539,
         N540, N541, N542, N543, N544, N545, N546, N547, N548, N549, N550,
         N551, N552, N553, N554, N555, N556, N557, N558, N559, N560, N561,
         N562, N563, N564, N565, N566, N569, N571, N572, N573, N574, N575,
         N576, N577, N578, N579, N580, N581, N582, N583, N584, N585, N586,
         N587, N588, N589, N590, N591, N592, N593, N594, N595, N597, N598,
         N599, N600, N601, N602, N603, N604, N605, N606, N607, N608, N609,
         N610, N611, N612, N613, N614, N615, N616, N617, N618, N619, N620,
         N621, N622, N623, N624, N625, N626, N627, N630, N632, N633, N634,
         N635, N636, N637, N638, N639, N640, N641, N642, N643, N644, N645,
         N646, N647, N648, N649, N650, N651, N652, N653, N654, N655, N656,
         N658, N659, N660, N661, N662, N663, N664, N665, N666, N667, N668,
         N669, N670, N671, N672, N673, N674, N675, N676, N677, N678, N679,
         N680, N681, N682, N683, N684, N685, N686, N687, N688, N691, N693,
         N694, N695, N696, N697, N698, N699, N700, N701, N702, N703, N704,
         N705, N706, N707, N708, N709, N710, N711, N712, N713, N714, N715,
         N716, N717, N719, N720, N721, N722, N723, N724, N725, N726, N727,
         N728, N729, N730, N731, N732, N733, N734, N735, N736, N737, N738,
         N739, N740, N741, N742, N743, N744, N745, N746, N747, N748, N749,
         N752, N754, N755, N756, N757, N758, N759, N760, N761, N762, N763,
         N764, N765, N766, N767, N768, N769, N770, N771, N772, N773, N774,
         N775, N776, N777, N778, N780, N781, N782, N783, N784, N785, N786,
         N787, N788, N789, N790, N791, N792, N793, N794, N795, N796, N797,
         N798, N799, N800, N801, N802, N803, N804, N805, N806, N807, N808,
         N809, N810, N813, N815, N816, N817, N818, N819, N820, N821, N822,
         N823, N824, N825, N826, N827, N828, N829, N830, N831, N832, N833,
         N834, N835, N836, N837, N838, N839, N841, N842, N843, N844, N845,
         N846, N847, N848, N849, N850, N851, N852, N853, N854, N855, N856,
         N857, N858, N859, N860, N861, N862, N863, N864, N865, N866, N867,
         N868, N869, N870, N871, N902, N903, N904, N905, N906, N907, N908,
         N909, N910, N911, N912, N913, N914, N915, N916, N917, N918, N919,
         N920, N921, N922, N923, N924, N925, N926, N927, N928, N929, N930,
         N931, N932, N935, N936, N937, N938, N939, N940, N941, N942, N943,
         N944, N945, N946, N947, N948, N949, N950, N951, N952, N953, N954,
         N955, N956, N957, N958, N959, N960, N961, N962, N963, N964, n125,
         n126, n127, n128, n129, n130, n17, n18, n19, n20, n21, n22, n23, n24,
         n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35, n36, n37, n38,
         n39, n40, n41, n42, n43, n44, n45, n46, n47, n48, n49, n50, n51, n52,
         n53, n54, n55, n56, n57, n58, n59, n60, n61, n62, n63, n64, n65, n66,
         n68, n69, n70, n71, n72, n73, n74, n75, n76, n77, n78, n79, n80, n81,
         n82, n83, n84, n85, n86, n87, n88, n89, n90, n91, n92, n93, n94, n95,
         n96, n97, n98, n99, n100, n101, n102, n103, n104, n105, n106, n107,
         n108, n109, n110, n111, n112, n113, n114, n115, n116, n117, n118,
         n119, n120, n121, n122, n123, n124, n131, n132, n133, n134, n135,
         n136, n137, n138, n139, n140, n141, n142, n143, n144, n145, n146,
         n147, n148, n149, n150, n151, n152, n153, n154, n155, n156, n157,
         n158, n159, n160, n161, n162, n163, n164, n165, n166, n167, n168,
         n169, n170, n171, n172, n173, n174, n175, n176, n177, n178, n179,
         n180, n181, n182, n183, n184, n185, n186, n187, n188, n189, n190,
         n191, n192, n193, n194, n195, n196, n197, n198, n199, n200, n201,
         n202, n203, n204, n205, n206, n207, n208, n209, n210, n211, n212,
         n213, n214, n215, n216, n217, n218, n219, n220, n221, n222, n223,
         n224, n225, n226, n227, n228, n229, n230, n231, n232, n233, n234,
         n235, n236, n237, n238, n239, n240, n241, n242, n243, n244, n245,
         n246, n247, n248, n249, n250, n251, n252, n253, n254, n255, n256,
         n257, n258, n259, n260, n261, n262, n263, n264, n265, n266, n267,
         n268, n269, n270, n271, n272, n273, n274, n275, n276, n277, n278,
         n279, n280, n281, n282, n283, n284, n285, n286, n287, n288, n289,
         n290, n291, n292, n293, n294, n295, n296, n297, n298, n299, n300,
         n301, n302, n303, n304, n305, n306, n307;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7, 
        SYNOPSYS_UNCONNECTED__8, SYNOPSYS_UNCONNECTED__9, 
        SYNOPSYS_UNCONNECTED__10, SYNOPSYS_UNCONNECTED__11, 
        SYNOPSYS_UNCONNECTED__12, SYNOPSYS_UNCONNECTED__13, 
        SYNOPSYS_UNCONNECTED__14, SYNOPSYS_UNCONNECTED__15, 
        SYNOPSYS_UNCONNECTED__16, SYNOPSYS_UNCONNECTED__17, 
        SYNOPSYS_UNCONNECTED__18, SYNOPSYS_UNCONNECTED__19, 
        SYNOPSYS_UNCONNECTED__20, SYNOPSYS_UNCONNECTED__21, 
        SYNOPSYS_UNCONNECTED__22, SYNOPSYS_UNCONNECTED__23, 
        SYNOPSYS_UNCONNECTED__24, SYNOPSYS_UNCONNECTED__25, 
        SYNOPSYS_UNCONNECTED__26, SYNOPSYS_UNCONNECTED__27, 
        SYNOPSYS_UNCONNECTED__28, SYNOPSYS_UNCONNECTED__29, 
        SYNOPSYS_UNCONNECTED__30, SYNOPSYS_UNCONNECTED__31, 
        SYNOPSYS_UNCONNECTED__32, SYNOPSYS_UNCONNECTED__33, 
        SYNOPSYS_UNCONNECTED__34, SYNOPSYS_UNCONNECTED__35, 
        SYNOPSYS_UNCONNECTED__36, SYNOPSYS_UNCONNECTED__37, 
        SYNOPSYS_UNCONNECTED__38, SYNOPSYS_UNCONNECTED__39, 
        SYNOPSYS_UNCONNECTED__40, SYNOPSYS_UNCONNECTED__41, 
        SYNOPSYS_UNCONNECTED__42, SYNOPSYS_UNCONNECTED__43, 
        SYNOPSYS_UNCONNECTED__44;

  norm_v4_29_DW01_sub_16 sub_66_I16_C74 ( .A({1'b0, N963, N962, N961, N960, 
        N959, N958, N957, N956, N955, N954, N953, N952, N951, N950, N949, N948, 
        N947, N946, N945, N944, N943, N942, N941, N940, N939, N938, N937, N936, 
        N935, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N964, 
        SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2, SYNOPSYS_UNCONNECTED__3, 
        SYNOPSYS_UNCONNECTED__4, SYNOPSYS_UNCONNECTED__5, 
        SYNOPSYS_UNCONNECTED__6, SYNOPSYS_UNCONNECTED__7, 
        SYNOPSYS_UNCONNECTED__8, SYNOPSYS_UNCONNECTED__9, 
        SYNOPSYS_UNCONNECTED__10, SYNOPSYS_UNCONNECTED__11, 
        SYNOPSYS_UNCONNECTED__12, SYNOPSYS_UNCONNECTED__13, 
        SYNOPSYS_UNCONNECTED__14, SYNOPSYS_UNCONNECTED__15, 
        SYNOPSYS_UNCONNECTED__16, SYNOPSYS_UNCONNECTED__17, 
        SYNOPSYS_UNCONNECTED__18, SYNOPSYS_UNCONNECTED__19, 
        SYNOPSYS_UNCONNECTED__20, SYNOPSYS_UNCONNECTED__21, 
        SYNOPSYS_UNCONNECTED__22, SYNOPSYS_UNCONNECTED__23, 
        SYNOPSYS_UNCONNECTED__24, SYNOPSYS_UNCONNECTED__25, 
        SYNOPSYS_UNCONNECTED__26, SYNOPSYS_UNCONNECTED__27, 
        SYNOPSYS_UNCONNECTED__28, SYNOPSYS_UNCONNECTED__29}) );
  norm_v4_29_DW01_sub_42 sub_66_I4_C74 ( .A({1'b0, N231, n278, N229, N228, 
        N227, N226, N225, N224, N223, N222, N221, N220, N219, N218, N217, N216, 
        N215, N214, N213, N212, N211, N210, N209, N208, N207, N206, N205, n18, 
        N203, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n80, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N261, 
        SYNOPSYS_UNCONNECTED__30, N260, N259, N258, N257, N256, N255, N254, 
        N253, N252, N251, N250, N249, N248, N247, N246, N245, N244, N243, N242, 
        N241, N240, N239, N238, N237, N236, N235, N234, N233, N232}) );
  norm_v4_29_DW01_sub_43 sub_66_I3_C74 ( .A({1'b0, N170, n279, N168, N167, 
        N166, N165, N164, N163, N162, N161, N160, N159, N158, N157, N156, N155, 
        N154, N153, N152, N151, N150, N149, N148, N147, N146, N145, N144, n43, 
        N142, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n80, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N200, 
        SYNOPSYS_UNCONNECTED__31, N199, N198, N197, N196, N195, N194, N193, 
        N192, N191, N190, N189, N188, N187, N186, N185, N184, N183, N182, N181, 
        N180, N179, N178, N177, N176, N175, N174, N173, N172, N171}) );
  norm_v4_29_DW01_sub_46 sub_66_I5_C74 ( .A({1'b0, N292, n277, N290, N289, 
        N288, N287, N286, N285, N284, N283, N282, N281, N280, N279, N278, N277, 
        N276, N275, N274, N273, N272, N271, N270, N269, N268, N267, N266, n31, 
        N264, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N322, 
        SYNOPSYS_UNCONNECTED__32, N321, N320, N319, N318, N317, N316, N315, 
        N314, N313, N312, N311, N310, N309, N308, N307, N306, N305, N304, N303, 
        N302, N301, N300, N299, N298, N297, N296, N295, N294, N293}) );
  norm_v4_29_DW01_sub_33 sub_66_I12_C74 ( .A({1'b0, N719, n270, N717, N716, 
        N715, N714, N713, N712, N711, N710, N709, N708, N707, N706, N705, N704, 
        N703, N702, N701, N700, N699, N698, N697, N696, N695, N694, N693, n46, 
        N691, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N749, 
        SYNOPSYS_UNCONNECTED__33, N748, N747, N746, N745, N744, N743, N742, 
        N741, N740, N739, N738, N737, N736, N735, N734, N733, N732, N731, N730, 
        N729, N728, N727, N726, N725, N724, N723, N722, N721, N720}) );
  norm_v4_29_DW01_sub_34 sub_66_I11_C74 ( .A({1'b0, N658, n271, N656, N655, 
        N654, N653, N652, N651, N650, N649, N648, N647, N646, N645, N644, N643, 
        N642, N641, N640, N639, N638, N637, N636, N635, N634, N633, N632, n26, 
        N630, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N688, 
        SYNOPSYS_UNCONNECTED__34, N687, N686, N685, N684, N683, N682, N681, 
        N680, N679, N678, N677, N676, N675, N674, N673, N672, N671, N670, N669, 
        N668, N667, N666, N665, N664, N663, N662, N661, N660, N659}) );
  norm_v4_29_DW01_sub_36 sub_66_I13_C74 ( .A({1'b0, N780, n269, N778, N777, 
        N776, N775, N774, N773, N772, N771, N770, N769, N768, N767, N766, N765, 
        N764, N763, N762, N761, N760, N759, N758, N757, N756, N755, N754, n17, 
        N752, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N810, 
        SYNOPSYS_UNCONNECTED__35, N809, N808, N807, N806, N805, N804, N803, 
        N802, N801, N800, N799, N798, N797, N796, N795, N794, N793, N792, N791, 
        N790, N789, N788, N787, N786, N785, N784, N783, N782, N781}) );
  norm_v4_29_DW01_sub_37 sub_66_I10_C74 ( .A({1'b0, N597, n272, N595, N594, 
        N593, N592, N591, N590, N589, N588, N587, N586, N585, N584, N583, N582, 
        N581, N580, N579, N578, N577, N576, N575, N574, N573, N572, N571, n27, 
        N569, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N627, 
        SYNOPSYS_UNCONNECTED__36, N626, N625, N624, N623, N622, N621, N620, 
        N619, N618, N617, N616, N615, N614, N613, N612, N611, N610, N609, N608, 
        N607, N606, N605, N604, N603, N602, N601, N600, N599, N598}) );
  norm_v4_29_DW01_sub_39 sub_66_I9_C74 ( .A({1'b0, N536, n273, N534, N533, 
        N532, N531, N530, N529, N528, N527, N526, N525, N524, N523, N522, N521, 
        N520, N519, N518, N517, N516, N515, N514, N513, N512, N511, N510, n25, 
        N508, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N566, 
        SYNOPSYS_UNCONNECTED__37, N565, N564, N563, N562, N561, N560, N559, 
        N558, N557, N556, N555, N554, N553, N552, N551, N550, N549, N548, N547, 
        N546, N545, N544, N543, N542, N541, N540, N539, N538, N537}) );
  norm_v4_29_DW01_sub_40 sub_66_I8_C74 ( .A({1'b0, N475, n274, N473, N472, 
        N471, N470, N469, N468, N467, N466, N465, N464, N463, N462, N461, N460, 
        N459, N458, N457, N456, N455, N454, N453, N452, N451, N450, N449, n30, 
        N447, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N505, 
        SYNOPSYS_UNCONNECTED__38, N504, N503, N502, N501, N500, N499, N498, 
        N497, N496, N495, N494, N493, N492, N491, N490, N489, N488, N487, N486, 
        N485, N484, N483, N482, N481, N480, N479, N478, N477, N476}) );
  norm_v4_29_DW01_sub_44 sub_66_I7_C74 ( .A({1'b0, N414, n275, N412, N411, 
        N410, N409, N408, N407, N406, N405, N404, N403, N402, N401, N400, N399, 
        N398, N397, N396, N395, N394, N393, N392, N391, N390, N389, N388, n39, 
        N386, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N444, 
        SYNOPSYS_UNCONNECTED__39, N443, N442, N441, N440, N439, N438, N437, 
        N436, N435, N434, N433, N432, N431, N430, N429, N428, N427, N426, N425, 
        N424, N423, N422, N421, N420, N419, N418, N417, N416, N415}) );
  norm_v4_29_DW01_sub_45 sub_66_I6_C74 ( .A({1'b0, N353, n276, N351, N350, 
        N349, N348, N347, N346, N345, N344, N343, N342, N341, N340, N339, N338, 
        N337, N336, N335, N334, N333, N332, N331, N330, N329, N328, N327, n45, 
        N325, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N383, 
        SYNOPSYS_UNCONNECTED__40, N382, N381, N380, N379, N378, N377, N376, 
        N375, N374, N373, N372, N371, N370, N369, N368, N367, N366, N365, N364, 
        N363, N362, N361, N360, N359, N358, N357, N356, N355, N354}) );
  norm_v4_29_DW01_sub_35 sub_66_I14_C74 ( .A({1'b0, N841, n268, N839, N838, 
        N837, N836, N835, N834, N833, N832, N831, N830, N829, N828, N827, N826, 
        N825, N824, N823, N822, N821, N820, N819, N818, N817, N816, N815, n41, 
        N813, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N871, 
        SYNOPSYS_UNCONNECTED__41, N870, N869, N868, N867, N866, N865, N864, 
        N863, N862, N861, N860, N859, N858, N857, N856, N855, N854, N853, N852, 
        N851, N850, N849, N848, N847, N846, N845, N844, N843, N842}) );
  norm_v4_29_DW01_sub_47 sub_66_C74 ( .A({1'b0, N48, n289, n288, n287, n286, 
        n285, n284, n283, n282, n281, n280, n307, n306, n305, n304, n303, n302, 
        n301, n300, n299, n298, n297, n296, n295, n294, n293, n292, n291, n290, 
        1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, n88, 
        n87, n86, n85, n84, n83, n82, n81, n80, n79, n78, n77, n76, n75, n74, 
        n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N78, 
        SYNOPSYS_UNCONNECTED__42, N77, N76, N75, N74, N73, N72, N71, N70, N69, 
        N68, N67, N66, N65, N64, N63, N62, N61, N60, N59, N58, N57, N56, N55, 
        N54, N53, N52, N51, N50, N49}) );
  norm_v4_29_DW01_sub_41 sub_66_I2_C74 ( .A({1'b0, N109, n47, n50, n22, N105, 
        n19, n28, n24, n55, n20, n54, n42, n36, n40, n48, n38, n53, n32, n52, 
        n33, n51, n21, n37, n49, n34, n29, n35, n23, N81, 1'b0}), .B({1'b0, 
        1'b0, n96, n95, n94, n93, n92, n91, n90, n89, n88, n87, n86, n85, n84, 
        n83, n82, n81, n80, n79, n78, n77, n76, n75, n74, n73, n72, n71, n70, 
        n69, n133}), .CI(1'b0), .DIFF({N139, SYNOPSYS_UNCONNECTED__43, N138, 
        N137, N136, N135, N134, N133, N132, N131, N130, N129, N128, N127, N126, 
        N125, N124, N123, N122, N121, N120, N119, N118, N117, N116, N115, N114, 
        N113, N112, N111, N110}) );
  norm_v4_29_DW01_sub_38 sub_66_I15_C74 ( .A({1'b0, N902, n241, n242, n243, 
        n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254, n255, 
        n256, n257, n258, n259, n260, n261, n262, n263, n264, n265, n266, n44, 
        n267, 1'b0}), .B({1'b0, 1'b0, n96, n95, n94, n93, n92, n91, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81, n66, n79, n78, n77, n76, n75, 
        n74, n73, n72, n71, n70, n69, n133}), .CI(1'b0), .DIFF({N932, 
        SYNOPSYS_UNCONNECTED__44, N931, N930, N929, N928, N927, N926, N925, 
        N924, N923, N922, N921, N920, N919, N918, N917, N916, N915, N914, N913, 
        N912, N911, N910, N909, N908, N907, N906, N905, N904, N903}) );
  DFFRQX2 \result_reg[16]  ( .D(combinational_result[16]), .CK(clk), .RN(
        reset_n), .Q(result[16]) );
  DFFRQX2 \result_reg[15]  ( .D(combinational_result[15]), .CK(clk), .RN(
        reset_n), .Q(result[15]) );
  DFFRQX2 \result_reg[14]  ( .D(combinational_result[14]), .CK(clk), .RN(
        reset_n), .Q(result[14]) );
  DFFRQX2 \result_reg[13]  ( .D(combinational_result[13]), .CK(clk), .RN(
        reset_n), .Q(result[13]) );
  DFFRQX2 \result_reg[12]  ( .D(combinational_result[12]), .CK(clk), .RN(
        reset_n), .Q(result[12]) );
  DFFRQX2 \result_reg[11]  ( .D(combinational_result[11]), .CK(clk), .RN(
        reset_n), .Q(result[11]) );
  DFFRQX2 \result_reg[10]  ( .D(combinational_result[10]), .CK(clk), .RN(
        reset_n), .Q(result[10]) );
  DFFRQX2 \result_reg[9]  ( .D(combinational_result[9]), .CK(clk), .RN(reset_n), .Q(result[9]) );
  DFFRQX2 \result_reg[8]  ( .D(combinational_result[8]), .CK(clk), .RN(reset_n), .Q(result[8]) );
  DFFRQX2 \result_reg[7]  ( .D(combinational_result[7]), .CK(clk), .RN(reset_n), .Q(result[7]) );
  DFFRQX2 \result_reg[6]  ( .D(combinational_result[6]), .CK(clk), .RN(reset_n), .Q(result[6]) );
  DFFRQX2 \result_reg[5]  ( .D(combinational_result[5]), .CK(clk), .RN(reset_n), .Q(result[5]) );
  DFFRQX2 \result_reg[4]  ( .D(combinational_result[4]), .CK(clk), .RN(reset_n), .Q(result[4]) );
  DFFRQX2 \result_reg[3]  ( .D(combinational_result[3]), .CK(clk), .RN(reset_n), .Q(result[3]) );
  DFFRQX2 \result_reg[2]  ( .D(combinational_result[2]), .CK(clk), .RN(reset_n), .Q(result[2]) );
  DFFRQX2 \result_reg[1]  ( .D(combinational_result[1]), .CK(clk), .RN(reset_n), .Q(result[1]) );
  DFFRQX1 \result_reg[0]  ( .D(combinational_result[0]), .CK(clk), .RN(reset_n), .Q(result[0]) );
  NAND2BX2 U3 ( .AN(n116), .B(N354), .Y(n210) );
  INVX10 U4 ( .A(n117), .Y(n116) );
  CLKBUFX4 U5 ( .A(denominator[23]), .Y(n91) );
  CLKBUFX4 U6 ( .A(denominator[6]), .Y(n74) );
  NOR4XL U7 ( .A(n73), .B(n72), .C(n71), .D(n70), .Y(n127) );
  BUFX12 U8 ( .A(denominator[11]), .Y(n79) );
  INVX4 U9 ( .A(n85), .Y(n163) );
  BUFX12 U10 ( .A(denominator[17]), .Y(n85) );
  NOR4XL U11 ( .A(n83), .B(n82), .C(n81), .D(n66), .Y(n129) );
  INVX4 U12 ( .A(n84), .Y(n164) );
  BUFX12 U13 ( .A(denominator[16]), .Y(n84) );
  XNOR2X4 U14 ( .A(n92), .B(magnitude[24]), .Y(n158) );
  BUFX12 U15 ( .A(denominator[24]), .Y(n92) );
  XOR2X8 U16 ( .A(n77), .B(magnitude[9]), .Y(n62) );
  BUFX12 U17 ( .A(denominator[9]), .Y(n77) );
  NOR3XL U18 ( .A(n86), .B(n85), .C(n84), .Y(n220) );
  XNOR2X4 U19 ( .A(magnitude[18]), .B(n86), .Y(n169) );
  CLKINVX24 U36 ( .A(n119), .Y(n118) );
  INVX4 U37 ( .A(N322), .Y(n119) );
  CLKINVX24 U38 ( .A(n113), .Y(n112) );
  INVX4 U39 ( .A(N505), .Y(n113) );
  CLKINVX24 U40 ( .A(n103), .Y(n102) );
  INVX4 U41 ( .A(N871), .Y(n103) );
  INVX12 U42 ( .A(n107), .Y(n106) );
  CLKINVX6 U43 ( .A(N688), .Y(n107) );
  CLKINVX20 U44 ( .A(n115), .Y(n114) );
  INVX4 U45 ( .A(N444), .Y(n115) );
  NAND2BXL U46 ( .AN(n110), .B(N537), .Y(n213) );
  CLKMX2X3 U47 ( .A(N554), .B(N524), .S0(n110), .Y(N586) );
  MX2X2 U48 ( .A(N545), .B(N515), .S0(n110), .Y(N577) );
  MX2XL U49 ( .A(N538), .B(N508), .S0(n110), .Y(n27) );
  CLKMX2X3 U50 ( .A(N544), .B(N514), .S0(n110), .Y(N576) );
  CLKMX2X3 U51 ( .A(N552), .B(N522), .S0(n110), .Y(N584) );
  INVX12 U52 ( .A(n111), .Y(n110) );
  CLKMX2X3 U53 ( .A(N910), .B(n262), .S0(n98), .Y(N942) );
  CLKMX2X3 U54 ( .A(N908), .B(n264), .S0(n98), .Y(N940) );
  CLKMX2X3 U55 ( .A(N917), .B(n255), .S0(n98), .Y(N949) );
  CLKMX2X3 U56 ( .A(N913), .B(n259), .S0(n98), .Y(N945) );
  MX2X1 U57 ( .A(N911), .B(n261), .S0(n98), .Y(N943) );
  INVX6 U58 ( .A(n100), .Y(n98) );
  CLKINVX1 U59 ( .A(n97), .Y(n101) );
  INVX5 U60 ( .A(n101), .Y(n99) );
  NAND2BXL U61 ( .AN(n122), .B(N171), .Y(n207) );
  CLKMX2X3 U62 ( .A(N178), .B(N148), .S0(n122), .Y(N210) );
  CLKMX2X3 U63 ( .A(N173), .B(n43), .S0(n122), .Y(N205) );
  MX2X2 U64 ( .A(N181), .B(N151), .S0(n122), .Y(N213) );
  CLKMX2X2 U65 ( .A(N174), .B(N144), .S0(n122), .Y(N206) );
  MX2XL U66 ( .A(N179), .B(N149), .S0(n122), .Y(N211) );
  INVX14 U67 ( .A(n123), .Y(n122) );
  MX2XL U68 ( .A(N198), .B(N168), .S0(n122), .Y(n278) );
  MX2XL U69 ( .A(N197), .B(N167), .S0(n122), .Y(N229) );
  MX2XL U70 ( .A(N188), .B(N158), .S0(n122), .Y(N220) );
  MX2XL U71 ( .A(N191), .B(N161), .S0(n122), .Y(N223) );
  MX2XL U72 ( .A(N189), .B(N159), .S0(n122), .Y(N221) );
  MX2XL U73 ( .A(N195), .B(N165), .S0(n122), .Y(N227) );
  MX2XL U74 ( .A(N194), .B(N164), .S0(n122), .Y(N226) );
  MX2XL U75 ( .A(N180), .B(N150), .S0(n122), .Y(N212) );
  MX2XL U76 ( .A(N187), .B(N157), .S0(n122), .Y(N219) );
  CLKMX2X2 U77 ( .A(N172), .B(N142), .S0(n122), .Y(n18) );
  INVX14 U78 ( .A(n121), .Y(n120) );
  INVX4 U79 ( .A(N261), .Y(n121) );
  INVX10 U80 ( .A(n109), .Y(n108) );
  INVX4 U81 ( .A(N627), .Y(n109) );
  INVX18 U82 ( .A(n105), .Y(n104) );
  INVX4 U83 ( .A(N810), .Y(n105) );
  INVX10 U84 ( .A(n131), .Y(n124) );
  CLKINVX4 U85 ( .A(N139), .Y(n131) );
  BUFX12 U86 ( .A(denominator[1]), .Y(n69) );
  BUFX12 U87 ( .A(denominator[7]), .Y(n75) );
  BUFX12 U88 ( .A(denominator[22]), .Y(n90) );
  BUFX12 U89 ( .A(denominator[25]), .Y(n93) );
  NOR3XL U90 ( .A(n90), .B(n92), .C(n91), .Y(n125) );
  XNOR2XL U91 ( .A(n91), .B(n153), .Y(n156) );
  NOR4XL U92 ( .A(n77), .B(n76), .C(n75), .D(n74), .Y(n128) );
  XNOR2XL U93 ( .A(n74), .B(n154), .Y(n155) );
  CLKBUFX40 U94 ( .A(N78), .Y(n132) );
  NAND2X2 U95 ( .A(n57), .B(n58), .Y(n147) );
  CLKNAND2X2 U96 ( .A(n56), .B(magnitude[8]), .Y(n58) );
  MX2X2 U97 ( .A(N135), .B(N105), .S0(n124), .Y(N167) );
  NOR4X2 U98 ( .A(n62), .B(n147), .C(n146), .D(n145), .Y(n148) );
  XOR2X1 U99 ( .A(magnitude[10]), .B(denominator[10]), .Y(n145) );
  BUFX8 U100 ( .A(denominator[28]), .Y(n96) );
  MX2X1 U101 ( .A(N118), .B(n21), .S0(n124), .Y(N150) );
  MX2X1 U102 ( .A(N136), .B(n22), .S0(n124), .Y(N168) );
  BUFX2 U103 ( .A(denominator[12]), .Y(n80) );
  CLKBUFX4 U104 ( .A(denominator[18]), .Y(n86) );
  BUFX2 U105 ( .A(denominator[15]), .Y(n83) );
  BUFX2 U106 ( .A(denominator[3]), .Y(n71) );
  BUFX2 U107 ( .A(denominator[2]), .Y(n70) );
  BUFX5 U108 ( .A(denominator[8]), .Y(n76) );
  XNOR2X1 U109 ( .A(n75), .B(magnitude[7]), .Y(n60) );
  XNOR2X1 U110 ( .A(n69), .B(magnitude[1]), .Y(n59) );
  XOR2X1 U111 ( .A(magnitude[0]), .B(n134), .Y(n61) );
  OR4X2 U112 ( .A(n138), .B(n137), .C(n136), .D(n135), .Y(n151) );
  AND4X2 U113 ( .A(n148), .B(n63), .C(n64), .D(n65), .Y(n149) );
  BUFX2 U114 ( .A(denominator[10]), .Y(n78) );
  INVX2 U115 ( .A(N566), .Y(n111) );
  INVX2 U116 ( .A(N383), .Y(n117) );
  INVX2 U117 ( .A(N200), .Y(n123) );
  INVX2 U118 ( .A(denominator[0]), .Y(n134) );
  MX2X1 U119 ( .A(N721), .B(N691), .S0(N749), .Y(n17) );
  MX2X1 U120 ( .A(N72), .B(n284), .S0(n132), .Y(n19) );
  MX2X1 U121 ( .A(N68), .B(n280), .S0(n132), .Y(n20) );
  MX2X1 U122 ( .A(N56), .B(n296), .S0(n132), .Y(n21) );
  MX2X1 U123 ( .A(N74), .B(n286), .S0(n132), .Y(n22) );
  MX2X1 U124 ( .A(N50), .B(n290), .S0(n132), .Y(n23) );
  MX2X1 U125 ( .A(N70), .B(n282), .S0(n132), .Y(n24) );
  MX2X1 U126 ( .A(N477), .B(N447), .S0(n112), .Y(n25) );
  MX2X1 U127 ( .A(N599), .B(N569), .S0(n108), .Y(n26) );
  MX2X1 U128 ( .A(N71), .B(n283), .S0(n132), .Y(n28) );
  MX2X1 U129 ( .A(N52), .B(n292), .S0(n132), .Y(n29) );
  MX2X1 U130 ( .A(N416), .B(N386), .S0(n114), .Y(n30) );
  MX2X1 U131 ( .A(N233), .B(N203), .S0(n120), .Y(n31) );
  MX2X1 U132 ( .A(N60), .B(n300), .S0(n132), .Y(n32) );
  MX2X1 U133 ( .A(N58), .B(n298), .S0(n132), .Y(n33) );
  MX2X1 U134 ( .A(N53), .B(n293), .S0(n132), .Y(n34) );
  MX2X1 U135 ( .A(N51), .B(n291), .S0(n132), .Y(n35) );
  MX2X1 U136 ( .A(N65), .B(n305), .S0(n132), .Y(n36) );
  MX2X1 U137 ( .A(N55), .B(n295), .S0(n132), .Y(n37) );
  MX2X1 U138 ( .A(N62), .B(n302), .S0(n132), .Y(n38) );
  MX2X1 U139 ( .A(N355), .B(N325), .S0(n116), .Y(n39) );
  MX2X1 U140 ( .A(N64), .B(n304), .S0(n132), .Y(n40) );
  MX2X1 U141 ( .A(N782), .B(N752), .S0(n104), .Y(n41) );
  MX2X1 U142 ( .A(N66), .B(n306), .S0(n132), .Y(n42) );
  MX2X1 U143 ( .A(N111), .B(N81), .S0(n124), .Y(n43) );
  MX2X1 U144 ( .A(N843), .B(N813), .S0(n102), .Y(n44) );
  MX2X1 U145 ( .A(N294), .B(N264), .S0(n118), .Y(n45) );
  MX2X1 U146 ( .A(N660), .B(N630), .S0(n106), .Y(n46) );
  MX2X1 U147 ( .A(N76), .B(n288), .S0(n132), .Y(n47) );
  MX2X1 U148 ( .A(N63), .B(n303), .S0(n132), .Y(n48) );
  MX2X1 U149 ( .A(N54), .B(n294), .S0(n132), .Y(n49) );
  MX2X1 U150 ( .A(N75), .B(n287), .S0(n132), .Y(n50) );
  MX2X1 U151 ( .A(N57), .B(n297), .S0(n132), .Y(n51) );
  MX2X1 U152 ( .A(N59), .B(n299), .S0(n132), .Y(n52) );
  MX2X1 U153 ( .A(N61), .B(n301), .S0(n132), .Y(n53) );
  MX2X1 U154 ( .A(N67), .B(n307), .S0(n132), .Y(n54) );
  MX2X1 U155 ( .A(N69), .B(n281), .S0(n132), .Y(n55) );
  BUFX2 U156 ( .A(N932), .Y(n97) );
  XOR2X4 U157 ( .A(n95), .B(magnitude[27]), .Y(n136) );
  NAND2X1 U158 ( .A(n76), .B(n143), .Y(n57) );
  INVX4 U159 ( .A(n76), .Y(n56) );
  INVX2 U160 ( .A(magnitude[8]), .Y(n143) );
  AND4X4 U161 ( .A(n170), .B(n59), .C(n60), .D(n61), .Y(n171) );
  MX2XL U162 ( .A(N319), .B(N289), .S0(n118), .Y(N351) );
  MX2X1 U163 ( .A(N909), .B(n263), .S0(n98), .Y(N941) );
  MX2XL U164 ( .A(N309), .B(N279), .S0(n118), .Y(N341) );
  MX2XL U165 ( .A(N125), .B(n48), .S0(n124), .Y(N157) );
  CLKINVX2 U166 ( .A(magnitude[28]), .Y(n175) );
  INVX1 U167 ( .A(magnitude[22]), .Y(n165) );
  CLKINVX2 U168 ( .A(n207), .Y(N203) );
  MX2XL U169 ( .A(N240), .B(N210), .S0(n120), .Y(N272) );
  MX2XL U170 ( .A(N320), .B(N290), .S0(n118), .Y(n276) );
  INVX2 U171 ( .A(n215), .Y(N691) );
  INVX2 U172 ( .A(n214), .Y(N630) );
  MX2XL U173 ( .A(N193), .B(N163), .S0(n122), .Y(N225) );
  CLKINVX2 U174 ( .A(n213), .Y(N569) );
  XNOR2X1 U175 ( .A(n73), .B(magnitude[5]), .Y(n65) );
  XNOR2X1 U176 ( .A(n72), .B(magnitude[4]), .Y(n64) );
  XNOR2X4 U177 ( .A(magnitude[11]), .B(n79), .Y(n63) );
  MX2X1 U178 ( .A(N921), .B(n251), .S0(n99), .Y(N953) );
  MX2X1 U179 ( .A(N667), .B(N637), .S0(n106), .Y(N699) );
  MX2XL U180 ( .A(N196), .B(N166), .S0(n122), .Y(N228) );
  MX2XL U181 ( .A(N192), .B(N162), .S0(n122), .Y(N224) );
  MX2XL U182 ( .A(N423), .B(N393), .S0(n114), .Y(N455) );
  MX2XL U183 ( .A(N500), .B(N470), .S0(n112), .Y(N532) );
  MX2XL U184 ( .A(N919), .B(n253), .S0(n99), .Y(N951) );
  MX2XL U185 ( .A(N905), .B(n44), .S0(n99), .Y(N937) );
  CLKINVX1 U186 ( .A(n224), .Y(combinational_result[1]) );
  MX2XL U187 ( .A(N549), .B(N519), .S0(n110), .Y(N581) );
  MX2XL U188 ( .A(N732), .B(N702), .S0(N749), .Y(N764) );
  MX2XL U189 ( .A(N488), .B(N458), .S0(n112), .Y(N520) );
  MX2XL U190 ( .A(N318), .B(N288), .S0(n118), .Y(N350) );
  MX2X1 U191 ( .A(N362), .B(N332), .S0(n116), .Y(N394) );
  MX2XL U192 ( .A(N431), .B(N401), .S0(n114), .Y(N463) );
  CLKINVX2 U193 ( .A(n206), .Y(N142) );
  NAND2BX1 U194 ( .AN(n99), .B(n68), .Y(n224) );
  NAND2BX1 U195 ( .AN(n102), .B(n68), .Y(n225) );
  BUFX12 U196 ( .A(denominator[14]), .Y(n82) );
  BUFX12 U197 ( .A(denominator[20]), .Y(n88) );
  BUFX12 U198 ( .A(denominator[19]), .Y(n87) );
  BUFX12 U199 ( .A(denominator[26]), .Y(n94) );
  MX2X1 U200 ( .A(N370), .B(N340), .S0(n116), .Y(N402) );
  MX2X1 U201 ( .A(N484), .B(N454), .S0(n112), .Y(N516) );
  MX2XL U202 ( .A(N199), .B(n279), .S0(n122), .Y(N231) );
  MX2XL U203 ( .A(N182), .B(N152), .S0(n122), .Y(N214) );
  MX2XL U204 ( .A(N186), .B(N156), .S0(n122), .Y(N218) );
  MX2XL U205 ( .A(N190), .B(N160), .S0(n122), .Y(N222) );
  MX2XL U206 ( .A(N185), .B(N155), .S0(n122), .Y(N217) );
  MX2XL U207 ( .A(N177), .B(N147), .S0(n122), .Y(N209) );
  MX2XL U208 ( .A(N850), .B(N820), .S0(n102), .Y(n260) );
  CLKINVX2 U209 ( .A(n217), .Y(N813) );
  CLKINVX2 U210 ( .A(n205), .Y(N81) );
  CLKINVX2 U211 ( .A(n216), .Y(N752) );
  CLKINVX1 U212 ( .A(n225), .Y(combinational_result[2]) );
  CLKINVX8 U213 ( .A(n174), .Y(n240) );
  NAND2BX2 U214 ( .AN(n240), .B(magnitude[16]), .Y(n187) );
  MX2XL U215 ( .A(N503), .B(N473), .S0(n112), .Y(n273) );
  MX2XL U216 ( .A(N869), .B(N839), .S0(n102), .Y(n241) );
  MX2XL U217 ( .A(N863), .B(N833), .S0(n102), .Y(n247) );
  MX2XL U218 ( .A(N865), .B(N835), .S0(n102), .Y(n245) );
  MX2XL U219 ( .A(N380), .B(N350), .S0(n116), .Y(N412) );
  MX2XL U220 ( .A(N366), .B(N336), .S0(n116), .Y(N398) );
  MX2XL U221 ( .A(N306), .B(N276), .S0(n118), .Y(N338) );
  MX2XL U222 ( .A(N427), .B(N397), .S0(n114), .Y(N459) );
  MX2XL U223 ( .A(N301), .B(N271), .S0(n118), .Y(N333) );
  MX2XL U224 ( .A(N248), .B(N218), .S0(n120), .Y(N280) );
  MX2XL U225 ( .A(N378), .B(N348), .S0(n116), .Y(N410) );
  MX2XL U226 ( .A(N252), .B(N222), .S0(n120), .Y(N284) );
  MX2XL U227 ( .A(N439), .B(N409), .S0(n114), .Y(N471) );
  MX2XL U228 ( .A(N553), .B(N523), .S0(n110), .Y(N585) );
  MX2XL U229 ( .A(N622), .B(N592), .S0(n108), .Y(N654) );
  MX2XL U230 ( .A(N736), .B(N706), .S0(N749), .Y(N768) );
  MX2XL U231 ( .A(N797), .B(N767), .S0(n104), .Y(N829) );
  MX2XL U232 ( .A(N492), .B(N462), .S0(n112), .Y(N524) );
  MX2XL U233 ( .A(N862), .B(N832), .S0(n102), .Y(n248) );
  MX2XL U234 ( .A(N259), .B(N229), .S0(n120), .Y(n277) );
  MX2XL U235 ( .A(N381), .B(N351), .S0(n116), .Y(n275) );
  MX2XL U236 ( .A(N442), .B(N412), .S0(n114), .Y(n274) );
  MX2XL U237 ( .A(N564), .B(N534), .S0(n110), .Y(n272) );
  MX2XL U238 ( .A(N239), .B(N209), .S0(n120), .Y(N271) );
  MX2XL U239 ( .A(N300), .B(N270), .S0(n118), .Y(N332) );
  MX2XL U240 ( .A(N237), .B(N207), .S0(n120), .Y(N269) );
  MX2XL U241 ( .A(N298), .B(N268), .S0(n118), .Y(N330) );
  MX2XL U242 ( .A(N255), .B(N225), .S0(n120), .Y(N287) );
  MX2XL U243 ( .A(N625), .B(N595), .S0(n108), .Y(n271) );
  MX2XL U244 ( .A(N361), .B(N331), .S0(n116), .Y(N393) );
  MX2XL U245 ( .A(N241), .B(N211), .S0(n120), .Y(N273) );
  MX2XL U246 ( .A(N243), .B(N213), .S0(n120), .Y(N275) );
  MX2XL U247 ( .A(N316), .B(N286), .S0(n118), .Y(N348) );
  MX2XL U248 ( .A(N258), .B(N228), .S0(n120), .Y(N290) );
  MX2XL U249 ( .A(N302), .B(N272), .S0(n118), .Y(N334) );
  MX2XL U250 ( .A(N422), .B(N392), .S0(n114), .Y(N454) );
  MX2XL U251 ( .A(N304), .B(N274), .S0(n118), .Y(N336) );
  MX2XL U252 ( .A(N363), .B(N333), .S0(n116), .Y(N395) );
  MX2XL U253 ( .A(N377), .B(N347), .S0(n116), .Y(N409) );
  MX2XL U254 ( .A(N686), .B(N656), .S0(n106), .Y(n270) );
  MX2XL U255 ( .A(N359), .B(N329), .S0(n116), .Y(N391) );
  MX2XL U256 ( .A(N424), .B(N394), .S0(n114), .Y(N456) );
  MX2XL U257 ( .A(N426), .B(N396), .S0(n114), .Y(N458) );
  MX2XL U258 ( .A(N420), .B(N390), .S0(n114), .Y(N452) );
  MX2XL U259 ( .A(N303), .B(N273), .S0(n118), .Y(N335) );
  MX2XL U260 ( .A(N257), .B(N227), .S0(n120), .Y(N289) );
  MX2XL U261 ( .A(N438), .B(N408), .S0(n114), .Y(N470) );
  MX2XL U262 ( .A(N364), .B(N334), .S0(n116), .Y(N396) );
  MX2XL U263 ( .A(N244), .B(N214), .S0(n120), .Y(N276) );
  MX2XL U264 ( .A(N546), .B(N516), .S0(n110), .Y(N578) );
  MX2XL U265 ( .A(N747), .B(N717), .S0(N749), .Y(n269) );
  MX2XL U266 ( .A(N425), .B(N395), .S0(n114), .Y(N457) );
  MX2XL U267 ( .A(N245), .B(N215), .S0(n120), .Y(N277) );
  MX2XL U268 ( .A(N379), .B(N349), .S0(n116), .Y(N411) );
  MX2XL U269 ( .A(N605), .B(N575), .S0(n108), .Y(N637) );
  MX2XL U270 ( .A(N441), .B(N411), .S0(n114), .Y(N473) );
  MX2XL U271 ( .A(N308), .B(N278), .S0(n118), .Y(N340) );
  MX2XL U272 ( .A(N609), .B(N579), .S0(n108), .Y(N641) );
  MX2XL U273 ( .A(N440), .B(N410), .S0(n114), .Y(N472) );
  MX2XL U274 ( .A(N236), .B(N206), .S0(n120), .Y(N268) );
  MX2XL U275 ( .A(N542), .B(N512), .S0(n110), .Y(N574) );
  MX2XL U276 ( .A(N247), .B(N217), .S0(n120), .Y(N279) );
  MX2XL U277 ( .A(N607), .B(N577), .S0(n108), .Y(N639) );
  MX2XL U278 ( .A(N560), .B(N530), .S0(n110), .Y(N592) );
  MX2XL U279 ( .A(N253), .B(N223), .S0(n120), .Y(N285) );
  MX2XL U280 ( .A(N246), .B(N216), .S0(n120), .Y(N278) );
  MX2XL U281 ( .A(N367), .B(N337), .S0(n116), .Y(N399) );
  MX2XL U282 ( .A(N547), .B(N517), .S0(n110), .Y(N579) );
  MX2XL U283 ( .A(N235), .B(N205), .S0(n120), .Y(N267) );
  MX2XL U284 ( .A(N670), .B(N640), .S0(n106), .Y(N702) );
  MX2XL U285 ( .A(N254), .B(N224), .S0(n120), .Y(N286) );
  MX2XL U286 ( .A(N314), .B(N284), .S0(n118), .Y(N346) );
  MX2XL U287 ( .A(N666), .B(N636), .S0(n106), .Y(N698) );
  MX2XL U288 ( .A(N603), .B(N573), .S0(n108), .Y(N635) );
  MX2XL U289 ( .A(N430), .B(N400), .S0(n114), .Y(N462) );
  MX2XL U290 ( .A(N369), .B(N339), .S0(n116), .Y(N401) );
  MX2XL U291 ( .A(N428), .B(N398), .S0(n114), .Y(N460) );
  MX2XL U292 ( .A(N297), .B(N267), .S0(n118), .Y(N329) );
  MX2XL U293 ( .A(N315), .B(N285), .S0(n118), .Y(N347) );
  MX2XL U294 ( .A(N668), .B(N638), .S0(n106), .Y(N700) );
  MX2XL U295 ( .A(N621), .B(N591), .S0(n108), .Y(N653) );
  MX2XL U296 ( .A(N563), .B(N533), .S0(n110), .Y(N595) );
  MX2XL U297 ( .A(N296), .B(N266), .S0(n118), .Y(N328) );
  MX2XL U298 ( .A(N608), .B(N578), .S0(n108), .Y(N640) );
  MX2XL U299 ( .A(N375), .B(N345), .S0(n116), .Y(N407) );
  MX2XL U300 ( .A(N562), .B(N532), .S0(n110), .Y(N594) );
  MX2XL U301 ( .A(N360), .B(N330), .S0(n116), .Y(N392) );
  MX2XL U302 ( .A(N436), .B(N406), .S0(n114), .Y(N468) );
  MX2XL U303 ( .A(N312), .B(N282), .S0(n118), .Y(N344) );
  MX2XL U304 ( .A(N256), .B(N226), .S0(n120), .Y(N288) );
  MX2XL U305 ( .A(N731), .B(N701), .S0(N749), .Y(N763) );
  MX2XL U306 ( .A(N550), .B(N520), .S0(n110), .Y(N582) );
  MX2XL U307 ( .A(N238), .B(N208), .S0(n120), .Y(N270) );
  MX2XL U308 ( .A(N307), .B(N277), .S0(n118), .Y(N339) );
  MX2XL U309 ( .A(N664), .B(N634), .S0(n106), .Y(N696) );
  MX2XL U310 ( .A(N357), .B(N327), .S0(n116), .Y(N389) );
  MX2XL U311 ( .A(N418), .B(N388), .S0(n114), .Y(N450) );
  MX2XL U312 ( .A(N376), .B(N346), .S0(n116), .Y(N408) );
  MX2XL U313 ( .A(N249), .B(N219), .S0(n120), .Y(N281) );
  MX2XL U314 ( .A(N368), .B(N338), .S0(n116), .Y(N400) );
  MX2XL U315 ( .A(N727), .B(N697), .S0(N749), .Y(N759) );
  MX2XL U316 ( .A(N610), .B(N580), .S0(n108), .Y(N642) );
  MX2XL U317 ( .A(N623), .B(N593), .S0(n108), .Y(N655) );
  MX2XL U318 ( .A(N317), .B(N287), .S0(n118), .Y(N349) );
  MX2XL U319 ( .A(N358), .B(N328), .S0(n116), .Y(N390) );
  MX2XL U320 ( .A(N611), .B(N581), .S0(n108), .Y(N643) );
  MX2XL U321 ( .A(N613), .B(N583), .S0(n108), .Y(N645) );
  MX2XL U322 ( .A(N299), .B(N269), .S0(n118), .Y(N331) );
  MX2XL U323 ( .A(N624), .B(N594), .S0(n108), .Y(N656) );
  MX2XL U324 ( .A(N373), .B(N343), .S0(n116), .Y(N405) );
  MX2XL U325 ( .A(N669), .B(N639), .S0(n106), .Y(N701) );
  MX2XL U326 ( .A(N729), .B(N699), .S0(N749), .Y(N761) );
  MX2XL U327 ( .A(N310), .B(N280), .S0(n118), .Y(N342) );
  MX2XL U328 ( .A(N682), .B(N652), .S0(n106), .Y(N714) );
  MX2XL U329 ( .A(N434), .B(N404), .S0(n114), .Y(N466) );
  MX2XL U330 ( .A(N429), .B(N399), .S0(n114), .Y(N461) );
  MX2XL U331 ( .A(N437), .B(N407), .S0(n114), .Y(N469) );
  MX2XL U332 ( .A(N674), .B(N644), .S0(n106), .Y(N706) );
  MX2XL U333 ( .A(N432), .B(N402), .S0(n114), .Y(N464) );
  MX2XL U334 ( .A(N672), .B(N642), .S0(n106), .Y(N704) );
  MX2XL U335 ( .A(N250), .B(N220), .S0(n120), .Y(N282) );
  MX2XL U336 ( .A(N671), .B(N641), .S0(n106), .Y(N703) );
  MX2XL U337 ( .A(N371), .B(N341), .S0(n116), .Y(N403) );
  MX2XL U338 ( .A(N725), .B(N695), .S0(N749), .Y(N757) );
  MX2XL U339 ( .A(N421), .B(N391), .S0(n114), .Y(N453) );
  MX2XL U340 ( .A(N313), .B(N283), .S0(n118), .Y(N345) );
  MX2XL U341 ( .A(N558), .B(N528), .S0(n110), .Y(N590) );
  MX2XL U342 ( .A(N735), .B(N705), .S0(N749), .Y(N767) );
  MX2XL U343 ( .A(N685), .B(N655), .S0(n106), .Y(N717) );
  MX2XL U344 ( .A(N684), .B(N654), .S0(n106), .Y(N716) );
  MX2XL U345 ( .A(N543), .B(N513), .S0(n110), .Y(N575) );
  MX2XL U346 ( .A(N733), .B(N703), .S0(N749), .Y(N765) );
  MX2XL U347 ( .A(N551), .B(N521), .S0(n110), .Y(N583) );
  MX2XL U348 ( .A(N374), .B(N344), .S0(n116), .Y(N406) );
  MX2XL U349 ( .A(N730), .B(N700), .S0(N749), .Y(N762) );
  MX2XL U350 ( .A(N556), .B(N526), .S0(n110), .Y(N588) );
  MX2XL U351 ( .A(N372), .B(N342), .S0(n116), .Y(N404) );
  MX2XL U352 ( .A(N311), .B(N281), .S0(n118), .Y(N343) );
  MX2XL U353 ( .A(N540), .B(N510), .S0(n110), .Y(N572) );
  MX2XL U354 ( .A(N619), .B(N589), .S0(n108), .Y(N651) );
  MX2XL U355 ( .A(N743), .B(N713), .S0(N749), .Y(N775) );
  MX2XL U356 ( .A(N559), .B(N529), .S0(n110), .Y(N591) );
  MX2XL U357 ( .A(N612), .B(N582), .S0(n108), .Y(N644) );
  MX2XL U358 ( .A(N617), .B(N587), .S0(n108), .Y(N649) );
  MX2XL U359 ( .A(N601), .B(N571), .S0(n108), .Y(N633) );
  MX2XL U360 ( .A(N433), .B(N403), .S0(n114), .Y(N465) );
  MX2XL U361 ( .A(N435), .B(N405), .S0(n114), .Y(N467) );
  MX2XL U362 ( .A(N615), .B(N585), .S0(n108), .Y(N647) );
  MX2XL U363 ( .A(N675), .B(N645), .S0(n106), .Y(N707) );
  MX2XL U364 ( .A(N561), .B(N531), .S0(n110), .Y(N593) );
  MX2XL U365 ( .A(N745), .B(N715), .S0(N749), .Y(N777) );
  MX2XL U366 ( .A(N678), .B(N648), .S0(n106), .Y(N710) );
  MX2XL U367 ( .A(N673), .B(N643), .S0(n106), .Y(N705) );
  MX2XL U368 ( .A(N737), .B(N707), .S0(N749), .Y(N769) );
  MX2XL U369 ( .A(N602), .B(N572), .S0(n108), .Y(N634) );
  MX2XL U370 ( .A(N614), .B(N584), .S0(n108), .Y(N646) );
  MX2XL U371 ( .A(N620), .B(N590), .S0(n108), .Y(N652) );
  MX2XL U372 ( .A(N739), .B(N709), .S0(N749), .Y(N771) );
  MX2XL U373 ( .A(N555), .B(N525), .S0(n110), .Y(N587) );
  MX2XL U374 ( .A(N662), .B(N632), .S0(n106), .Y(N694) );
  MX2XL U375 ( .A(N746), .B(N716), .S0(N749), .Y(N778) );
  MX2XL U376 ( .A(N676), .B(N646), .S0(n106), .Y(N708) );
  MX2XL U377 ( .A(N604), .B(N574), .S0(n108), .Y(N636) );
  MX2XL U378 ( .A(N234), .B(n18), .S0(n120), .Y(N266) );
  MX2XL U379 ( .A(N557), .B(N527), .S0(n110), .Y(N589) );
  MX2XL U380 ( .A(N734), .B(N704), .S0(N749), .Y(N766) );
  MX2XL U381 ( .A(N741), .B(N711), .S0(N749), .Y(N773) );
  MX2XL U382 ( .A(N616), .B(N586), .S0(n108), .Y(N648) );
  MX2XL U383 ( .A(N618), .B(N588), .S0(n108), .Y(N650) );
  MX2XL U384 ( .A(N681), .B(N651), .S0(n106), .Y(N713) );
  MX2XL U385 ( .A(N295), .B(n31), .S0(n118), .Y(N327) );
  MX2XL U386 ( .A(N665), .B(N635), .S0(n106), .Y(N697) );
  MX2XL U387 ( .A(N723), .B(N693), .S0(N749), .Y(N755) );
  MX2XL U388 ( .A(N683), .B(N653), .S0(n106), .Y(N715) );
  MX2XL U389 ( .A(N356), .B(n45), .S0(n116), .Y(N388) );
  MX2XL U390 ( .A(N679), .B(N649), .S0(n106), .Y(N711) );
  MX2XL U391 ( .A(N677), .B(N647), .S0(n106), .Y(N709) );
  MX2XL U392 ( .A(N726), .B(N696), .S0(N749), .Y(N758) );
  MX2XL U393 ( .A(N742), .B(N712), .S0(N749), .Y(N774) );
  MX2XL U394 ( .A(N738), .B(N708), .S0(N749), .Y(N770) );
  MX2XL U395 ( .A(N724), .B(N694), .S0(N749), .Y(N756) );
  MX2XL U396 ( .A(N740), .B(N710), .S0(N749), .Y(N772) );
  MX2XL U397 ( .A(N744), .B(N714), .S0(N749), .Y(N776) );
  MX2XL U398 ( .A(N600), .B(n27), .S0(n108), .Y(N632) );
  MX2XL U399 ( .A(N722), .B(n46), .S0(N749), .Y(N754) );
  MX2XL U400 ( .A(N808), .B(N778), .S0(n104), .Y(n268) );
  MX2XL U401 ( .A(N788), .B(N758), .S0(n104), .Y(N820) );
  MX2XL U402 ( .A(N792), .B(N762), .S0(n104), .Y(N824) );
  MX2XL U403 ( .A(N790), .B(N760), .S0(n104), .Y(N822) );
  MX2XL U404 ( .A(N796), .B(N766), .S0(n104), .Y(N828) );
  MX2XL U405 ( .A(N794), .B(N764), .S0(n104), .Y(N826) );
  MX2XL U406 ( .A(N786), .B(N756), .S0(n104), .Y(N818) );
  MX2XL U407 ( .A(N793), .B(N763), .S0(n104), .Y(N825) );
  MX2XL U408 ( .A(N800), .B(N770), .S0(n104), .Y(N832) );
  MX2XL U409 ( .A(N791), .B(N761), .S0(n104), .Y(N823) );
  MX2XL U410 ( .A(N804), .B(N774), .S0(n104), .Y(N836) );
  MX2XL U411 ( .A(N798), .B(N768), .S0(n104), .Y(N830) );
  MX2XL U412 ( .A(N806), .B(N776), .S0(n104), .Y(N838) );
  MX2XL U413 ( .A(N802), .B(N772), .S0(n104), .Y(N834) );
  MX2XL U414 ( .A(N795), .B(N765), .S0(n104), .Y(N827) );
  MX2XL U415 ( .A(N807), .B(N777), .S0(n104), .Y(N839) );
  MX2XL U416 ( .A(N784), .B(N754), .S0(n104), .Y(N816) );
  MX2XL U417 ( .A(N799), .B(N769), .S0(n104), .Y(N831) );
  MX2XL U418 ( .A(N801), .B(N771), .S0(n104), .Y(N833) );
  MX2XL U419 ( .A(N803), .B(N773), .S0(n104), .Y(N835) );
  MX2XL U420 ( .A(N787), .B(N757), .S0(n104), .Y(N819) );
  MX2XL U421 ( .A(N805), .B(N775), .S0(n104), .Y(N837) );
  MX2XL U422 ( .A(N251), .B(N221), .S0(n120), .Y(N283) );
  MX2XL U423 ( .A(N680), .B(N650), .S0(n106), .Y(N712) );
  MX2XL U424 ( .A(N486), .B(N456), .S0(n112), .Y(N518) );
  MX2XL U425 ( .A(N852), .B(N822), .S0(n102), .Y(n258) );
  MX2XL U426 ( .A(N483), .B(N453), .S0(n112), .Y(N515) );
  MX2XL U427 ( .A(N481), .B(N451), .S0(n112), .Y(N513) );
  MX2XL U428 ( .A(N485), .B(N455), .S0(n112), .Y(N517) );
  MX2XL U429 ( .A(N487), .B(N457), .S0(n112), .Y(N519) );
  MX2XL U430 ( .A(N499), .B(N469), .S0(n112), .Y(N531) );
  MX2XL U431 ( .A(N502), .B(N472), .S0(n112), .Y(N534) );
  MX2XL U432 ( .A(N501), .B(N471), .S0(n112), .Y(N533) );
  MX2XL U433 ( .A(N491), .B(N461), .S0(n112), .Y(N523) );
  MX2XL U434 ( .A(N489), .B(N459), .S0(n112), .Y(N521) );
  MX2XL U435 ( .A(N497), .B(N467), .S0(n112), .Y(N529) );
  MX2XL U436 ( .A(N479), .B(N449), .S0(n112), .Y(N511) );
  MX2XL U437 ( .A(N495), .B(N465), .S0(n112), .Y(N527) );
  MX2XL U438 ( .A(N480), .B(N450), .S0(n112), .Y(N512) );
  MX2XL U439 ( .A(N498), .B(N468), .S0(n112), .Y(N530) );
  MX2XL U440 ( .A(N490), .B(N460), .S0(n112), .Y(N522) );
  MX2XL U441 ( .A(N482), .B(N452), .S0(n112), .Y(N514) );
  MX2XL U442 ( .A(N493), .B(N463), .S0(n112), .Y(N525) );
  MX2XL U443 ( .A(N494), .B(N464), .S0(n112), .Y(N526) );
  MX2XL U444 ( .A(N496), .B(N466), .S0(n112), .Y(N528) );
  MX2XL U445 ( .A(N853), .B(N823), .S0(n102), .Y(n257) );
  MX2XL U446 ( .A(N861), .B(N831), .S0(n102), .Y(n249) );
  MX2XL U447 ( .A(N851), .B(N821), .S0(n102), .Y(n259) );
  MX2XL U448 ( .A(N855), .B(N825), .S0(n102), .Y(n255) );
  MX2XL U449 ( .A(N857), .B(N827), .S0(n102), .Y(n253) );
  MX2XL U450 ( .A(N859), .B(N829), .S0(n102), .Y(n251) );
  MX2XL U451 ( .A(N849), .B(N819), .S0(n102), .Y(n261) );
  MX2XL U452 ( .A(N858), .B(N828), .S0(n102), .Y(n252) );
  MX2XL U453 ( .A(N847), .B(N817), .S0(n102), .Y(n263) );
  MX2XL U454 ( .A(N860), .B(N830), .S0(n102), .Y(n250) );
  MX2XL U455 ( .A(N867), .B(N837), .S0(n102), .Y(n243) );
  MX2XL U456 ( .A(N856), .B(N826), .S0(n102), .Y(n254) );
  MX2XL U457 ( .A(N864), .B(N834), .S0(n102), .Y(n246) );
  MX2XL U458 ( .A(N845), .B(N815), .S0(n102), .Y(n265) );
  MX2XL U459 ( .A(N848), .B(N818), .S0(n102), .Y(n262) );
  MX2XL U460 ( .A(N868), .B(N838), .S0(n102), .Y(n242) );
  MX2XL U461 ( .A(N866), .B(N836), .S0(n102), .Y(n244) );
  MX2XL U462 ( .A(N844), .B(n41), .S0(n102), .Y(n266) );
  MX2XL U463 ( .A(N176), .B(N146), .S0(n122), .Y(N208) );
  MX2XL U464 ( .A(N321), .B(n277), .S0(n118), .Y(N353) );
  MX2XL U465 ( .A(N382), .B(n276), .S0(n116), .Y(N414) );
  MX2XL U466 ( .A(N260), .B(n278), .S0(n120), .Y(N292) );
  MX2XL U467 ( .A(N565), .B(n273), .S0(n110), .Y(N597) );
  MX2XL U468 ( .A(N626), .B(n272), .S0(n108), .Y(N658) );
  MX2XL U469 ( .A(N184), .B(N154), .S0(n122), .Y(N216) );
  MX2XL U470 ( .A(N925), .B(n247), .S0(n99), .Y(N957) );
  MX2XL U471 ( .A(N907), .B(n265), .S0(n98), .Y(N939) );
  MX2XL U472 ( .A(N915), .B(n257), .S0(n98), .Y(N947) );
  MX2XL U473 ( .A(N929), .B(n243), .S0(n99), .Y(N961) );
  MX2XL U474 ( .A(N923), .B(n249), .S0(n99), .Y(N955) );
  MX2XL U475 ( .A(N927), .B(n245), .S0(n99), .Y(N959) );
  MX2XL U476 ( .A(N912), .B(n260), .S0(n98), .Y(N944) );
  MX2XL U477 ( .A(N906), .B(n266), .S0(n98), .Y(N938) );
  MX2XL U478 ( .A(N918), .B(n254), .S0(n98), .Y(N950) );
  MX2XL U479 ( .A(N920), .B(n252), .S0(n99), .Y(N952) );
  MX2XL U480 ( .A(N916), .B(n256), .S0(n98), .Y(N948) );
  MX2XL U481 ( .A(N924), .B(n248), .S0(n99), .Y(N956) );
  MX2XL U482 ( .A(N928), .B(n244), .S0(n99), .Y(N960) );
  MX2XL U483 ( .A(N914), .B(n258), .S0(n98), .Y(N946) );
  MX2XL U484 ( .A(N926), .B(n246), .S0(n99), .Y(N958) );
  MX2XL U485 ( .A(N922), .B(n250), .S0(n99), .Y(N954) );
  MX2XL U486 ( .A(N687), .B(n271), .S0(n106), .Y(N719) );
  MX2XL U487 ( .A(N930), .B(n242), .S0(n99), .Y(N962) );
  MX2XL U488 ( .A(N931), .B(n241), .S0(n99), .Y(N963) );
  MX2XL U489 ( .A(N137), .B(n50), .S0(n124), .Y(n279) );
  MX2XL U490 ( .A(N117), .B(n37), .S0(n124), .Y(N149) );
  MX2XL U491 ( .A(N115), .B(n34), .S0(n124), .Y(N147) );
  MX2XL U492 ( .A(N119), .B(n51), .S0(n124), .Y(N151) );
  MX2XL U493 ( .A(N121), .B(n52), .S0(n124), .Y(N153) );
  MX2XL U494 ( .A(N120), .B(n33), .S0(n124), .Y(N152) );
  MX2XL U495 ( .A(N123), .B(n53), .S0(n124), .Y(N155) );
  MX2XL U496 ( .A(N132), .B(n24), .S0(n124), .Y(N164) );
  MX2XL U497 ( .A(N113), .B(n35), .S0(n124), .Y(N145) );
  MX2XL U498 ( .A(N124), .B(n38), .S0(n124), .Y(N156) );
  MX2XL U499 ( .A(N134), .B(n19), .S0(n124), .Y(N166) );
  MX2XL U500 ( .A(N116), .B(n49), .S0(n124), .Y(N148) );
  MX2XL U501 ( .A(N129), .B(n54), .S0(n124), .Y(N161) );
  MX2XL U502 ( .A(N127), .B(n36), .S0(n124), .Y(N159) );
  MX2XL U503 ( .A(N126), .B(n40), .S0(n124), .Y(N158) );
  MX2XL U504 ( .A(N130), .B(n20), .S0(n124), .Y(N162) );
  MX2XL U505 ( .A(N128), .B(n42), .S0(n124), .Y(N160) );
  MX2XL U506 ( .A(N112), .B(n23), .S0(n124), .Y(N144) );
  INVX2 U507 ( .A(n209), .Y(N325) );
  NAND2BX1 U508 ( .AN(n118), .B(N293), .Y(n209) );
  INVX2 U509 ( .A(n210), .Y(N386) );
  MX2XL U510 ( .A(N904), .B(n267), .S0(n99), .Y(N936) );
  NAND2BX1 U511 ( .AN(n120), .B(N232), .Y(n208) );
  NAND2BX1 U512 ( .AN(n114), .B(N415), .Y(n211) );
  MX2XL U513 ( .A(N131), .B(n55), .S0(n124), .Y(N163) );
  NAND2BX1 U514 ( .AN(n108), .B(N598), .Y(n214) );
  NAND2BX1 U515 ( .AN(n106), .B(N659), .Y(n215) );
  NAND2BX1 U516 ( .AN(N749), .B(N720), .Y(n216) );
  NAND2BX1 U517 ( .AN(n104), .B(N781), .Y(n217) );
  NAND2BX1 U518 ( .AN(n112), .B(N476), .Y(n212) );
  NAND2BX1 U519 ( .AN(n102), .B(N842), .Y(n218) );
  AND2XL U520 ( .A(N903), .B(n101), .Y(N935) );
  INVXL U521 ( .A(n226), .Y(combinational_result[3]) );
  INVX1 U522 ( .A(n227), .Y(combinational_result[4]) );
  NAND2BX1 U523 ( .AN(N749), .B(n68), .Y(n227) );
  NAND2BX1 U524 ( .AN(n106), .B(n68), .Y(n228) );
  NAND2BX1 U525 ( .AN(n108), .B(n68), .Y(n229) );
  NAND2BX1 U526 ( .AN(n110), .B(n68), .Y(n230) );
  NAND2BX1 U527 ( .AN(n112), .B(n68), .Y(n231) );
  NAND2BX1 U528 ( .AN(n114), .B(n68), .Y(n232) );
  NAND2BX1 U529 ( .AN(n116), .B(n68), .Y(n233) );
  NAND2BX1 U530 ( .AN(n118), .B(n68), .Y(n234) );
  NAND2BX1 U531 ( .AN(n120), .B(n68), .Y(n235) );
  NAND2BX1 U532 ( .AN(n122), .B(n68), .Y(n236) );
  NAND2BX1 U533 ( .AN(n124), .B(n68), .Y(n237) );
  NAND2BX1 U534 ( .AN(n132), .B(n68), .Y(n238) );
  INVX2 U535 ( .A(n134), .Y(n133) );
  MX2XL U536 ( .A(N77), .B(n289), .S0(n132), .Y(N109) );
  NOR4BX4 U537 ( .AN(n162), .B(n161), .C(n160), .D(n159), .Y(n172) );
  MXI2XL U538 ( .A(N73), .B(n285), .S0(n132), .Y(n204) );
  NOR4XL U539 ( .A(n96), .B(n95), .C(n94), .D(n93), .Y(n126) );
  BUFX12 U540 ( .A(denominator[13]), .Y(n81) );
  BUFX12 U541 ( .A(denominator[5]), .Y(n73) );
  BUFX12 U542 ( .A(denominator[21]), .Y(n89) );
  BUFX12 U543 ( .A(denominator[4]), .Y(n72) );
  BUFX12 U544 ( .A(denominator[27]), .Y(n95) );
  NAND2BX1 U545 ( .AN(n240), .B(magnitude[6]), .Y(n197) );
  NAND2BX1 U546 ( .AN(n240), .B(magnitude[14]), .Y(n189) );
  NAND2BX1 U547 ( .AN(n240), .B(magnitude[7]), .Y(n196) );
  NAND2BX1 U548 ( .AN(n240), .B(magnitude[4]), .Y(n199) );
  NAND2BX1 U549 ( .AN(n240), .B(magnitude[20]), .Y(n183) );
  NAND2BX1 U550 ( .AN(n240), .B(magnitude[18]), .Y(n185) );
  NAND2BX1 U551 ( .AN(n240), .B(magnitude[3]), .Y(n200) );
  NAND2BX1 U552 ( .AN(n240), .B(magnitude[1]), .Y(n202) );
  INVX2 U553 ( .A(n201), .Y(n292) );
  NAND2BX1 U554 ( .AN(n240), .B(magnitude[2]), .Y(n201) );
  INVX1 U555 ( .A(magnitude[6]), .Y(n154) );
  INVX1 U556 ( .A(magnitude[23]), .Y(n153) );
  INVX1 U557 ( .A(magnitude[25]), .Y(n152) );
  INVX1 U558 ( .A(magnitude[12]), .Y(n144) );
  BUFX2 U559 ( .A(n80), .Y(n66) );
  INVX2 U560 ( .A(n97), .Y(n100) );
  MX2X1 U561 ( .A(N809), .B(n269), .S0(n104), .Y(N841) );
  MX2X1 U562 ( .A(N748), .B(n270), .S0(N749), .Y(N780) );
  MX2X1 U563 ( .A(N504), .B(n274), .S0(n112), .Y(N536) );
  MX2X1 U564 ( .A(N183), .B(N153), .S0(n122), .Y(N215) );
  MX2X1 U565 ( .A(N417), .B(n39), .S0(n114), .Y(N449) );
  MX2X1 U566 ( .A(N606), .B(N576), .S0(n108), .Y(N638) );
  MX2X1 U567 ( .A(N789), .B(N759), .S0(n104), .Y(N821) );
  MX2X1 U568 ( .A(N365), .B(N335), .S0(n116), .Y(N397) );
  MX2X1 U569 ( .A(N443), .B(n275), .S0(n114), .Y(N475) );
  MX2X1 U570 ( .A(N305), .B(N275), .S0(n118), .Y(N337) );
  MX2X1 U571 ( .A(N175), .B(N145), .S0(n122), .Y(N207) );
  MX2X1 U572 ( .A(N419), .B(N389), .S0(n114), .Y(N451) );
  MX2X1 U573 ( .A(N541), .B(N511), .S0(n110), .Y(N573) );
  MX2X1 U574 ( .A(N663), .B(N633), .S0(n106), .Y(N695) );
  MX2X1 U575 ( .A(N728), .B(N698), .S0(N749), .Y(N760) );
  MX2X1 U576 ( .A(N785), .B(N755), .S0(n104), .Y(N817) );
  MX2X1 U577 ( .A(N783), .B(n17), .S0(n104), .Y(N815) );
  MX2X1 U578 ( .A(N870), .B(n268), .S0(n102), .Y(N902) );
  MX2X1 U579 ( .A(N539), .B(n25), .S0(n110), .Y(N571) );
  MX2X1 U580 ( .A(N661), .B(n26), .S0(n106), .Y(N693) );
  MX2X1 U581 ( .A(N854), .B(N824), .S0(n102), .Y(n256) );
  MX2X1 U582 ( .A(N242), .B(N212), .S0(n120), .Y(N274) );
  MX2X1 U583 ( .A(N548), .B(N518), .S0(n110), .Y(N580) );
  MX2X1 U584 ( .A(N138), .B(n47), .S0(n124), .Y(N170) );
  MX2X1 U585 ( .A(N122), .B(n32), .S0(n124), .Y(N154) );
  MX2X1 U586 ( .A(N133), .B(n28), .S0(n124), .Y(N165) );
  MX2X1 U587 ( .A(N114), .B(n29), .S0(n124), .Y(N146) );
  INVX2 U588 ( .A(n211), .Y(N447) );
  INVX2 U589 ( .A(n208), .Y(N264) );
  INVX2 U590 ( .A(n212), .Y(N508) );
  NAND2BX2 U591 ( .AN(n132), .B(N49), .Y(n205) );
  NAND2BX2 U592 ( .AN(n124), .B(N110), .Y(n206) );
  INVX2 U593 ( .A(n218), .Y(n267) );
  NAND2BX2 U594 ( .AN(N964), .B(n68), .Y(n223) );
  INVX2 U595 ( .A(n228), .Y(combinational_result[5]) );
  INVX2 U596 ( .A(n229), .Y(combinational_result[6]) );
  INVX2 U597 ( .A(n230), .Y(combinational_result[7]) );
  INVX2 U598 ( .A(n232), .Y(combinational_result[9]) );
  INVX2 U599 ( .A(n231), .Y(combinational_result[8]) );
  INVX2 U600 ( .A(n233), .Y(combinational_result[10]) );
  INVX2 U601 ( .A(n234), .Y(combinational_result[11]) );
  INVX2 U602 ( .A(n236), .Y(combinational_result[13]) );
  INVX2 U603 ( .A(n235), .Y(combinational_result[12]) );
  INVX2 U604 ( .A(n237), .Y(combinational_result[14]) );
  INVX2 U605 ( .A(n238), .Y(combinational_result[15]) );
  AND2X2 U606 ( .A(n68), .B(n240), .Y(combinational_result[16]) );
  XNOR2X1 U607 ( .A(n96), .B(n175), .Y(n135) );
  NOR4BX2 U608 ( .AN(n158), .B(n157), .C(n156), .D(n155), .Y(n162) );
  XNOR2X1 U609 ( .A(n93), .B(n152), .Y(n157) );
  NOR2X2 U610 ( .A(n240), .B(n175), .Y(N48) );
  NOR4BX2 U611 ( .AN(n142), .B(n141), .C(n140), .D(n139), .Y(n150) );
  INVX2 U612 ( .A(n204), .Y(N105) );
  BUFX2 U613 ( .A(n239), .Y(n68) );
  NAND2BX2 U614 ( .AN(n222), .B(n221), .Y(n239) );
  NAND4BX2 U615 ( .AN(n219), .B(n128), .C(n126), .D(n127), .Y(n222) );
  NAND3XL U616 ( .A(n129), .B(n125), .C(n130), .Y(n219) );
  NOR4X2 U617 ( .A(n89), .B(n88), .C(n69), .D(n87), .Y(n130) );
  INVX2 U618 ( .A(n191), .Y(n302) );
  XOR2X1 U619 ( .A(n94), .B(magnitude[26]), .Y(n139) );
  XOR2X1 U620 ( .A(n83), .B(magnitude[15]), .Y(n159) );
  XOR2X1 U621 ( .A(n71), .B(magnitude[3]), .Y(n161) );
  XOR2X1 U622 ( .A(n89), .B(magnitude[21]), .Y(n141) );
  XOR2X1 U623 ( .A(n70), .B(magnitude[2]), .Y(n160) );
  XOR2X1 U624 ( .A(n87), .B(magnitude[19]), .Y(n140) );
  XOR2X1 U625 ( .A(n81), .B(magnitude[13]), .Y(n137) );
  XOR2X1 U626 ( .A(n82), .B(magnitude[14]), .Y(n138) );
  NOR4BX2 U627 ( .AN(n169), .B(n168), .C(n167), .D(n166), .Y(n170) );
  XNOR2X1 U628 ( .A(n90), .B(n165), .Y(n166) );
  XNOR2X1 U629 ( .A(magnitude[17]), .B(n163), .Y(n168) );
  XNOR2X1 U630 ( .A(magnitude[16]), .B(n164), .Y(n167) );
  XNOR2X1 U631 ( .A(n80), .B(n144), .Y(n146) );
  XNOR2X1 U632 ( .A(n88), .B(magnitude[20]), .Y(n142) );
  INVX2 U633 ( .A(n198), .Y(n295) );
  INVX2 U634 ( .A(n193), .Y(n300) );
  INVX2 U635 ( .A(n190), .Y(n303) );
  INVX2 U636 ( .A(n188), .Y(n305) );
  INVX2 U637 ( .A(n186), .Y(n307) );
  INVX2 U638 ( .A(n179), .Y(n286) );
  INVX2 U639 ( .A(n197), .Y(n296) );
  INVX2 U640 ( .A(n195), .Y(n298) );
  NAND2BX2 U641 ( .AN(n240), .B(magnitude[8]), .Y(n195) );
  INVX2 U642 ( .A(n183), .Y(n282) );
  INVX2 U643 ( .A(n184), .Y(n281) );
  INVX2 U644 ( .A(n180), .Y(n285) );
  INVX2 U645 ( .A(n178), .Y(n287) );
  INVX2 U646 ( .A(n182), .Y(n283) );
  INVX2 U647 ( .A(n176), .Y(n289) );
  INVX2 U648 ( .A(n194), .Y(n299) );
  INVX2 U649 ( .A(n177), .Y(n288) );
  INVX2 U650 ( .A(n181), .Y(n284) );
  INVX2 U651 ( .A(n189), .Y(n304) );
  INVX2 U652 ( .A(n192), .Y(n301) );
  INVX2 U653 ( .A(n199), .Y(n294) );
  INVX2 U654 ( .A(n203), .Y(n290) );
  NAND2BX2 U655 ( .AN(n240), .B(magnitude[0]), .Y(n203) );
  INVX2 U656 ( .A(n187), .Y(n306) );
  INVX2 U657 ( .A(n200), .Y(n293) );
  INVX2 U658 ( .A(n196), .Y(n297) );
  INVX2 U659 ( .A(n202), .Y(n291) );
  INVX2 U660 ( .A(n185), .Y(n280) );
  NAND2BX2 U661 ( .AN(n240), .B(magnitude[9]), .Y(n194) );
  NAND2BX1 U662 ( .AN(n104), .B(n68), .Y(n226) );
  MX2X1 U663 ( .A(N846), .B(N816), .S0(n102), .Y(n264) );
  NAND2BX2 U664 ( .AN(n240), .B(magnitude[11]), .Y(n192) );
  NAND2BX1 U665 ( .AN(n240), .B(magnitude[27]), .Y(n176) );
  NAND2BX1 U666 ( .AN(n240), .B(magnitude[25]), .Y(n178) );
  NAND2BX1 U667 ( .AN(n240), .B(magnitude[21]), .Y(n182) );
  NAND2BX1 U668 ( .AN(n240), .B(magnitude[13]), .Y(n190) );
  NAND2BX1 U669 ( .AN(n240), .B(magnitude[24]), .Y(n179) );
  NAND2BX1 U670 ( .AN(n240), .B(magnitude[23]), .Y(n180) );
  NAND2BX2 U671 ( .AN(n240), .B(magnitude[26]), .Y(n177) );
  NAND2BX2 U672 ( .AN(n240), .B(magnitude[22]), .Y(n181) );
  NAND2BX1 U673 ( .AN(n240), .B(magnitude[5]), .Y(n198) );
  NAND2BX2 U674 ( .AN(n240), .B(magnitude[10]), .Y(n193) );
  NAND2BX1 U675 ( .AN(n240), .B(magnitude[17]), .Y(n186) );
  NAND2BX1 U676 ( .AN(n240), .B(magnitude[15]), .Y(n188) );
  NAND2BX1 U677 ( .AN(n240), .B(magnitude[19]), .Y(n184) );
  NAND2BX1 U678 ( .AN(n240), .B(magnitude[12]), .Y(n191) );
  MX2X1 U679 ( .A(N478), .B(n30), .S0(n112), .Y(N510) );
  NOR4BXL U680 ( .AN(n220), .B(n78), .C(n79), .D(n133), .Y(n221) );
  NAND3BX2 U681 ( .AN(n151), .B(n150), .C(n149), .Y(n173) );
  INVX2 U682 ( .A(n223), .Y(combinational_result[0]) );
  NAND3BX4 U683 ( .AN(n173), .B(n172), .C(n171), .Y(n174) );
endmodule


module probe_v4_29 ( clk, reset_n, magnitude, denominator, result );
  input [28:0] magnitude;
  input [28:0] denominator;
  output [16:0] result;
  input clk, reset_n;


  norm_v4_29 arithmetic ( .clk(clk), .reset_n(reset_n), .magnitude(magnitude), 
        .denominator(denominator), .result(result) );
endmodule

