module probe_original(
    input logic clk,reset_n,window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,dphase
);
    wire signed [63:0] code_value;
    wire signed [63:0] phase_value;
    norm_original arithmetic(.*,.dcode(code_value),.dphase(phase_value));
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) begin dcode<=0;dphase<=0;end
        else begin dcode<=64'($signed(code_value));dphase<=64'($signed(phase_value));end
endmodule

module probe_optimized(
    input logic clk,reset_n,window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,dphase
);
    wire signed [15:0] code_value;
    wire signed [14:0] phase_value;
    norm_optimized arithmetic(.*,.dcode(code_value),.dphase(phase_value));
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) begin dcode<=0;dphase<=0;end
        else begin dcode<=64'($signed(code_value));dphase<=64'($signed(phase_value));end
endmodule
