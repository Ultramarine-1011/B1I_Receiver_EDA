`timescale 1ns/1ps
module tb_cordic_quad;
    logic signed [56:0] dot_value,cross_value;
    wire signed [15:0] old_result,new_result;
    logic signed [56:0] edges[0:10];
    logic [63:0] random_state=64'hb1d1_c04d_1c20_2611;
    integer checks=0;
    tracking_atan_reference reference_dut(.*,.result(old_result));
    tracking_atan optimized_dut(.*,.result(new_result));
    function automatic logic [63:0] random_word();
        random_state=random_state^(random_state<<13);
        random_state=random_state^(random_state>>7);
        random_state=random_state^(random_state<<17);
        return random_state;
    endfunction
    task automatic check_result;
        #1;
        if(old_result!==new_result)
            $fatal(1,"CORDIC_QUAD_MISMATCH n=%0d dot=%h cross=%h old=%h new=%h",
                checks,dot_value,cross_value,old_result,new_result);
        checks=checks+1;
    endtask
    initial begin
        edges[0]=0;edges[1]=1;edges[2]=-1;edges[3]=2;edges[4]=-2;
        edges[5]=57'sh100000000000000;edges[6]=57'sh0ffffffffffffff;
        edges[7]=57'sh080000000000000;edges[8]=-57'sh080000000000000;
        edges[9]=57'sh040000000000000;edges[10]=-57'sh040000000000000;
        for(integer a=0;a<11;a=a+1)
            for(integer b=0;b<11;b=b+1) begin
                dot_value=edges[a];cross_value=edges[b];check_result();
            end
        for(integer n=0;n<200000;n=n+1) begin
            dot_value=57'(random_word());cross_value=57'(random_word());
            if(n%7==0) cross_value=0;
            if(n%11==0) dot_value=0;
            check_result();
        end
        $display("CORDIC_QUAD_EQUIVALENCE_PASS checks=%0d full_signed57_and_zero_axes=1",checks);
        $finish;
    end
endmodule
