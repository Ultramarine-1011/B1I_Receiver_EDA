set_app_var sh_enable_page_mode false
set_host_options -max_cores 1
set report_dir $env(BASELINE_REPORT_DIR)
file mkdir $report_dir
define_design_lib WORK -path ./WORK
set db_file /home/ic_libs/TSMC.90/aci/sc-x/synopsys/typical.db
set_app_var target_library [list $db_file]
set_app_var synthetic_library [list dw_foundation.sldb]
set_app_var link_library [list * $db_file dw_foundation.sldb]
if {[analyze -format sverilog work/quad_atan_probes.sv] == 0} { exit 1 }
if {[elaborate tracking_atan] == 0} { exit 1 }
if {[link] == 0} { exit 1 }
set top_design [get_object_name [current_design]]
set quads [get_cells -hierarchical -filter {ref_name =~ tracking_cordic_quad*}]
if {[sizeof_collection $quads] != 4} { exit 1 }
set quad_designs [lsort -unique [get_attribute $quads ref_name]]

proc constrain_math {period} {
    set_operating_conditions typical -library typical
    create_clock -name module_clk -period $period
    set_clock_uncertainty -setup 0.2 [get_clocks module_clk]
    set_clock_uncertainty -hold 0.2 [get_clocks module_clk]
    set_input_delay -clock module_clk -max 0.0 [all_inputs]
    set_input_delay -clock module_clk -min 0.0 [all_inputs]
    set_output_delay -clock module_clk -max 0.0 [all_outputs]
    set_output_delay -clock module_clk -min 0.0 [all_outputs]
    set_driving_cell -lib_cell INVX1 -library typical [all_inputs]
    set_load [expr {4.0 * [load_of typical/INVX1/A]}] [all_outputs]
}

foreach quad $quad_designs {
    current_design $quad
    constrain_math $env(QUAD_PERIOD)
    puts "QUAD_COMPILE_BEGIN $quad [clock seconds]"
    if {[compile -map_effort medium] == 0} { exit 1 }
    puts "QUAD_COMPILE_END $quad [clock seconds]"
    redirect $report_dir/${quad}_qor.rpt { report_qor }
    ungroup -all -flatten
    reset_design
    set_dont_touch [current_design] true
}
current_design $top_design
constrain_math 10
set_dont_touch [get_cells -hierarchical -filter {ref_name =~ tracking_cordic_quad*}] true
puts "PROBE_COMPILE_BEGIN [clock seconds]"
if {[compile -map_effort medium] == 0} { exit 1 }
puts "PROBE_COMPILE_END [clock seconds]"
write -format verilog -hierarchy -output $report_dir/mapped.v
write -format ddc -hierarchy -output $report_dir/mapped.ddc
redirect $report_dir/area.rpt { report_area -hierarchy }
redirect $report_dir/qor.rpt { report_qor }
redirect $report_dir/timing_max.rpt { report_timing -delay max -max_paths 3 -significant_digits 6 }
redirect $report_dir/check_timing_post.rpt { check_timing }
redirect $report_dir/check_design_post.rpt { check_design }
set unmapped [get_cells -hierarchical -filter {is_hierarchical == false && is_unmapped == true}]
puts "PROBE_UNMAPPED [sizeof_collection $unmapped]"
if {[sizeof_collection $unmapped] != 0} { exit 1 }
puts "PROBE_REPORTS_DONE"
exit 0
