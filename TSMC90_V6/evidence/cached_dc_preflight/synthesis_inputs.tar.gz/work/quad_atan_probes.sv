module tracking_atan_reference(input logic signed [56:0] dot_value,cross_value,output logic signed [15:0] result);
    function automatic logic signed [15:0] atan_turn_q16(input logic signed [56:0] dot_value,cross_value);
        logic signed [58:0] x,y,nx,ny;
        logic signed [31:0] z,angle;
        begin
            x=dot_value<0 ? -dot_value : dot_value;y=dot_value<0 ? -cross_value : cross_value;z=0;
            for(integer k=0;k<16;k=k+1) begin
                case(k)
                    0:angle=64'sd536870912;1:angle=64'sd316933406;2:angle=64'sd167458907;
                    3:angle=64'sd85004756;4:angle=64'sd42667331;5:angle=64'sd21354465;
                    6:angle=64'sd10679838;7:angle=64'sd5340245;8:angle=64'sd2670163;
                    9:angle=64'sd1335087;10:angle=64'sd667544;11:angle=64'sd333772;
                    12:angle=64'sd166886;13:angle=64'sd83443;14:angle=64'sd41722;default:angle=64'sd20861;
                endcase
                if(y>0) begin nx=x+(y >>> k);ny=y-(x >>> k);z=z+angle;end
                else if(y<0) begin nx=x-(y >>> k);ny=y+(x >>> k);z=z-angle;end
                else begin nx=x;ny=y;end
                x=nx;y=ny;
            end
            atan_turn_q16=16'(z >>> 16);
        end
    endfunction
    assign result=atan_turn_q16(dot_value,cross_value);
endmodule
module tracking_atan(
    input logic signed [56:0] dot_value,cross_value,
    output logic signed [15:0] result
);
    logic signed [58:0] x_stage[0:4],y_stage[0:4];
    logic signed [31:0] z_stage[0:4];
    assign x_stage[0]=dot_value<0 ? -dot_value : dot_value;
    assign y_stage[0]=dot_value<0 ? -cross_value : cross_value;
    assign z_stage[0]=32'sd0;
    for(genvar stage=0;stage<4;stage=stage+1) begin: rotation_groups
        tracking_cordic_quad #(.START(4*stage)) rotations(
            .x_in(x_stage[stage]),.y_in(y_stage[stage]),.z_in(z_stage[stage]),
            .x_out(x_stage[stage+1]),.y_out(y_stage[stage+1]),.z_out(z_stage[stage+1]));
    end
    assign result=16'(z_stage[4] >>> 16);
endmodule

module tracking_cordic_quad #(parameter integer START=0)(
    input logic signed [58:0] x_in,y_in,
    input logic signed [31:0] z_in,
    output logic signed [58:0] x_out,y_out,
    output logic signed [31:0] z_out
);
    logic signed [58:0] x,y,nx,ny;
    logic signed [31:0] z,angle;
    always_comb begin
        x=x_in;y=y_in;z=z_in;nx=0;ny=0;angle=0;
        for(integer k=START;k<START+4;k=k+1) begin
                case(k)
                    0:angle=64'sd536870912;1:angle=64'sd316933406;2:angle=64'sd167458907;
                    3:angle=64'sd85004756;4:angle=64'sd42667331;5:angle=64'sd21354465;
                    6:angle=64'sd10679838;7:angle=64'sd5340245;8:angle=64'sd2670163;
                    9:angle=64'sd1335087;10:angle=64'sd667544;11:angle=64'sd333772;
                    12:angle=64'sd166886;13:angle=64'sd83443;14:angle=64'sd41722;default:angle=64'sd20861;
                endcase
            if(y>0) begin nx=x+(y >>> k);ny=y-(x >>> k);z=z+angle;end
            else if(y<0) begin nx=x-(y >>> k);ny=y+(x >>> k);z=z-angle;end
            else begin nx=x;ny=y;end
            x=nx;y=ny;
        end
        x_out=x;y_out=y;z_out=z;
    end
endmodule