`timescale 1ns/1ps
module tb_loop_equivalence;
    logic window_done=1,previous_prompt_valid=1,previous_phase_valid=1;
    logic signed [27:0] ie,qe,ip,qp,il,ql,previous_ip,previous_qp;
    logic signed [31:0] code_integral,carrier_integral,code_mean_q16,frequency_mean_q16,previous_phase_q16;
    logic [7:0] seen,population;
    logic [127:0] validity_history;
    logic [31:0] phase_mean_square_q32;
    logic [41:0] window_energy;
    logic [63:0] window_ref,previous_prompt_ref;
    logic [1023:0] original_values,optimized_values;
    logic [31:0] random_state=32'h600dc0de;
    logic signed [31:0] state_edges[0:8];
    integer checks=0;
    loop_original reference_dut(.*,.observed_values(original_values));
    loop_optimized optimized_dut(.*,.observed_values(optimized_values));
    function automatic logic [31:0] random_word();
        random_state=random_state^(random_state<<13);
        random_state=random_state^(random_state>>17);
        random_state=random_state^(random_state<<5);
        return random_state;
    endfunction
    task automatic check_result;
        #1;
        if(original_values!==optimized_values)
            $fatal(1,"LOOP_ARITHMETIC_MISMATCH check=%0d old=%h new=%h",checks,original_values,optimized_values);
        checks=checks+1;
    endtask
    initial begin
        state_edges[0]=32'sh80000000;state_edges[1]=32'sh7fffffff;
        state_edges[2]=0;state_edges[3]=1;state_edges[4]=-1;
        state_edges[5]=1638400;state_edges[6]=-1638400;
        state_edges[7]=655360000;state_edges[8]=-655360000;
        // Include arbitrary full-width state words, beyond normal closed-loop trajectories.
        for(integer n=0;n<100000;n=n+1) begin
            ie=28'(random_word());qe=28'(random_word());il=28'(random_word());ql=28'(random_word());
            ip=28'(random_word());qp=28'(random_word());previous_ip=28'(random_word());previous_qp=28'(random_word());
            code_integral=n<81 ? state_edges[n%9] : 32'(random_word());
            carrier_integral=n<81 ? state_edges[(n/9)%9] : 32'(random_word());
            code_mean_q16=32'(random_word());frequency_mean_q16=32'(random_word());previous_phase_q16=32'(random_word());
            phase_mean_square_q32=random_word();window_energy={10'd0,random_word()};
            seen=8'(n%129);population=8'(n%129);validity_history={random_word(),random_word(),random_word(),random_word()};
            previous_prompt_ref={32'd0,random_word()};window_ref=previous_prompt_ref+((n%3)==0 ? 16369 : 16368);
            previous_prompt_valid=n%5!=0;previous_phase_valid=n%7!=0;window_done=n%11!=0;
            if(n<81) begin
                ie=n%2==0 ? 28'sh8000000 : 0;qe=ie;il=n%2==0 ? 0 : 28'sh8000000;ql=il;
                ip=n%3==0 ? 0 : n%3==1 ? -1 : 28'sh8000000;qp=n%2==0 ? 28'sh8000000 : 28'sh7ffffff;
                window_energy=0;window_done=1;
            end
            check_result();
        end
        $display("LOOP_EQUIVALENCE_PASS checks=%0d fields=16 seed=600dc0de",checks);
        $finish;
    end
endmodule
