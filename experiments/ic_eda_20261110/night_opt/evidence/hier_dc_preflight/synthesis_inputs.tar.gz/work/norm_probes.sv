module norm_original (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,
    output logic signed [63:0] dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic signed [79:0] code_numerator,phase_numerator;

    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        code_numerator=(80'($signed(pe))-80'($signed(pl))) <<< 16;
        phase_numerator=80'($signed(qp)) <<< 16;
        if(ip<0) phase_numerator=-phase_numerator;
        dcode=!window_done || den_code==0 ? 64'sd0 : 64'(code_numerator / 80'($signed(den_code)));
        dcode=(dcode*11)/32; // (1-delta)/2, delta=5/16 chip in this wrapper
        dphase=!window_done || (abs_i+abs_q)==0 ? 64'sd0 : 64'(phase_numerator / 80'($signed(abs_i+abs_q)));
        dphase=(dphase*10430) >>> 16; // small-error Costas approximation, turn Q16
    end
endmodule

module norm_optimized (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [15:0] dcode,
    output logic signed [14:0] dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic [56:0] code_magnitude; logic [28:0] phase_denominator; logic [16:0] code_ratio,phase_ratio; logic signed [17:0] code_ratio_signed,phase_ratio_signed;
    logic [16:0] normalized_code_raw,normalized_phase_raw;
    tracking_ratio_code dll_ratio(.magnitude(code_magnitude),.denominator(den_code[56:0]),.result(normalized_code_raw));
    tracking_ratio_phase pll_ratio(.magnitude(abs_q[28:0]),.denominator(phase_denominator),.result(normalized_phase_raw));


    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        // A square is at most 2^54. Each power is at most 2^55 and their sum 2^56.
        code_magnitude=pe>=pl ? pe[56:0]-pl[56:0] : pl[56:0]-pe[56:0];
        phase_denominator=29'(abs_i+abs_q); // <= 2^28, including -2^27 inputs
    end
    always_comb begin
        code_ratio=0;
        phase_ratio=0;
        if(window_done) begin
            code_ratio=normalized_code_raw;
            phase_ratio=normalized_phase_raw;
        end
        code_ratio_signed=!window_done ? 18'sd0 : (pe<pl ? -$signed({1'b0,code_ratio}) : $signed({1'b0,code_ratio}));
        dcode=16'((64'($signed(code_ratio_signed))*11)/32); // (1-delta)/2, delta=5/16 chip in this wrapper
        phase_ratio_signed=!window_done ? 18'sd0 : ((qp<0) != (ip<0) ? -$signed({1'b0,phase_ratio}) : $signed({1'b0,phase_ratio}));
        dphase=15'((64'($signed(phase_ratio_signed))*10430) >>> 16); // small-error Costas approximation, turn Q16
    end
endmodule

module tracking_ratio_code(input logic [56:0] magnitude,denominator,output logic [16:0] result);
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic [16:0] quotient;
        logic [58:0] denominator_2_1;
        logic signed [59:0] trial_2_1;
        logic [58:0] denominator_2_2;
        logic signed [59:0] trial_2_2;
        logic [58:0] denominator_2_3;
        logic signed [59:0] trial_2_3;
        begin
            remainder_value=magnitude;
            quotient=0;
            denominator_2_1=59'(denominator)*59'd1;
            trial_2_1=0;
            denominator_2_2=59'(denominator)*59'd2;
            trial_2_2=0;
            denominator_2_3=59'(denominator)*59'd3;
            trial_2_3=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[14 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[14 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[14 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[14 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[12 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[12 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[12 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[12 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[10 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[10 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[10 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[10 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[8 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[8 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[8 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[8 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[6 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[6 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[6 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[6 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[4 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[4 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[4 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[4 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[2 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[2 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[2 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[2 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[0 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[0 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[0 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[0 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    assign result=normalized_ratio_q16(magnitude,denominator);
endmodule

module tracking_ratio_phase(input logic [28:0] magnitude,denominator,output logic [16:0] result);
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic signed [30:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[30];
                    remainder_value=trial[30] ? (remainder_value << 1) : trial[28:0];
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    assign result=normalized_phase_ratio_q16(magnitude,denominator);
endmodule

module tracking_atan(input logic signed [56:0] dot_value,cross_value,output logic signed [15:0] result);
    function automatic logic signed [15:0] atan_turn_q16(input logic signed [56:0] dot_value,cross_value);
        logic signed [58:0] x,y,nx,ny;
        logic signed [31:0] z,angle;
        begin
            x=dot_value<0 ? -dot_value : dot_value;y=dot_value<0 ? -cross_value : cross_value;z=0;
            for(integer k=0;k<16;k=k+1) begin
                case(k)
                    0:angle=64'sd536870912;1:angle=64'sd316933406;2:angle=64'sd167458907;
                    3:angle=64'sd85004756;4:angle=64'sd42667331;5:angle=64'sd21354465;
                    6:angle=64'sd10679838;7:angle=64'sd5340245;8:angle=64'sd2670163;
                    9:angle=64'sd1335087;10:angle=64'sd667544;11:angle=64'sd333772;
                    12:angle=64'sd166886;13:angle=64'sd83443;14:angle=64'sd41722;default:angle=64'sd20861;
                endcase
                if(y>0) begin nx=x+(y >>> k);ny=y-(x >>> k);z=z+angle;end
                else if(y<0) begin nx=x-(y >>> k);ny=y+(x >>> k);z=z-angle;end
                else begin nx=x;ny=y;end
                x=nx;y=ny;
            end
            atan_turn_q16=16'(z >>> 16);
        end
    endfunction
    assign result=atan_turn_q16(dot_value,cross_value);
endmodule

module tracking_divide_step(input logic signed [39:0] value,output logic signed [23:0] result);
    function automatic logic signed [23:0] divide_step_127875(input logic signed [39:0] value);
        logic signed [80:0] product;
        logic signed [23:0] floor_quotient;
        begin
            product=value*41'sd563500246631;
            floor_quotient=24'(product >>> 56);
            divide_step_127875=floor_quotient+24'(value[39]);
        end
    endfunction
    assign result=divide_step_127875(value);
endmodule

module tracking_divide_aid(input logic signed [32:0] value,output logic signed [23:0] result);
    function automatic logic signed [23:0] divide_aid_763(input logic signed [32:0] value);
        logic signed [66:0] product;
        logic signed [23:0] floor_quotient;
        begin
            product=value*34'sd5764150081;
            floor_quotient=24'(product >>> 42);
            divide_aid_763=floor_quotient+24'(value[32]);
        end
    endfunction
    assign result=divide_aid_763(value);
endmodule
