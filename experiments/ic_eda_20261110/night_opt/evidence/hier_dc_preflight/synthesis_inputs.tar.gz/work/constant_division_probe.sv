module constant_division_probe(input logic signed [39:0] step_value,input logic signed [32:0] aid_value,output logic signed [23:0] step_result,aid_result);
    function automatic logic signed [23:0] divide_step_127875(input logic signed [39:0] value);
        logic signed [80:0] product;
        logic signed [23:0] floor_quotient;
        begin
            product=value*41'sd563500246631;
            floor_quotient=24'(product >>> 56);
            divide_step_127875=floor_quotient+24'(value[39]);
        end
    endfunction
    function automatic logic signed [23:0] divide_aid_763(input logic signed [32:0] value);
        logic signed [66:0] product;
        logic signed [23:0] floor_quotient;
        begin
            product=value*34'sd5764150081;
            floor_quotient=24'(product >>> 42);
            divide_aid_763=floor_quotient+24'(value[32]);
        end
    endfunction
 always_comb begin step_result=divide_step_127875(step_value);aid_result=divide_aid_763(aid_value);end
endmodule
