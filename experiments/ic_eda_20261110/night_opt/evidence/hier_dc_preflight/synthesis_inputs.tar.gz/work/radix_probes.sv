module norm_v4_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic signed [58:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[58];
                    remainder_value=trial[58] ? (remainder_value << 1) : trial[56:0];
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_v4_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_v4_57 arithmetic(.*,.combinational_result());
endmodule

module norm_v4_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic signed [30:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[30];
                    remainder_value=trial[30] ? (remainder_value << 1) : trial[28:0];
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_phase_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_v4_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_v4_29 arithmetic(.*,.combinational_result());
endmodule

module norm_r4_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic [16:0] quotient;
        logic [58:0] denominator_2_1;
        logic signed [59:0] trial_2_1;
        logic [58:0] denominator_2_2;
        logic signed [59:0] trial_2_2;
        logic [58:0] denominator_2_3;
        logic signed [59:0] trial_2_3;
        begin
            remainder_value=magnitude;
            quotient=0;
            denominator_2_1=59'(denominator)*59'd1;
            trial_2_1=0;
            denominator_2_2=59'(denominator)*59'd2;
            trial_2_2=0;
            denominator_2_3=59'(denominator)*59'd3;
            trial_2_3=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[14 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[14 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[14 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[14 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[12 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[12 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[12 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[12 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[10 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[10 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[10 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[10 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[8 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[8 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[8 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[8 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[6 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[6 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[6 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[6 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[4 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[4 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[4 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[4 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[2 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[2 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[2 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[2 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[59]) begin
                    if(!trial_2_3[59]) begin
                        quotient[0 +: 2]=2'd3;
                        remainder_value=trial_2_3[56:0];
                    end else begin
                        quotient[0 +: 2]=2'd2;
                        remainder_value=trial_2_2[56:0];
                    end
                end else begin
                    if(!trial_2_1[59]) begin
                        quotient[0 +: 2]=2'd1;
                        remainder_value=trial_2_1[56:0];
                    end else begin
                        quotient[0 +: 2]=2'd0;
                        remainder_value=57'(remainder_value << 2);
                    end
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_r4_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_r4_57 arithmetic(.*,.combinational_result());
endmodule

module norm_r4_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic [16:0] quotient;
        logic [30:0] denominator_2_1;
        logic signed [31:0] trial_2_1;
        logic [30:0] denominator_2_2;
        logic signed [31:0] trial_2_2;
        logic [30:0] denominator_2_3;
        logic signed [31:0] trial_2_3;
        begin
            remainder_value=magnitude;
            quotient=0;
            denominator_2_1=31'(denominator)*31'd1;
            trial_2_1=0;
            denominator_2_2=31'(denominator)*31'd2;
            trial_2_2=0;
            denominator_2_3=31'(denominator)*31'd3;
            trial_2_3=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[14 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[14 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[14 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[14 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[12 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[12 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[12 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[12 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[10 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[10 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[10 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[10 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[8 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[8 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[8 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[8 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[6 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[6 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[6 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[6 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[4 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[4 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[4 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[4 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[2 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[2 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[2 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[2 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
                trial_2_1=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_1});
                trial_2_2=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_2});
                trial_2_3=$signed({1'b0,remainder_value,2'd0})-$signed({1'b0,denominator_2_3});
                if(!trial_2_2[31]) begin
                    if(!trial_2_3[31]) begin
                        quotient[0 +: 2]=2'd3;
                        remainder_value=trial_2_3[28:0];
                    end else begin
                        quotient[0 +: 2]=2'd2;
                        remainder_value=trial_2_2[28:0];
                    end
                end else begin
                    if(!trial_2_1[31]) begin
                        quotient[0 +: 2]=2'd1;
                        remainder_value=trial_2_1[28:0];
                    end else begin
                        quotient[0 +: 2]=2'd0;
                        remainder_value=29'(remainder_value << 2);
                    end
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_phase_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_r4_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_r4_29 arithmetic(.*,.combinational_result());
endmodule

module norm_r16_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic [16:0] quotient;
        logic [60:0] denominator_4_1;
        logic signed [61:0] trial_4_1;
        logic [60:0] denominator_4_2;
        logic signed [61:0] trial_4_2;
        logic [60:0] denominator_4_3;
        logic signed [61:0] trial_4_3;
        logic [60:0] denominator_4_4;
        logic signed [61:0] trial_4_4;
        logic [60:0] denominator_4_5;
        logic signed [61:0] trial_4_5;
        logic [60:0] denominator_4_6;
        logic signed [61:0] trial_4_6;
        logic [60:0] denominator_4_7;
        logic signed [61:0] trial_4_7;
        logic [60:0] denominator_4_8;
        logic signed [61:0] trial_4_8;
        logic [60:0] denominator_4_9;
        logic signed [61:0] trial_4_9;
        logic [60:0] denominator_4_10;
        logic signed [61:0] trial_4_10;
        logic [60:0] denominator_4_11;
        logic signed [61:0] trial_4_11;
        logic [60:0] denominator_4_12;
        logic signed [61:0] trial_4_12;
        logic [60:0] denominator_4_13;
        logic signed [61:0] trial_4_13;
        logic [60:0] denominator_4_14;
        logic signed [61:0] trial_4_14;
        logic [60:0] denominator_4_15;
        logic signed [61:0] trial_4_15;
        begin
            remainder_value=magnitude;
            quotient=0;
            denominator_4_1=61'(denominator)*61'd1;
            trial_4_1=0;
            denominator_4_2=61'(denominator)*61'd2;
            trial_4_2=0;
            denominator_4_3=61'(denominator)*61'd3;
            trial_4_3=0;
            denominator_4_4=61'(denominator)*61'd4;
            trial_4_4=0;
            denominator_4_5=61'(denominator)*61'd5;
            trial_4_5=0;
            denominator_4_6=61'(denominator)*61'd6;
            trial_4_6=0;
            denominator_4_7=61'(denominator)*61'd7;
            trial_4_7=0;
            denominator_4_8=61'(denominator)*61'd8;
            trial_4_8=0;
            denominator_4_9=61'(denominator)*61'd9;
            trial_4_9=0;
            denominator_4_10=61'(denominator)*61'd10;
            trial_4_10=0;
            denominator_4_11=61'(denominator)*61'd11;
            trial_4_11=0;
            denominator_4_12=61'(denominator)*61'd12;
            trial_4_12=0;
            denominator_4_13=61'(denominator)*61'd13;
            trial_4_13=0;
            denominator_4_14=61'(denominator)*61'd14;
            trial_4_14=0;
            denominator_4_15=61'(denominator)*61'd15;
            trial_4_15=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[61]) begin
                    if(!trial_4_12[61]) begin
                        if(!trial_4_14[61]) begin
                            if(!trial_4_15[61]) begin
                                quotient[12 +: 4]=4'd15;
                                remainder_value=trial_4_15[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd14;
                                remainder_value=trial_4_14[56:0];
                            end
                        end else begin
                            if(!trial_4_13[61]) begin
                                quotient[12 +: 4]=4'd13;
                                remainder_value=trial_4_13[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd12;
                                remainder_value=trial_4_12[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[61]) begin
                            if(!trial_4_11[61]) begin
                                quotient[12 +: 4]=4'd11;
                                remainder_value=trial_4_11[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd10;
                                remainder_value=trial_4_10[56:0];
                            end
                        end else begin
                            if(!trial_4_9[61]) begin
                                quotient[12 +: 4]=4'd9;
                                remainder_value=trial_4_9[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd8;
                                remainder_value=trial_4_8[56:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[61]) begin
                        if(!trial_4_6[61]) begin
                            if(!trial_4_7[61]) begin
                                quotient[12 +: 4]=4'd7;
                                remainder_value=trial_4_7[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd6;
                                remainder_value=trial_4_6[56:0];
                            end
                        end else begin
                            if(!trial_4_5[61]) begin
                                quotient[12 +: 4]=4'd5;
                                remainder_value=trial_4_5[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd4;
                                remainder_value=trial_4_4[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[61]) begin
                            if(!trial_4_3[61]) begin
                                quotient[12 +: 4]=4'd3;
                                remainder_value=trial_4_3[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd2;
                                remainder_value=trial_4_2[56:0];
                            end
                        end else begin
                            if(!trial_4_1[61]) begin
                                quotient[12 +: 4]=4'd1;
                                remainder_value=trial_4_1[56:0];
                            end else begin
                                quotient[12 +: 4]=4'd0;
                                remainder_value=57'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[61]) begin
                    if(!trial_4_12[61]) begin
                        if(!trial_4_14[61]) begin
                            if(!trial_4_15[61]) begin
                                quotient[8 +: 4]=4'd15;
                                remainder_value=trial_4_15[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd14;
                                remainder_value=trial_4_14[56:0];
                            end
                        end else begin
                            if(!trial_4_13[61]) begin
                                quotient[8 +: 4]=4'd13;
                                remainder_value=trial_4_13[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd12;
                                remainder_value=trial_4_12[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[61]) begin
                            if(!trial_4_11[61]) begin
                                quotient[8 +: 4]=4'd11;
                                remainder_value=trial_4_11[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd10;
                                remainder_value=trial_4_10[56:0];
                            end
                        end else begin
                            if(!trial_4_9[61]) begin
                                quotient[8 +: 4]=4'd9;
                                remainder_value=trial_4_9[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd8;
                                remainder_value=trial_4_8[56:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[61]) begin
                        if(!trial_4_6[61]) begin
                            if(!trial_4_7[61]) begin
                                quotient[8 +: 4]=4'd7;
                                remainder_value=trial_4_7[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd6;
                                remainder_value=trial_4_6[56:0];
                            end
                        end else begin
                            if(!trial_4_5[61]) begin
                                quotient[8 +: 4]=4'd5;
                                remainder_value=trial_4_5[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd4;
                                remainder_value=trial_4_4[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[61]) begin
                            if(!trial_4_3[61]) begin
                                quotient[8 +: 4]=4'd3;
                                remainder_value=trial_4_3[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd2;
                                remainder_value=trial_4_2[56:0];
                            end
                        end else begin
                            if(!trial_4_1[61]) begin
                                quotient[8 +: 4]=4'd1;
                                remainder_value=trial_4_1[56:0];
                            end else begin
                                quotient[8 +: 4]=4'd0;
                                remainder_value=57'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[61]) begin
                    if(!trial_4_12[61]) begin
                        if(!trial_4_14[61]) begin
                            if(!trial_4_15[61]) begin
                                quotient[4 +: 4]=4'd15;
                                remainder_value=trial_4_15[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd14;
                                remainder_value=trial_4_14[56:0];
                            end
                        end else begin
                            if(!trial_4_13[61]) begin
                                quotient[4 +: 4]=4'd13;
                                remainder_value=trial_4_13[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd12;
                                remainder_value=trial_4_12[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[61]) begin
                            if(!trial_4_11[61]) begin
                                quotient[4 +: 4]=4'd11;
                                remainder_value=trial_4_11[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd10;
                                remainder_value=trial_4_10[56:0];
                            end
                        end else begin
                            if(!trial_4_9[61]) begin
                                quotient[4 +: 4]=4'd9;
                                remainder_value=trial_4_9[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd8;
                                remainder_value=trial_4_8[56:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[61]) begin
                        if(!trial_4_6[61]) begin
                            if(!trial_4_7[61]) begin
                                quotient[4 +: 4]=4'd7;
                                remainder_value=trial_4_7[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd6;
                                remainder_value=trial_4_6[56:0];
                            end
                        end else begin
                            if(!trial_4_5[61]) begin
                                quotient[4 +: 4]=4'd5;
                                remainder_value=trial_4_5[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd4;
                                remainder_value=trial_4_4[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[61]) begin
                            if(!trial_4_3[61]) begin
                                quotient[4 +: 4]=4'd3;
                                remainder_value=trial_4_3[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd2;
                                remainder_value=trial_4_2[56:0];
                            end
                        end else begin
                            if(!trial_4_1[61]) begin
                                quotient[4 +: 4]=4'd1;
                                remainder_value=trial_4_1[56:0];
                            end else begin
                                quotient[4 +: 4]=4'd0;
                                remainder_value=57'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[61]) begin
                    if(!trial_4_12[61]) begin
                        if(!trial_4_14[61]) begin
                            if(!trial_4_15[61]) begin
                                quotient[0 +: 4]=4'd15;
                                remainder_value=trial_4_15[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd14;
                                remainder_value=trial_4_14[56:0];
                            end
                        end else begin
                            if(!trial_4_13[61]) begin
                                quotient[0 +: 4]=4'd13;
                                remainder_value=trial_4_13[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd12;
                                remainder_value=trial_4_12[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[61]) begin
                            if(!trial_4_11[61]) begin
                                quotient[0 +: 4]=4'd11;
                                remainder_value=trial_4_11[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd10;
                                remainder_value=trial_4_10[56:0];
                            end
                        end else begin
                            if(!trial_4_9[61]) begin
                                quotient[0 +: 4]=4'd9;
                                remainder_value=trial_4_9[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd8;
                                remainder_value=trial_4_8[56:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[61]) begin
                        if(!trial_4_6[61]) begin
                            if(!trial_4_7[61]) begin
                                quotient[0 +: 4]=4'd7;
                                remainder_value=trial_4_7[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd6;
                                remainder_value=trial_4_6[56:0];
                            end
                        end else begin
                            if(!trial_4_5[61]) begin
                                quotient[0 +: 4]=4'd5;
                                remainder_value=trial_4_5[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd4;
                                remainder_value=trial_4_4[56:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[61]) begin
                            if(!trial_4_3[61]) begin
                                quotient[0 +: 4]=4'd3;
                                remainder_value=trial_4_3[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd2;
                                remainder_value=trial_4_2[56:0];
                            end
                        end else begin
                            if(!trial_4_1[61]) begin
                                quotient[0 +: 4]=4'd1;
                                remainder_value=trial_4_1[56:0];
                            end else begin
                                quotient[0 +: 4]=4'd0;
                                remainder_value=57'(remainder_value << 4);
                            end
                        end
                    end
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_r16_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_r16_57 arithmetic(.*,.combinational_result());
endmodule

module norm_r16_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic [16:0] quotient;
        logic [32:0] denominator_4_1;
        logic signed [33:0] trial_4_1;
        logic [32:0] denominator_4_2;
        logic signed [33:0] trial_4_2;
        logic [32:0] denominator_4_3;
        logic signed [33:0] trial_4_3;
        logic [32:0] denominator_4_4;
        logic signed [33:0] trial_4_4;
        logic [32:0] denominator_4_5;
        logic signed [33:0] trial_4_5;
        logic [32:0] denominator_4_6;
        logic signed [33:0] trial_4_6;
        logic [32:0] denominator_4_7;
        logic signed [33:0] trial_4_7;
        logic [32:0] denominator_4_8;
        logic signed [33:0] trial_4_8;
        logic [32:0] denominator_4_9;
        logic signed [33:0] trial_4_9;
        logic [32:0] denominator_4_10;
        logic signed [33:0] trial_4_10;
        logic [32:0] denominator_4_11;
        logic signed [33:0] trial_4_11;
        logic [32:0] denominator_4_12;
        logic signed [33:0] trial_4_12;
        logic [32:0] denominator_4_13;
        logic signed [33:0] trial_4_13;
        logic [32:0] denominator_4_14;
        logic signed [33:0] trial_4_14;
        logic [32:0] denominator_4_15;
        logic signed [33:0] trial_4_15;
        begin
            remainder_value=magnitude;
            quotient=0;
            denominator_4_1=33'(denominator)*33'd1;
            trial_4_1=0;
            denominator_4_2=33'(denominator)*33'd2;
            trial_4_2=0;
            denominator_4_3=33'(denominator)*33'd3;
            trial_4_3=0;
            denominator_4_4=33'(denominator)*33'd4;
            trial_4_4=0;
            denominator_4_5=33'(denominator)*33'd5;
            trial_4_5=0;
            denominator_4_6=33'(denominator)*33'd6;
            trial_4_6=0;
            denominator_4_7=33'(denominator)*33'd7;
            trial_4_7=0;
            denominator_4_8=33'(denominator)*33'd8;
            trial_4_8=0;
            denominator_4_9=33'(denominator)*33'd9;
            trial_4_9=0;
            denominator_4_10=33'(denominator)*33'd10;
            trial_4_10=0;
            denominator_4_11=33'(denominator)*33'd11;
            trial_4_11=0;
            denominator_4_12=33'(denominator)*33'd12;
            trial_4_12=0;
            denominator_4_13=33'(denominator)*33'd13;
            trial_4_13=0;
            denominator_4_14=33'(denominator)*33'd14;
            trial_4_14=0;
            denominator_4_15=33'(denominator)*33'd15;
            trial_4_15=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[33]) begin
                    if(!trial_4_12[33]) begin
                        if(!trial_4_14[33]) begin
                            if(!trial_4_15[33]) begin
                                quotient[12 +: 4]=4'd15;
                                remainder_value=trial_4_15[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd14;
                                remainder_value=trial_4_14[28:0];
                            end
                        end else begin
                            if(!trial_4_13[33]) begin
                                quotient[12 +: 4]=4'd13;
                                remainder_value=trial_4_13[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd12;
                                remainder_value=trial_4_12[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[33]) begin
                            if(!trial_4_11[33]) begin
                                quotient[12 +: 4]=4'd11;
                                remainder_value=trial_4_11[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd10;
                                remainder_value=trial_4_10[28:0];
                            end
                        end else begin
                            if(!trial_4_9[33]) begin
                                quotient[12 +: 4]=4'd9;
                                remainder_value=trial_4_9[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd8;
                                remainder_value=trial_4_8[28:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[33]) begin
                        if(!trial_4_6[33]) begin
                            if(!trial_4_7[33]) begin
                                quotient[12 +: 4]=4'd7;
                                remainder_value=trial_4_7[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd6;
                                remainder_value=trial_4_6[28:0];
                            end
                        end else begin
                            if(!trial_4_5[33]) begin
                                quotient[12 +: 4]=4'd5;
                                remainder_value=trial_4_5[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd4;
                                remainder_value=trial_4_4[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[33]) begin
                            if(!trial_4_3[33]) begin
                                quotient[12 +: 4]=4'd3;
                                remainder_value=trial_4_3[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd2;
                                remainder_value=trial_4_2[28:0];
                            end
                        end else begin
                            if(!trial_4_1[33]) begin
                                quotient[12 +: 4]=4'd1;
                                remainder_value=trial_4_1[28:0];
                            end else begin
                                quotient[12 +: 4]=4'd0;
                                remainder_value=29'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[33]) begin
                    if(!trial_4_12[33]) begin
                        if(!trial_4_14[33]) begin
                            if(!trial_4_15[33]) begin
                                quotient[8 +: 4]=4'd15;
                                remainder_value=trial_4_15[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd14;
                                remainder_value=trial_4_14[28:0];
                            end
                        end else begin
                            if(!trial_4_13[33]) begin
                                quotient[8 +: 4]=4'd13;
                                remainder_value=trial_4_13[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd12;
                                remainder_value=trial_4_12[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[33]) begin
                            if(!trial_4_11[33]) begin
                                quotient[8 +: 4]=4'd11;
                                remainder_value=trial_4_11[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd10;
                                remainder_value=trial_4_10[28:0];
                            end
                        end else begin
                            if(!trial_4_9[33]) begin
                                quotient[8 +: 4]=4'd9;
                                remainder_value=trial_4_9[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd8;
                                remainder_value=trial_4_8[28:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[33]) begin
                        if(!trial_4_6[33]) begin
                            if(!trial_4_7[33]) begin
                                quotient[8 +: 4]=4'd7;
                                remainder_value=trial_4_7[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd6;
                                remainder_value=trial_4_6[28:0];
                            end
                        end else begin
                            if(!trial_4_5[33]) begin
                                quotient[8 +: 4]=4'd5;
                                remainder_value=trial_4_5[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd4;
                                remainder_value=trial_4_4[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[33]) begin
                            if(!trial_4_3[33]) begin
                                quotient[8 +: 4]=4'd3;
                                remainder_value=trial_4_3[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd2;
                                remainder_value=trial_4_2[28:0];
                            end
                        end else begin
                            if(!trial_4_1[33]) begin
                                quotient[8 +: 4]=4'd1;
                                remainder_value=trial_4_1[28:0];
                            end else begin
                                quotient[8 +: 4]=4'd0;
                                remainder_value=29'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[33]) begin
                    if(!trial_4_12[33]) begin
                        if(!trial_4_14[33]) begin
                            if(!trial_4_15[33]) begin
                                quotient[4 +: 4]=4'd15;
                                remainder_value=trial_4_15[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd14;
                                remainder_value=trial_4_14[28:0];
                            end
                        end else begin
                            if(!trial_4_13[33]) begin
                                quotient[4 +: 4]=4'd13;
                                remainder_value=trial_4_13[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd12;
                                remainder_value=trial_4_12[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[33]) begin
                            if(!trial_4_11[33]) begin
                                quotient[4 +: 4]=4'd11;
                                remainder_value=trial_4_11[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd10;
                                remainder_value=trial_4_10[28:0];
                            end
                        end else begin
                            if(!trial_4_9[33]) begin
                                quotient[4 +: 4]=4'd9;
                                remainder_value=trial_4_9[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd8;
                                remainder_value=trial_4_8[28:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[33]) begin
                        if(!trial_4_6[33]) begin
                            if(!trial_4_7[33]) begin
                                quotient[4 +: 4]=4'd7;
                                remainder_value=trial_4_7[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd6;
                                remainder_value=trial_4_6[28:0];
                            end
                        end else begin
                            if(!trial_4_5[33]) begin
                                quotient[4 +: 4]=4'd5;
                                remainder_value=trial_4_5[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd4;
                                remainder_value=trial_4_4[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[33]) begin
                            if(!trial_4_3[33]) begin
                                quotient[4 +: 4]=4'd3;
                                remainder_value=trial_4_3[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd2;
                                remainder_value=trial_4_2[28:0];
                            end
                        end else begin
                            if(!trial_4_1[33]) begin
                                quotient[4 +: 4]=4'd1;
                                remainder_value=trial_4_1[28:0];
                            end else begin
                                quotient[4 +: 4]=4'd0;
                                remainder_value=29'(remainder_value << 4);
                            end
                        end
                    end
                end
                trial_4_1=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_1});
                trial_4_2=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_2});
                trial_4_3=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_3});
                trial_4_4=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_4});
                trial_4_5=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_5});
                trial_4_6=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_6});
                trial_4_7=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_7});
                trial_4_8=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_8});
                trial_4_9=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_9});
                trial_4_10=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_10});
                trial_4_11=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_11});
                trial_4_12=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_12});
                trial_4_13=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_13});
                trial_4_14=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_14});
                trial_4_15=$signed({1'b0,remainder_value,4'd0})-$signed({1'b0,denominator_4_15});
                if(!trial_4_8[33]) begin
                    if(!trial_4_12[33]) begin
                        if(!trial_4_14[33]) begin
                            if(!trial_4_15[33]) begin
                                quotient[0 +: 4]=4'd15;
                                remainder_value=trial_4_15[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd14;
                                remainder_value=trial_4_14[28:0];
                            end
                        end else begin
                            if(!trial_4_13[33]) begin
                                quotient[0 +: 4]=4'd13;
                                remainder_value=trial_4_13[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd12;
                                remainder_value=trial_4_12[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_10[33]) begin
                            if(!trial_4_11[33]) begin
                                quotient[0 +: 4]=4'd11;
                                remainder_value=trial_4_11[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd10;
                                remainder_value=trial_4_10[28:0];
                            end
                        end else begin
                            if(!trial_4_9[33]) begin
                                quotient[0 +: 4]=4'd9;
                                remainder_value=trial_4_9[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd8;
                                remainder_value=trial_4_8[28:0];
                            end
                        end
                    end
                end else begin
                    if(!trial_4_4[33]) begin
                        if(!trial_4_6[33]) begin
                            if(!trial_4_7[33]) begin
                                quotient[0 +: 4]=4'd7;
                                remainder_value=trial_4_7[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd6;
                                remainder_value=trial_4_6[28:0];
                            end
                        end else begin
                            if(!trial_4_5[33]) begin
                                quotient[0 +: 4]=4'd5;
                                remainder_value=trial_4_5[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd4;
                                remainder_value=trial_4_4[28:0];
                            end
                        end
                    end else begin
                        if(!trial_4_2[33]) begin
                            if(!trial_4_3[33]) begin
                                quotient[0 +: 4]=4'd3;
                                remainder_value=trial_4_3[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd2;
                                remainder_value=trial_4_2[28:0];
                            end
                        end else begin
                            if(!trial_4_1[33]) begin
                                quotient[0 +: 4]=4'd1;
                                remainder_value=trial_4_1[28:0];
                            end else begin
                                quotient[0 +: 4]=4'd0;
                                remainder_value=29'(remainder_value << 4);
                            end
                        end
                    end
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_phase_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_r16_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_r16_29 arithmetic(.*,.combinational_result());
endmodule

module norm_nr_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic signed [57:0] remainder_value;
        logic signed [57:0] positive_denominator,negative_denominator;
        logic [16:0] quotient;
        begin
            remainder_value=$signed({1'b0,magnitude});
            positive_denominator=$signed({1'b0,denominator});
            negative_denominator=-positive_denominator;
            quotient=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    remainder_value=(remainder_value <<< 1)+
                        (remainder_value[57] ? positive_denominator : negative_denominator);
                    quotient[bit_index]=!remainder_value[57];
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_nr_57(
    input logic clk, reset_n,
    input logic [56:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_nr_57 arithmetic(.*,.combinational_result());
endmodule

module norm_nr_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result,
    output logic [16:0] combinational_result
);
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic signed [29:0] remainder_value;
        logic signed [29:0] positive_denominator,negative_denominator;
        logic [16:0] quotient;
        begin
            remainder_value=$signed({1'b0,magnitude});
            positive_denominator=$signed({1'b0,denominator});
            negative_denominator=-positive_denominator;
            quotient=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0; quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    remainder_value=(remainder_value <<< 1)+
                        (remainder_value[29] ? positive_denominator : negative_denominator);
                    quotient[bit_index]=!remainder_value[29];
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    assign combinational_result=normalized_phase_ratio_q16(magnitude,denominator);
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) result<=0;
        else result<=combinational_result;
endmodule
module probe_nr_29(
    input logic clk, reset_n,
    input logic [28:0] magnitude, denominator,
    output logic [16:0] result
);
    norm_nr_29 arithmetic(.*,.combinational_result());
endmodule
