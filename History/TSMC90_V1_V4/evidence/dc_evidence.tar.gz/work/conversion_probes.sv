module conversion_original(
    input logic clk,reset_n,
    input logic signed [31:0] raw_code,raw_carrier,base_doppler,
    output logic [32:0] code_step,
    output logic [31:0] carrier_step
);
    localparam logic signed [63:0] CODE_LIMIT=64'sd1638400,CARRIER_LIMIT=64'sd655360000;
    logic signed [63:0] code_command,carrier_command,code_delta_word,carrier_delta_word;
    logic [32:0] code_next;
    logic [31:0] carrier_next;
    function automatic logic signed [63:0] clamp(input logic signed [63:0] value,input logic signed [63:0] limit);
        if(value>limit) clamp=limit;
        else if(value < -limit) clamp=-limit;
        else clamp=value;
    endfunction

    always_comb begin
        code_command=clamp(64'($signed(raw_code)),CODE_LIMIT);
        carrier_command=clamp(64'($signed(raw_carrier)),CARRIER_LIMIT);
        code_delta_word=(code_command*65536)/16368000;
        carrier_delta_word=(carrier_command*65536)/16368000;
        code_next=33'(64'sh20000000+code_delta_word+(64'($signed(base_doppler))+carrier_delta_word)/763);
        carrier_next=32'(64'sh40000000+64'($signed(base_doppler))+carrier_delta_word);
    end
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) begin code_step<=0;carrier_step<=0;end
        else begin code_step<=code_next;carrier_step<=carrier_next;end
endmodule

module conversion_optimized(
    input logic clk,reset_n,
    input logic signed [31:0] raw_code,raw_carrier,base_doppler,
    output logic [32:0] code_step,
    output logic [31:0] carrier_step
);
    localparam logic signed [63:0] CODE_LIMIT=64'sd1638400,CARRIER_LIMIT=64'sd655360000;
    logic signed [21:0] code_command; logic signed [30:0] carrier_command; logic signed [13:0] code_delta_word; logic signed [22:0] carrier_delta_word; logic signed [23:0] feedback_aid_word;
    logic [32:0] code_next;
    logic [31:0] carrier_next;
    function automatic logic signed [63:0] clamp(input logic signed [63:0] value,input logic signed [63:0] limit);
        if(value>limit) clamp=limit;
        else if(value < -limit) clamp=-limit;
        else clamp=value;
    endfunction
    function automatic logic signed [23:0] divide_step_127875(input logic signed [39:0] value);
        logic [39:0] magnitude;
        logic [63:0] product;
        logic [23:0] quotient;
        logic [40:0] remainder_value;
        begin
            magnitude=value[39] ? (~value+40'd1) : value;
            product=magnitude*24'd8598331;
            quotient=product[63:40];
            remainder_value={1'b0,magnitude}-(41'(quotient)*41'd127875);
            if(remainder_value>=41'd127875) quotient=quotient+24'd1;
            divide_step_127875=value[39] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction
    function automatic logic signed [23:0] divide_aid_763(input logic signed [32:0] value);
        logic [32:0] magnitude;
        logic [56:0] product;
        logic [23:0] quotient;
        logic [33:0] remainder_value;
        begin
            magnitude=value[32] ? (~value+33'd1) : value;
            product=magnitude*24'd11258105;
            quotient=product[56:33];
            remainder_value={1'b0,magnitude}-(34'(quotient)*34'd763);
            if(remainder_value>=34'd763) quotient=quotient+24'd1;
            divide_aid_763=value[32] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction
    always_comb begin
        code_command=clamp(64'($signed(raw_code)),CODE_LIMIT);
        carrier_command=clamp(64'($signed(raw_carrier)),CARRIER_LIMIT);
        code_delta_word=14'(divide_step_127875(40'(64'($signed(code_command))*512)));
        carrier_delta_word=23'(divide_step_127875(40'(64'($signed(carrier_command))*512)));
        feedback_aid_word=divide_aid_763(33'(64'($signed(base_doppler))+carrier_delta_word));
        code_next=33'(64'sh20000000+code_delta_word+64'($signed(feedback_aid_word)));
        carrier_next=32'(64'sh40000000+64'($signed(base_doppler))+carrier_delta_word);
    end
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) begin code_step<=0;carrier_step<=0;end
        else begin code_step<=code_next;carrier_step<=carrier_next;end
endmodule
