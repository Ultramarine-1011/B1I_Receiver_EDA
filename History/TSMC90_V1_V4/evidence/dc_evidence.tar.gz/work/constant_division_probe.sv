module constant_division_probe(input logic signed [39:0] step_value,input logic signed [32:0] aid_value,output logic signed [23:0] step_result,aid_result);
    function automatic logic signed [23:0] divide_step_127875(input logic signed [39:0] value);
        logic [39:0] magnitude;
        logic [63:0] product;
        logic [23:0] quotient;
        logic [40:0] remainder_value;
        begin
            magnitude=value[39] ? (~value+40'd1) : value;
            product=magnitude*24'd8598331;
            quotient=product[63:40];
            remainder_value={1'b0,magnitude}-(41'(quotient)*41'd127875);
            if(remainder_value>=41'd127875) quotient=quotient+24'd1;
            divide_step_127875=value[39] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction
    function automatic logic signed [23:0] divide_aid_763(input logic signed [32:0] value);
        logic [32:0] magnitude;
        logic [56:0] product;
        logic [23:0] quotient;
        logic [33:0] remainder_value;
        begin
            magnitude=value[32] ? (~value+33'd1) : value;
            product=magnitude*24'd11258105;
            quotient=product[56:33];
            remainder_value={1'b0,magnitude}-(34'(quotient)*34'd763);
            if(remainder_value>=34'd763) quotient=quotient+24'd1;
            divide_aid_763=value[32] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction
 always_comb begin step_result=divide_step_127875(step_value);aid_result=divide_aid_763(aid_value);end
endmodule
