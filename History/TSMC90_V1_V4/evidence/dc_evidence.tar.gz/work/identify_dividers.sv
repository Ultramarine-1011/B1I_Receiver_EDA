module identify_code (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic signed [79:0] code_numerator,phase_numerator;

    always_comb begin
        dphase=0;
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        code_numerator=(80'($signed(pe))-80'($signed(pl))) <<< 16;
        dcode=!window_done || den_code==0 ? 64'sd0 : 64'(code_numerator / 80'($signed(den_code)));
        dcode=(dcode*11)/32; // (1-delta)/2, delta=5/16 chip in this wrapper
    end
endmodule

module identify_phase (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic signed [79:0] code_numerator,phase_numerator;

    always_comb begin
        dcode=0;
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        phase_numerator=80'($signed(qp)) <<< 16;
        if(ip<0) phase_numerator=-phase_numerator;
        dphase=!window_done || (abs_i+abs_q)==0 ? 64'sd0 : 64'(phase_numerator / 80'($signed(abs_i+abs_q)));
        dphase=(dphase*10430) >>> 16; // small-error Costas approximation, turn Q16
    end
endmodule
