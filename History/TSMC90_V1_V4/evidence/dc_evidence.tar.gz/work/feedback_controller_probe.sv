module feedback_controller_probe(
input logic clk,reset_n,
input logic window_done,
input logic signed [27:0] ie,qe,ip,qp,il,ql,
input logic [41:0] window_energy,
input logic [63:0] window_ref,
input logic signed [31:0] init_doppler_word,
input logic [63:0] previous_prompt_ref,
input logic signed [27:0] previous_ip,previous_qp,
input logic previous_prompt_valid,
input logic previous_phase_valid,
input logic [31:0] phase_mean_square_q32,
input logic signed [31:0] code_mean_q16,frequency_mean_q16,previous_phase_q16,
input logic [7:0] population,seen,
input logic [127:0] validity_history,
input logic signed [31:0] base_doppler,code_integral,carrier_integral,
output logic [32:0] code_step,
output logic [31:0] carrier_step
);
    logic [1151:0] observed_values;
    logic signed [63:0] code_delta_word,carrier_delta_word,feedback_aid_word;
    logic [32:0] code_next;
    logic [31:0] carrier_next;
    loop_optimized math(.*);
    always_comb begin
        code_delta_word=$signed(observed_values[767:704]);
        carrier_delta_word=$signed(observed_values[703:640]);
        feedback_aid_word=$signed(observed_values[63:0]);
        code_next=33'(64'sh20000000+code_delta_word+feedback_aid_word);
        carrier_next=32'(64'sh40000000+64'($signed(base_doppler))+carrier_delta_word);
    end
    always_ff @(posedge clk or negedge reset_n)
        if(!reset_n) begin code_step<=0;carrier_step<=0;end
        else begin code_step<=code_next;carrier_step<=carrier_next;end
endmodule
