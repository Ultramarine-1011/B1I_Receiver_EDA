module loop_original #(parameter integer ENABLE_FLL=1)(
input logic window_done,
input logic signed [27:0] ie,qe,ip,qp,il,ql,
input logic [41:0] window_energy,
input logic [63:0] window_ref,
input logic signed [31:0] init_doppler_word,
input logic [63:0] previous_prompt_ref,
input logic signed [27:0] previous_ip,previous_qp,
input logic previous_prompt_valid,
input logic previous_phase_valid,
input logic [31:0] phase_mean_square_q32,
input logic signed [31:0] code_mean_q16,frequency_mean_q16,previous_phase_q16,
input logic [7:0] population,seen,
input logic [127:0] validity_history,
input logic signed [31:0] base_doppler,code_integral,carrier_integral,
output logic [1151:0] observed_values);
    localparam logic signed [63:0] CODE_LIMIT=64'sd1638400; // 25 chip/s Q16
    localparam logic signed [63:0] CARRIER_LIMIT=64'sd655360000; // 10 kHz Q16
    logic code_valid, accepted, enabled;

    logic [5:0] good_windows;
    logic [2:0] bad_windows;
    logic [4:0] invalid_run;


    logic [8:0] population_next;






    logic signed [63:0] fll_dot,fll_cross,fll_frequency,fll_adjustment;
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic signed [79:0] code_numerator, phase_numerator;
    logic signed [63:0] dcode, dphase, ci_next, pi_next, code_command, carrier_command;
    logic signed [63:0] code_delta_word, carrier_delta_word;
    logic valid_energy, good_error;
    logic signed [63:0] phase_square, phase_mean_next, code_mean_next, frequency_mean_next;
    logic signed [23:0] initial_aid_word,feedback_aid_word;
    logic fll_active;
    function automatic logic signed [63:0] clamp(input logic signed [63:0] value,input logic signed [63:0] limit);
        if(value>limit) clamp=limit;
        else if(value < -limit) clamp=-limit;
        else clamp=value;
    endfunction
    // Vectoring CORDIC, turns Q32 -> Q16. Fold BPSK sign using dot's sign.
    function automatic logic signed [31:0] atan_turn_q16(input logic signed [63:0] dot_value,cross_value);
        logic signed [63:0] x,y,nx,ny,z;
        logic signed [63:0] angle;
        begin
            x=dot_value<0 ? -dot_value : dot_value;y=dot_value<0 ? -cross_value : cross_value;z=0;
            for(integer k=0;k<16;k=k+1) begin
                case(k)
                    0:angle=64'sd536870912;1:angle=64'sd316933406;2:angle=64'sd167458907;
                    3:angle=64'sd85004756;4:angle=64'sd42667331;5:angle=64'sd21354465;
                    6:angle=64'sd10679838;7:angle=64'sd5340245;8:angle=64'sd2670163;
                    9:angle=64'sd1335087;10:angle=64'sd667544;11:angle=64'sd333772;
                    12:angle=64'sd166886;13:angle=64'sd83443;14:angle=64'sd41722;default:angle=64'sd20861;
                endcase
                if(y>0) begin nx=x+(y >>> k);ny=y-(x >>> k);z=z+angle;end
                else if(y<0) begin nx=x-(y >>> k);ny=y+(x >>> k);z=z-angle;end
                else begin nx=x;ny=y;end
                x=nx;y=ny;
            end
            atan_turn_q16=32'(z >>> 16);
        end
    endfunction
    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        code_numerator=(80'($signed(pe))-80'($signed(pl))) <<< 16;
        phase_numerator=80'($signed(qp)) <<< 16;
        if(ip<0) phase_numerator=-phase_numerator;
        dcode=!window_done || den_code==0 ? 64'sd0 : 64'(code_numerator / 80'($signed(den_code)));
        dcode=(dcode*11)/32; // (1-delta)/2, delta=5/16 chip in this wrapper
        dphase=!window_done || (abs_i+abs_q)==0 ? 64'sd0 : 64'(phase_numerator / 80'($signed(abs_i+abs_q)));
        dphase=(dphase*10430) >>> 16; // small-error Costas approximation, turn Q16
        valid_energy=pp > (64'(window_energy)*4) && den_code > (64'(window_energy)*8);
        ci_next=clamp(64'($signed(code_integral))+((dcode*932) >>> 16),CODE_LIMIT);
        fll_dot=64'($signed(previous_ip))*64'($signed(ip))+64'($signed(previous_qp))*64'($signed(qp));
        fll_cross=64'($signed(previous_ip))*64'($signed(qp))-64'($signed(previous_qp))*64'($signed(ip));
        fll_frequency=0;
        if(window_done && ENABLE_FLL!=0)
            fll_frequency=64'($signed(atan_turn_q16(fll_dot,fll_cross)))*1000;
        fll_active=ENABLE_FLL!=0 && seen<128;
        fll_adjustment=0;
        if(fll_active && previous_prompt_valid && valid_energy && window_ref==previous_prompt_ref+16368)
            fll_adjustment=(fll_frequency*3277) >>> 16; // 0.05, measured residual Hz Q16
        pi_next=clamp(64'($signed(carrier_integral))+((dphase*52429) >>> 16)+fll_adjustment,CARRIER_LIMIT);
        code_command=clamp(ci_next+((dcode*349525) >>> 16),CODE_LIMIT);
        carrier_command=clamp(pi_next+dphase*40,CARRIER_LIMIT);
        code_delta_word=(code_command*65536)/16368000;
        carrier_delta_word=(carrier_command*65536)/16368000;
        // Port the 9.28 LockEvidence/TrackingLoops policy: 128-window evidence,
        // smoothed measured errors, 32 good enter / 4 bad exit / 16 invalid exit.
        population_next={1'b0,population}+9'(valid_energy)-9'(validity_history[127]);
        phase_square=dphase*dphase;
        phase_mean_next=$signed({32'd0,phase_mean_square_q32})+(((phase_square-$signed({32'd0,phase_mean_square_q32}))*1311) >>> 16);
        code_mean_next=64'($signed(code_mean_q16))+(((dcode-64'($signed(code_mean_q16)))*1311) >>> 16);
        frequency_mean_next=64'($signed(frequency_mean_q16));
        if(previous_phase_valid)
            frequency_mean_next=frequency_mean_next+(((1000*(dphase-64'($signed(previous_phase_q16)))-frequency_mean_next)*3277) >>> 16);
        good_error=seen==128 && population>=64 && phase_mean_square_q32<32'd10737418
                   && code_mean_q16>-6554 && code_mean_q16<6554
                   && frequency_mean_q16>-655360 && frequency_mean_q16<655360;
        initial_aid_word=24'(64'($signed(init_doppler_word))/763);
        feedback_aid_word=24'((64'($signed(base_doppler))+carrier_delta_word)/763);
    end
    assign observed_values={64'($signed(dcode)),64'($signed(dphase)),64'($signed(ci_next)),64'($signed(pi_next)),64'($signed(code_command)),64'($signed(carrier_command)),64'($signed(code_delta_word)),64'($signed(carrier_delta_word)),64'($signed(phase_square)),64'($signed(phase_mean_next)),64'($signed(code_mean_next)),64'($signed(frequency_mean_next)),64'($signed(fll_adjustment)),64'($signed(fll_frequency)),64'($signed(fll_dot)),64'($signed(fll_cross)),64'($signed(initial_aid_word)),64'($signed(feedback_aid_word))};
endmodule

module loop_optimized #(parameter integer ENABLE_FLL=1)(
input logic window_done,
input logic signed [27:0] ie,qe,ip,qp,il,ql,
input logic [41:0] window_energy,
input logic [63:0] window_ref,
input logic signed [31:0] init_doppler_word,
input logic [63:0] previous_prompt_ref,
input logic signed [27:0] previous_ip,previous_qp,
input logic previous_prompt_valid,
input logic previous_phase_valid,
input logic [31:0] phase_mean_square_q32,
input logic signed [31:0] code_mean_q16,frequency_mean_q16,previous_phase_q16,
input logic [7:0] population,seen,
input logic [127:0] validity_history,
input logic signed [31:0] base_doppler,code_integral,carrier_integral,
output logic [1151:0] observed_values);
    localparam logic signed [63:0] CODE_LIMIT=64'sd1638400; // 25 chip/s Q16
    localparam logic signed [63:0] CARRIER_LIMIT=64'sd655360000; // 10 kHz Q16
    logic code_valid, accepted, enabled;

    logic [5:0] good_windows;
    logic [2:0] bad_windows;
    logic [4:0] invalid_run;


    logic [8:0] population_next;






    logic signed [56:0] fll_dot,fll_cross; // each magnitude <= 2^55 for all 28-bit Prompt values
    logic signed [25:0] fll_frequency; // signed 16-bit turn error times 1000
    logic signed [21:0] fll_adjustment; // signed 26-bit frequency times 3277, arithmetic >> 16
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic [56:0] code_magnitude;
    logic [28:0] phase_denominator;
    logic [16:0] code_ratio, phase_ratio;
    logic signed [17:0] code_ratio_signed, phase_ratio_signed;
    logic signed [15:0] dcode; // |dcode| <= 65536*11/32 = 22528
    logic signed [14:0] dphase; // -10430 <= floor(raw*10430/65536) <= 10430
    logic signed [21:0] ci_next, code_command; // clamp guarantees +/-1638400
    logic signed [30:0] pi_next, carrier_command; // clamp guarantees +/-655360000
    logic signed [13:0] code_delta_word; // maximum magnitude 6560
    logic signed [22:0] carrier_delta_word; // maximum magnitude 2624002
    logic signed [23:0] initial_aid_word, feedback_aid_word;
    logic valid_energy, good_error;
    logic signed [63:0] phase_square, phase_mean_next, code_mean_next, frequency_mean_next;
    logic fll_active;
    function automatic logic signed [63:0] clamp(input logic signed [63:0] value,input logic signed [63:0] limit);
        if(value>limit) clamp=limit;
        else if(value < -limit) clamp=-limit;
        else clamp=value;
    endfunction
    // M=floor(2^40/127875). The estimate is at most one below the exact quotient.
    // One remainder correction gives exact signed division toward zero for every 40-bit input.
    function automatic logic signed [23:0] divide_step_127875(input logic signed [39:0] value);
        logic [39:0] magnitude;
        logic [63:0] product;
        logic [23:0] quotient;
        logic [40:0] remainder_value;
        begin
            magnitude=value[39] ? (~value+40'd1) : value;
            product=magnitude*24'd8598331;
            quotient=product[63:40];
            remainder_value={1'b0,magnitude}-(41'(quotient)*41'd127875);
            if(remainder_value>=41'd127875) quotient=quotient+24'd1;
            divide_step_127875=value[39] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction
    // The same identity with M=floor(2^33/763), covering every signed 33-bit word.
    function automatic logic signed [23:0] divide_aid_763(input logic signed [32:0] value);
        logic [32:0] magnitude;
        logic [56:0] product;
        logic [23:0] quotient;
        logic [33:0] remainder_value;
        begin
            magnitude=value[32] ? (~value+33'd1) : value;
            product=magnitude*24'd11258105;
            quotient=product[56:33];
            remainder_value={1'b0,magnitude}-(34'(quotient)*34'd763);
            if(remainder_value>=34'd763) quotient=quotient+24'd1;
            divide_aid_763=value[32] ? -$signed(quotient) : $signed(quotient);
        end
    endfunction

    // Exact floor(2^16 * magnitude / denominator), with 0 <= magnitude <= denominator.
    // This bound follows from |pe-pl| <= pe+pl and |Q| <= |I|+|Q| for ALL 28-bit I/Q.
    // One integer bit and 16 fractional bits suffice, including the exact ratio 1.
    // The loop is combinational and keeps the existing feedback cycle unchanged.
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic signed [58:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[58];
                    remainder_value=trial[58] ? (remainder_value << 1) : trial[56:0];
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    // Prompt denominator is at most 2^28, so this instance needs only 29-bit remainders.
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic signed [30:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[30];
                    remainder_value=trial[30] ? (remainder_value << 1) : trial[28:0];
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    // For 16 rotations, max(|x|,|y|) <= 2^55*product(1+2^-k)+80 < 2^58.
    // Sum of all positive angle constants is < 2^31, so z is exact in 32 bits.
    // Vectoring CORDIC, turns Q32 -> Q16. Fold BPSK sign using dot's sign.
    function automatic logic signed [15:0] atan_turn_q16(input logic signed [56:0] dot_value,cross_value);
        logic signed [58:0] x,y,nx,ny;
        logic signed [31:0] z,angle;
        begin
            x=dot_value<0 ? -dot_value : dot_value;y=dot_value<0 ? -cross_value : cross_value;z=0;
            for(integer k=0;k<16;k=k+1) begin
                case(k)
                    0:angle=64'sd536870912;1:angle=64'sd316933406;2:angle=64'sd167458907;
                    3:angle=64'sd85004756;4:angle=64'sd42667331;5:angle=64'sd21354465;
                    6:angle=64'sd10679838;7:angle=64'sd5340245;8:angle=64'sd2670163;
                    9:angle=64'sd1335087;10:angle=64'sd667544;11:angle=64'sd333772;
                    12:angle=64'sd166886;13:angle=64'sd83443;14:angle=64'sd41722;default:angle=64'sd20861;
                endcase
                if(y>0) begin nx=x+(y >>> k);ny=y-(x >>> k);z=z+angle;end
                else if(y<0) begin nx=x-(y >>> k);ny=y+(x >>> k);z=z-angle;end
                else begin nx=x;ny=y;end
                x=nx;y=ny;
            end
            atan_turn_q16=16'(z >>> 16);
        end
    endfunction
    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        // A square is at most 2^54. Each power is at most 2^55 and their sum 2^56.
        code_magnitude=pe>=pl ? pe[56:0]-pl[56:0] : pl[56:0]-pe[56:0];
        phase_denominator=29'(abs_i+abs_q); // <= 2^28, including -2^27 inputs
        code_ratio=0;
        phase_ratio=0;
        if(window_done) begin
            code_ratio=normalized_ratio_q16(code_magnitude,den_code[56:0]);
            phase_ratio=normalized_phase_ratio_q16(abs_q[28:0],phase_denominator);
        end
        code_ratio_signed=!window_done ? 18'sd0 : (pe<pl ? -$signed({1'b0,code_ratio}) : $signed({1'b0,code_ratio}));
        dcode=16'((64'($signed(code_ratio_signed))*11)/32); // (1-delta)/2, delta=5/16 chip in this wrapper
        phase_ratio_signed=!window_done ? 18'sd0 : ((qp<0) != (ip<0) ? -$signed({1'b0,phase_ratio}) : $signed({1'b0,phase_ratio}));
        dphase=15'((64'($signed(phase_ratio_signed))*10430) >>> 16); // small-error Costas approximation, turn Q16
        valid_energy=pp > (64'(window_energy)*4) && den_code > (64'(window_energy)*8);
        ci_next=clamp(64'($signed(code_integral))+((dcode*932) >>> 16),CODE_LIMIT);
        fll_dot=64'($signed(previous_ip))*64'($signed(ip))+64'($signed(previous_qp))*64'($signed(qp));
        fll_cross=64'($signed(previous_ip))*64'($signed(qp))-64'($signed(previous_qp))*64'($signed(ip));
        fll_frequency=0;
        if(window_done && ENABLE_FLL!=0)
            fll_frequency=64'($signed(atan_turn_q16(fll_dot,fll_cross)))*1000;
        fll_active=ENABLE_FLL!=0 && seen<128;
        fll_adjustment=0;
        if(fll_active && previous_prompt_valid && valid_energy && window_ref==previous_prompt_ref+16368)
            fll_adjustment=(64'($signed(fll_frequency))*3277) >>> 16; // 0.05, measured residual Hz Q16
        pi_next=clamp(64'($signed(carrier_integral))+((dphase*52429) >>> 16)+fll_adjustment,CARRIER_LIMIT);
        code_command=clamp(ci_next+((dcode*349525) >>> 16),CODE_LIMIT);
        carrier_command=clamp(pi_next+dphase*40,CARRIER_LIMIT);
        // Cancel 2^7 exactly: 65536/16368000 = 512/127875 before the single truncation.
        code_delta_word=14'(divide_step_127875(40'(64'($signed(code_command))*512)));
        carrier_delta_word=23'(divide_step_127875(40'(64'($signed(carrier_command))*512)));
        initial_aid_word=divide_aid_763(33'($signed(init_doppler_word)));
        feedback_aid_word=divide_aid_763(33'(64'($signed(base_doppler))+carrier_delta_word));
        // Port the 9.28 LockEvidence/TrackingLoops policy: 128-window evidence,
        // smoothed measured errors, 32 good enter / 4 bad exit / 16 invalid exit.
        population_next={1'b0,population}+9'(valid_energy)-9'(validity_history[127]);
        phase_square=dphase*dphase;
        phase_mean_next=$signed({32'd0,phase_mean_square_q32})+(((phase_square-$signed({32'd0,phase_mean_square_q32}))*1311) >>> 16);
        code_mean_next=64'($signed(code_mean_q16))+(((dcode-64'($signed(code_mean_q16)))*1311) >>> 16);
        frequency_mean_next=64'($signed(frequency_mean_q16));
        if(previous_phase_valid)
            frequency_mean_next=frequency_mean_next+(((1000*(dphase-64'($signed(previous_phase_q16)))-frequency_mean_next)*3277) >>> 16);
        good_error=seen==128 && population>=64 && phase_mean_square_q32<32'd10737418
                   && code_mean_q16>-6554 && code_mean_q16<6554
                   && frequency_mean_q16>-655360 && frequency_mean_q16<655360;
    end
    assign observed_values={64'($signed(dcode)),64'($signed(dphase)),64'($signed(ci_next)),64'($signed(pi_next)),64'($signed(code_command)),64'($signed(carrier_command)),64'($signed(code_delta_word)),64'($signed(carrier_delta_word)),64'($signed(phase_square)),64'($signed(phase_mean_next)),64'($signed(code_mean_next)),64'($signed(frequency_mean_next)),64'($signed(fll_adjustment)),64'($signed(fll_frequency)),64'($signed(fll_dot)),64'($signed(fll_cross)),64'($signed(initial_aid_word)),64'($signed(feedback_aid_word))};
endmodule
