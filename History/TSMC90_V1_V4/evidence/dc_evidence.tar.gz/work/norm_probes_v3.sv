module norm_original (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [63:0] dcode,
    output logic signed [63:0] dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic signed [79:0] code_numerator,phase_numerator;

    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        code_numerator=(80'($signed(pe))-80'($signed(pl))) <<< 16;
        phase_numerator=80'($signed(qp)) <<< 16;
        if(ip<0) phase_numerator=-phase_numerator;
        dcode=!window_done || den_code==0 ? 64'sd0 : 64'(code_numerator / 80'($signed(den_code)));
        dcode=(dcode*11)/32; // (1-delta)/2, delta=5/16 chip in this wrapper
        dphase=!window_done || (abs_i+abs_q)==0 ? 64'sd0 : 64'(phase_numerator / 80'($signed(abs_i+abs_q)));
        dphase=(dphase*10430) >>> 16; // small-error Costas approximation, turn Q16
    end
endmodule

module norm_optimized (
    input logic window_done,
    input logic signed [27:0] ie,qe,ip,qp,il,ql,
    output logic signed [15:0] dcode,
    output logic signed [14:0] dphase
);
    logic signed [55:0] ie2,qe2,ip2,qp2,il2,ql2;
    logic [63:0] pe,pp,pl,den_code,abs_i,abs_q;
    logic [56:0] code_magnitude; logic [28:0] phase_denominator; logic [16:0] code_ratio,phase_ratio; logic signed [17:0] code_ratio_signed,phase_ratio_signed;
    function automatic logic [16:0] normalized_ratio_q16(
        input logic [56:0] magnitude, denominator
    );
        logic [56:0] remainder_value;
        logic signed [58:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[58];
                    remainder_value=trial[58] ? (remainder_value << 1) : trial[56:0];
                end
            end
            normalized_ratio_q16=quotient;
        end
    endfunction
    // Prompt denominator is at most 2^28, so this instance needs only 29-bit remainders.
    function automatic logic [16:0] normalized_phase_ratio_q16(
        input logic [28:0] magnitude, denominator
    );
        logic [28:0] remainder_value;
        logic signed [30:0] trial;
        logic [16:0] quotient;
        begin
            remainder_value=magnitude;
            quotient=0;
            trial=0;
            if(denominator!=0) begin
                if(magnitude==denominator) begin
                    remainder_value=0;
                    quotient[16]=1'b1;
                end
                for(integer bit_index=15;bit_index>=0;bit_index=bit_index-1) begin
                    trial=$signed({1'b0,remainder_value,1'b0})-$signed({2'b0,denominator});
                    quotient[bit_index]=!trial[30];
                    remainder_value=trial[30] ? (remainder_value << 1) : trial[28:0];
                end
            end
            normalized_phase_ratio_q16=quotient;
        end
    endfunction
    always_comb begin
        ie2=$signed(ie)*$signed(ie); qe2=$signed(qe)*$signed(qe);
        ip2=$signed(ip)*$signed(ip); qp2=$signed(qp)*$signed(qp);
        il2=$signed(il)*$signed(il); ql2=$signed(ql)*$signed(ql);
        pe={8'd0,ie2}+{8'd0,qe2}; pp={8'd0,ip2}+{8'd0,qp2}; pl={8'd0,il2}+{8'd0,ql2};
        den_code=pe+pl;
        abs_i=ip<0 ? 64'(-64'($signed(ip))) : 64'($signed(ip));
        abs_q=qp<0 ? 64'(-64'($signed(qp))) : 64'($signed(qp));
        // A square is at most 2^54. Each power is at most 2^55 and their sum 2^56.
        code_magnitude=pe>=pl ? pe[56:0]-pl[56:0] : pl[56:0]-pe[56:0];
        phase_denominator=29'(abs_i+abs_q); // <= 2^28, including -2^27 inputs
        code_ratio=0;
        phase_ratio=0;
        if(window_done) begin
            code_ratio=normalized_ratio_q16(code_magnitude,den_code[56:0]);
            phase_ratio=normalized_phase_ratio_q16(abs_q[28:0],phase_denominator);
        end
        code_ratio_signed=!window_done ? 18'sd0 : (pe<pl ? -$signed({1'b0,code_ratio}) : $signed({1'b0,code_ratio}));
        dcode=16'((64'($signed(code_ratio_signed))*11)/32); // (1-delta)/2, delta=5/16 chip in this wrapper
        phase_ratio_signed=!window_done ? 18'sd0 : ((qp<0) != (ip<0) ? -$signed({1'b0,phase_ratio}) : $signed({1'b0,phase_ratio}));
        dphase=15'((64'($signed(phase_ratio_signed))*10430) >>> 16); // small-error Costas approximation, turn Q16
    end
endmodule
