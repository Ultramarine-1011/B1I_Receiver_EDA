/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : O-2018.06-SP1
// Date      : Thu Nov 12 00:58:49 2026
/////////////////////////////////////////////////////////////


module b1i_period_reduce_DW01_add_4 ( A, B, CI, SUM, CO );
  input [23:0] A;
  input [23:0] B;
  output [23:0] SUM;
  input CI;
  output CO;
  wire   \carry[11] , n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13,
         n14, n15, n16, n17, n18, n19, n21, n22, n23, n24, n25, n26, n27, n28,
         n29;

  ADDFX1 U1_10 ( .A(A[10]), .B(B[10]), .CI(n1), .CO(\carry[11] ), .S(SUM[10])
         );
  AND2X2 U1 ( .A(B[9]), .B(n19), .Y(n1) );
  XNOR2X1 U2 ( .A(B[1]), .B(n29), .Y(SUM[1]) );
  INVX2 U3 ( .A(n3), .Y(n29) );
  XOR2X1 U4 ( .A(B[11]), .B(\carry[11] ), .Y(SUM[11]) );
  XOR2X1 U5 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
  XOR2X1 U6 ( .A(B[12]), .B(n2), .Y(SUM[12]) );
  XOR2X1 U7 ( .A(B[13]), .B(n4), .Y(SUM[13]) );
  XOR2X1 U8 ( .A(B[14]), .B(n5), .Y(SUM[14]) );
  XOR2X1 U9 ( .A(B[16]), .B(n7), .Y(SUM[16]) );
  XOR2X1 U10 ( .A(B[17]), .B(n8), .Y(SUM[17]) );
  XOR2X1 U11 ( .A(B[18]), .B(n9), .Y(SUM[18]) );
  AND2X2 U12 ( .A(B[11]), .B(\carry[11] ), .Y(n2) );
  AND2X2 U13 ( .A(B[0]), .B(A[0]), .Y(n3) );
  AND2X2 U14 ( .A(B[12]), .B(n2), .Y(n4) );
  AND2X2 U15 ( .A(B[13]), .B(n4), .Y(n5) );
  AND2X2 U16 ( .A(B[14]), .B(n5), .Y(n6) );
  AND2X2 U17 ( .A(B[15]), .B(n6), .Y(n7) );
  AND2X2 U18 ( .A(B[16]), .B(n7), .Y(n8) );
  AND2X2 U19 ( .A(B[17]), .B(n8), .Y(n9) );
  AND2X2 U20 ( .A(B[18]), .B(n9), .Y(n10) );
  AND2X2 U21 ( .A(B[19]), .B(n10), .Y(n11) );
  AND2X2 U22 ( .A(B[1]), .B(n3), .Y(n12) );
  AND2X2 U23 ( .A(B[2]), .B(n12), .Y(n13) );
  AND2X2 U24 ( .A(B[3]), .B(n13), .Y(n14) );
  AND2X2 U25 ( .A(B[4]), .B(n14), .Y(n15) );
  AND2X2 U26 ( .A(B[5]), .B(n15), .Y(n16) );
  AND2X2 U27 ( .A(B[6]), .B(n16), .Y(n17) );
  AND2X2 U28 ( .A(B[7]), .B(n17), .Y(n18) );
  AND2X2 U29 ( .A(B[8]), .B(n18), .Y(n19) );
  AND2X2 U30 ( .A(A[20]), .B(n11), .Y(SUM[21]) );
  XOR2X1 U31 ( .A(B[15]), .B(n6), .Y(SUM[15]) );
  XOR2X1 U32 ( .A(B[19]), .B(n10), .Y(SUM[19]) );
  XOR2X1 U33 ( .A(A[20]), .B(n11), .Y(SUM[20]) );
  XNOR2X1 U34 ( .A(B[6]), .B(n24), .Y(SUM[6]) );
  INVX2 U35 ( .A(n16), .Y(n24) );
  XNOR2X1 U36 ( .A(B[7]), .B(n23), .Y(SUM[7]) );
  INVX2 U37 ( .A(n17), .Y(n23) );
  XNOR2X1 U38 ( .A(B[8]), .B(n22), .Y(SUM[8]) );
  INVX2 U39 ( .A(n18), .Y(n22) );
  XNOR2X1 U40 ( .A(B[2]), .B(n28), .Y(SUM[2]) );
  INVX2 U41 ( .A(n12), .Y(n28) );
  XNOR2X1 U42 ( .A(B[3]), .B(n27), .Y(SUM[3]) );
  INVX2 U43 ( .A(n13), .Y(n27) );
  XNOR2X1 U44 ( .A(B[4]), .B(n26), .Y(SUM[4]) );
  INVX2 U45 ( .A(n14), .Y(n26) );
  XNOR2X1 U46 ( .A(B[5]), .B(n25), .Y(SUM[5]) );
  INVX2 U47 ( .A(n15), .Y(n25) );
  XNOR2X1 U48 ( .A(B[9]), .B(n21), .Y(SUM[9]) );
  INVX2 U49 ( .A(n19), .Y(n21) );
endmodule


module b1i_period_reduce_DW01_add_2 ( A, B, CI, SUM, CO );
  input [23:0] A;
  input [23:0] B;
  output [23:0] SUM;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n12;
  wire   [23:1] carry;

  ADDFX1 U1_9 ( .A(A[9]), .B(B[9]), .CI(carry[9]), .CO(carry[10]), .S(SUM[9])
         );
  ADDFX1 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry[5]), .CO(carry[6]), .S(SUM[5])
         );
  ADDFX1 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry[4]), .CO(carry[5]), .S(SUM[4])
         );
  ADDFX1 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry[3]), .CO(carry[4]), .S(SUM[3])
         );
  ADDFX1 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry[2]), .CO(carry[3]), .S(SUM[2])
         );
  ADDFX1 U1_10 ( .A(A[10]), .B(B[10]), .CI(carry[10]), .CO(carry[11]), .S(
        SUM[10]) );
  ADDFX1 U1_8 ( .A(A[8]), .B(B[8]), .CI(carry[8]), .CO(carry[9]), .S(SUM[8])
         );
  ADDFX1 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry[7]), .CO(carry[8]), .S(SUM[7])
         );
  ADDFX1 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry[6]), .CO(carry[7]), .S(SUM[6])
         );
  ADDFX1 U1_1 ( .A(A[1]), .B(B[1]), .CI(n1), .CO(carry[2]), .S(SUM[1]) );
  AND2X2 U1 ( .A(B[0]), .B(A[0]), .Y(n1) );
  XOR2X1 U2 ( .A(B[13]), .B(n2), .Y(SUM[13]) );
  XOR2X1 U3 ( .A(B[14]), .B(n3), .Y(SUM[14]) );
  XOR2X1 U4 ( .A(B[15]), .B(n4), .Y(SUM[15]) );
  XOR2X1 U5 ( .A(B[16]), .B(n5), .Y(SUM[16]) );
  XOR2X1 U6 ( .A(B[17]), .B(n6), .Y(SUM[17]) );
  XOR2X1 U7 ( .A(B[18]), .B(n7), .Y(SUM[18]) );
  XOR2X1 U8 ( .A(B[19]), .B(n8), .Y(SUM[19]) );
  XOR2X1 U9 ( .A(B[20]), .B(n9), .Y(SUM[20]) );
  XOR2X1 U10 ( .A(B[21]), .B(n10), .Y(SUM[21]) );
  AND2X2 U11 ( .A(B[12]), .B(n12), .Y(n2) );
  AND2X2 U12 ( .A(B[13]), .B(n2), .Y(n3) );
  AND2X2 U13 ( .A(B[14]), .B(n3), .Y(n4) );
  AND2X2 U14 ( .A(B[15]), .B(n4), .Y(n5) );
  AND2X2 U15 ( .A(B[16]), .B(n5), .Y(n6) );
  AND2X2 U16 ( .A(B[17]), .B(n6), .Y(n7) );
  AND2X2 U17 ( .A(B[18]), .B(n7), .Y(n8) );
  AND2X2 U18 ( .A(B[19]), .B(n8), .Y(n9) );
  AND2X2 U19 ( .A(B[20]), .B(n9), .Y(n10) );
  AND2X2 U20 ( .A(B[21]), .B(n10), .Y(SUM[22]) );
  XOR2X1 U21 ( .A(B[12]), .B(n12), .Y(SUM[12]) );
  XOR2X1 U22 ( .A(B[11]), .B(carry[11]), .Y(SUM[11]) );
  AND2X2 U23 ( .A(B[11]), .B(carry[11]), .Y(n12) );
  XOR2X1 U24 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
endmodule


module b1i_period_reduce_DW01_add_1 ( A, B, CI, SUM, CO );
  input [10:0] A;
  input [10:0] B;
  output [10:0] SUM;
  input CI;
  output CO;

  wire   [10:1] carry;

  ADDFX1 U1_0 ( .A(A[0]), .B(B[0]), .CI(CI), .CO(carry[1]), .S(SUM[0]) );
  ADDFX1 U1_8 ( .A(A[8]), .B(B[8]), .CI(carry[8]), .CO(carry[9]), .S(SUM[8])
         );
  ADDFX1 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry[7]), .CO(carry[8]), .S(SUM[7])
         );
  ADDFX1 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry[6]), .CO(carry[7]), .S(SUM[6])
         );
  ADDFX1 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry[5]), .CO(carry[6]), .S(SUM[5])
         );
  ADDFX1 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry[4]), .CO(carry[5]), .S(SUM[4])
         );
  ADDFX1 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry[3]), .CO(carry[4]), .S(SUM[3])
         );
  ADDFX1 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry[2]), .CO(carry[3]), .S(SUM[2])
         );
  ADDFX1 U1_1 ( .A(A[1]), .B(B[1]), .CI(carry[1]), .CO(carry[2]), .S(SUM[1])
         );
  ADDFX1 U1_9 ( .A(A[9]), .B(B[9]), .CI(carry[9]), .CO(SUM[10]), .S(SUM[9]) );
endmodule


module b1i_period_reduce_DW01_add_0 ( A, B, CI, SUM, CO );
  input [11:0] A;
  input [11:0] B;
  output [11:0] SUM;
  input CI;
  output CO;
  wire   n1;
  wire   [11:1] carry;

  ADDFX1 U1_1 ( .A(A[1]), .B(B[1]), .CI(n1), .CO(carry[2]), .S(SUM[1]) );
  ADDFX1 U1_8 ( .A(A[8]), .B(B[8]), .CI(carry[8]), .CO(carry[9]), .S(SUM[8])
         );
  ADDFX1 U1_7 ( .A(A[7]), .B(B[7]), .CI(carry[7]), .CO(carry[8]), .S(SUM[7])
         );
  ADDFX1 U1_6 ( .A(A[6]), .B(B[6]), .CI(carry[6]), .CO(carry[7]), .S(SUM[6])
         );
  ADDFX1 U1_5 ( .A(A[5]), .B(B[5]), .CI(carry[5]), .CO(carry[6]), .S(SUM[5])
         );
  ADDFX1 U1_4 ( .A(A[4]), .B(B[4]), .CI(carry[4]), .CO(carry[5]), .S(SUM[4])
         );
  ADDFX1 U1_3 ( .A(A[3]), .B(B[3]), .CI(carry[3]), .CO(carry[4]), .S(SUM[3])
         );
  ADDFX1 U1_2 ( .A(A[2]), .B(B[2]), .CI(carry[2]), .CO(carry[3]), .S(SUM[2])
         );
  ADDFX1 U1_9 ( .A(A[9]), .B(B[9]), .CI(carry[9]), .CO(carry[10]), .S(SUM[9])
         );
  AND2X2 U1 ( .A(B[0]), .B(A[0]), .Y(n1) );
  XOR2X1 U2 ( .A(B[0]), .B(A[0]), .Y(SUM[0]) );
  XOR2X1 U3 ( .A(B[10]), .B(carry[10]), .Y(SUM[10]) );
  AND2X2 U4 ( .A(B[10]), .B(carry[10]), .Y(SUM[11]) );
endmodule


module b1i_period_reduce ( value, quotient, remainder );
  input [63:0] value;
  output [31:0] quotient;
  output [42:0] remainder;
  wire   N31, N32, N33, N34, N35, N36, N37, N38, N39, N41, N43, N44, N45, N46,
         N47, N48, N49, N50, N53, N54, N55, N56, N57, N58, N59, N60, N61, N72,
         N71, N70, N69, N68, N67, N66, N65, N64, N63, N62, N124, N123, N122,
         N121, N120, N119, N118, N117, N116, N115, N9, N8, N7, N6, N5, N4, N3,
         N2, N11, N10, N1, \sub_24/carry[2] , \sub_24/carry[3] ,
         \sub_24/carry[4] , \sub_24/carry[5] , \sub_24/carry[6] ,
         \sub_24/carry[7] , \sub_24/carry[8] , \sub_24/carry[9] ,
         \sub_18/carry[2] , \sub_18/carry[3] , \sub_18/carry[4] ,
         \sub_18/carry[5] , \sub_18/carry[6] , \sub_18/carry[7] ,
         \sub_18/carry[8] , \sub_18/carry[9] , n80, n81, n82, n83, n84, n85,
         n86, n87, n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99,
         n100, n101, n102, n103, n104, n105, n106, n107, n108, n109, n110,
         n111, n112, n113, n114, n115, n116, n117, n118, n119, n120, n121,
         n122, n123, n124, n125, n126, n127, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n144, n145, n146, n147,
         n148, n149, n150, n151, n152, n153;
  wire   [11:0] digit_sum;
  wire   [1:0] quotient_correction;
  wire   [10:0] \sub_21/carry ;
  wire   [20:1] \add_3_root_add_0_root_add_30_4/carry ;
  wire   SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, 
        SYNOPSYS_UNCONNECTED__2;
  assign remainder[32] = value[32];
  assign remainder[31] = value[31];
  assign remainder[30] = value[30];
  assign remainder[29] = value[29];
  assign remainder[28] = value[28];
  assign remainder[27] = value[27];
  assign remainder[26] = value[26];
  assign remainder[25] = value[25];
  assign remainder[24] = value[24];
  assign remainder[23] = value[23];
  assign remainder[22] = value[22];
  assign remainder[21] = value[21];
  assign remainder[20] = value[20];
  assign remainder[19] = value[19];
  assign remainder[18] = value[18];
  assign remainder[17] = value[17];
  assign remainder[16] = value[16];
  assign remainder[15] = value[15];
  assign remainder[14] = value[14];
  assign remainder[13] = value[13];
  assign remainder[12] = value[12];
  assign remainder[11] = value[11];
  assign remainder[10] = value[10];
  assign remainder[9] = value[9];
  assign remainder[8] = value[8];
  assign remainder[7] = value[7];
  assign remainder[6] = value[6];
  assign remainder[5] = value[5];
  assign remainder[4] = value[4];
  assign remainder[3] = value[3];
  assign remainder[2] = value[2];
  assign remainder[1] = value[1];
  assign remainder[0] = value[0];
  assign N124 = value[62];
  assign N123 = value[61];
  assign N122 = value[60];
  assign N121 = value[59];
  assign N120 = value[58];
  assign N119 = value[57];
  assign N118 = value[56];
  assign N117 = value[55];
  assign N116 = value[54];
  assign N115 = value[53];
  assign quotient[23] = 1'b0;
  assign quotient[24] = 1'b0;
  assign quotient[25] = 1'b0;
  assign quotient[26] = 1'b0;
  assign quotient[27] = 1'b0;
  assign quotient[28] = 1'b0;
  assign quotient[29] = 1'b0;
  assign quotient[30] = 1'b0;
  assign quotient[31] = 1'b0;

  b1i_period_reduce_DW01_add_4 add_1_root_add_0_root_add_30_4 ( .A({1'b0, 1'b0, 
        1'b0, n91, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, n91, 
        1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, n91}), .B({1'b0, 
        1'b0, 1'b0, 1'b0, n90, n89, n88, n87, n86, n85, n84, n83, n82, n81, 
        n90, n89, n88, n87, n86, n85, n84, n83, n82, n81}), .CI(1'b0), .SUM({
        SYNOPSYS_UNCONNECTED__0, SYNOPSYS_UNCONNECTED__1, n153, n152, n151, 
        n150, n149, n148, n147, n146, n145, n144, n143, n142, n141, n140, n139, 
        n138, n137, n136, n135, n134, n133, n132}) );
  b1i_period_reduce_DW01_add_2 add_0_root_add_0_root_add_30_4 ( .A({1'b0, 1'b0, 
        1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, N72, 
        N71, N70, N69, N68, N67, N66, N65, N64, N63, N62}), .B({1'b0, 1'b0, 
        n153, n152, n151, n150, n149, n148, n147, n146, n145, n144, n143, n142, 
        n141, n140, n139, n138, n137, n136, n135, n134, n133, n132}), .CI(1'b0), .SUM({SYNOPSYS_UNCONNECTED__2, quotient[22:0]}) );
  b1i_period_reduce_DW01_add_1 add_2_root_add_13_3 ( .A({1'b0, value[42:33]}), 
        .B({1'b0, value[52:45], n80, value[43]}), .CI(n91), .SUM({N11, N10, N9, 
        N8, N7, N6, N5, N4, N3, N2, N1}) );
  b1i_period_reduce_DW01_add_0 add_1_root_add_13_3 ( .A({1'b0, 1'b0, n90, n89, 
        n88, n87, n86, n85, n84, n83, n82, n81}), .B({1'b0, N11, N10, N9, N8, 
        N7, N6, N5, N4, N3, N2, N1}), .CI(1'b0), .SUM({digit_sum[11:1], N41})
         );
  OAI32XL U61 ( .A0(n126), .A1(n92), .A2(n124), .B0(n124), .B1(n123), .Y(n97)
         );
  NOR2X2 U62 ( .A(n97), .B(n121), .Y(n98) );
  AND2X2 U63 ( .A(n121), .B(n93), .Y(n96) );
  OAI211XL U64 ( .A0(n122), .A1(n118), .B0(n123), .C0(n124), .Y(n93) );
  NAND2BX2 U65 ( .AN(digit_sum[1]), .B(n98), .Y(n116) );
  BUFX2 U66 ( .A(N115), .Y(n81) );
  BUFX2 U67 ( .A(value[63]), .Y(n91) );
  ADDFX1 U68 ( .A(quotient_correction[1]), .B(n80), .CI(
        \add_3_root_add_0_root_add_30_4/carry [1]), .CO(
        \add_3_root_add_0_root_add_30_4/carry [2]), .S(N63) );
  BUFX2 U69 ( .A(N116), .Y(n82) );
  BUFX2 U70 ( .A(N117), .Y(n83) );
  BUFX2 U71 ( .A(N118), .Y(n84) );
  BUFX2 U72 ( .A(N119), .Y(n85) );
  BUFX2 U73 ( .A(N120), .Y(n86) );
  BUFX2 U74 ( .A(N121), .Y(n87) );
  BUFX2 U75 ( .A(N122), .Y(n88) );
  BUFX2 U76 ( .A(N123), .Y(n89) );
  BUFX2 U77 ( .A(N124), .Y(n90) );
  BUFX2 U78 ( .A(value[44]), .Y(n80) );
  XOR2X1 U79 ( .A(digit_sum[9]), .B(\sub_18/carry[9] ), .Y(N39) );
  AND2X1 U80 ( .A(\sub_18/carry[8] ), .B(digit_sum[8]), .Y(\sub_18/carry[9] )
         );
  XOR2X1 U81 ( .A(digit_sum[8]), .B(\sub_18/carry[8] ), .Y(N38) );
  AND2X1 U82 ( .A(\sub_18/carry[7] ), .B(digit_sum[7]), .Y(\sub_18/carry[8] )
         );
  XOR2X1 U83 ( .A(digit_sum[7]), .B(\sub_18/carry[7] ), .Y(N37) );
  AND2X1 U84 ( .A(\sub_18/carry[6] ), .B(digit_sum[6]), .Y(\sub_18/carry[7] )
         );
  XOR2X1 U85 ( .A(digit_sum[6]), .B(\sub_18/carry[6] ), .Y(N36) );
  AND2X1 U86 ( .A(\sub_18/carry[5] ), .B(digit_sum[5]), .Y(\sub_18/carry[6] )
         );
  XOR2X1 U87 ( .A(digit_sum[5]), .B(\sub_18/carry[5] ), .Y(N35) );
  AND2X1 U88 ( .A(\sub_18/carry[4] ), .B(digit_sum[4]), .Y(\sub_18/carry[5] )
         );
  XOR2X1 U89 ( .A(digit_sum[4]), .B(\sub_18/carry[4] ), .Y(N34) );
  AND2X1 U90 ( .A(\sub_18/carry[3] ), .B(digit_sum[3]), .Y(\sub_18/carry[4] )
         );
  XOR2X1 U91 ( .A(digit_sum[3]), .B(\sub_18/carry[3] ), .Y(N33) );
  AND2X1 U92 ( .A(\sub_18/carry[2] ), .B(digit_sum[2]), .Y(\sub_18/carry[3] )
         );
  XOR2X1 U93 ( .A(digit_sum[2]), .B(\sub_18/carry[2] ), .Y(N32) );
  OR2X1 U94 ( .A(digit_sum[1]), .B(N41), .Y(\sub_18/carry[2] ) );
  XNOR2X1 U95 ( .A(N41), .B(digit_sum[1]), .Y(N31) );
  XOR2X1 U96 ( .A(digit_sum[9]), .B(\sub_24/carry[9] ), .Y(N61) );
  AND2X1 U97 ( .A(\sub_24/carry[8] ), .B(digit_sum[8]), .Y(\sub_24/carry[9] )
         );
  XOR2X1 U98 ( .A(digit_sum[8]), .B(\sub_24/carry[8] ), .Y(N60) );
  AND2X1 U99 ( .A(\sub_24/carry[7] ), .B(digit_sum[7]), .Y(\sub_24/carry[8] )
         );
  XOR2X1 U100 ( .A(digit_sum[7]), .B(\sub_24/carry[7] ), .Y(N59) );
  AND2X1 U101 ( .A(\sub_24/carry[6] ), .B(digit_sum[6]), .Y(\sub_24/carry[7] )
         );
  XOR2X1 U102 ( .A(digit_sum[6]), .B(\sub_24/carry[6] ), .Y(N58) );
  AND2X1 U103 ( .A(\sub_24/carry[5] ), .B(digit_sum[5]), .Y(\sub_24/carry[6] )
         );
  XOR2X1 U104 ( .A(digit_sum[5]), .B(\sub_24/carry[5] ), .Y(N57) );
  AND2X1 U105 ( .A(\sub_24/carry[4] ), .B(digit_sum[4]), .Y(\sub_24/carry[5] )
         );
  XOR2X1 U106 ( .A(digit_sum[4]), .B(\sub_24/carry[4] ), .Y(N56) );
  AND2X1 U107 ( .A(\sub_24/carry[3] ), .B(digit_sum[3]), .Y(\sub_24/carry[4] )
         );
  XOR2X1 U108 ( .A(digit_sum[3]), .B(\sub_24/carry[3] ), .Y(N55) );
  AND2X1 U109 ( .A(\sub_24/carry[2] ), .B(digit_sum[2]), .Y(\sub_24/carry[3] )
         );
  XOR2X1 U110 ( .A(digit_sum[2]), .B(\sub_24/carry[2] ), .Y(N54) );
  AND2X1 U111 ( .A(N41), .B(digit_sum[1]), .Y(\sub_24/carry[2] ) );
  XOR2X1 U112 ( .A(digit_sum[1]), .B(N41), .Y(N53) );
  XOR2X1 U113 ( .A(digit_sum[9]), .B(\sub_21/carry [9]), .Y(N50) );
  AND2X1 U114 ( .A(\sub_21/carry [8]), .B(digit_sum[8]), .Y(\sub_21/carry [9])
         );
  XOR2X1 U115 ( .A(digit_sum[8]), .B(\sub_21/carry [8]), .Y(N49) );
  AND2X1 U116 ( .A(\sub_21/carry [7]), .B(digit_sum[7]), .Y(\sub_21/carry [8])
         );
  XOR2X1 U117 ( .A(digit_sum[7]), .B(\sub_21/carry [7]), .Y(N48) );
  AND2X1 U118 ( .A(\sub_21/carry [6]), .B(digit_sum[6]), .Y(\sub_21/carry [7])
         );
  XOR2X1 U119 ( .A(digit_sum[6]), .B(\sub_21/carry [6]), .Y(N47) );
  AND2X1 U120 ( .A(\sub_21/carry [5]), .B(digit_sum[5]), .Y(\sub_21/carry [6])
         );
  XOR2X1 U121 ( .A(digit_sum[5]), .B(\sub_21/carry [5]), .Y(N46) );
  AND2X1 U122 ( .A(\sub_21/carry [4]), .B(digit_sum[4]), .Y(\sub_21/carry [5])
         );
  XOR2X1 U123 ( .A(digit_sum[4]), .B(\sub_21/carry [4]), .Y(N45) );
  AND2X1 U124 ( .A(\sub_21/carry [3]), .B(digit_sum[3]), .Y(\sub_21/carry [4])
         );
  XOR2X1 U125 ( .A(digit_sum[3]), .B(\sub_21/carry [3]), .Y(N44) );
  AND2X1 U126 ( .A(digit_sum[1]), .B(digit_sum[2]), .Y(\sub_21/carry [3]) );
  XOR2X1 U127 ( .A(digit_sum[2]), .B(digit_sum[1]), .Y(N43) );
  AND2X1 U128 ( .A(\add_3_root_add_0_root_add_30_4/carry [9]), .B(value[52]), 
        .Y(N72) );
  XOR2X1 U129 ( .A(value[52]), .B(\add_3_root_add_0_root_add_30_4/carry [9]), 
        .Y(N71) );
  AND2X1 U130 ( .A(\add_3_root_add_0_root_add_30_4/carry [8]), .B(value[51]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [9]) );
  XOR2X1 U131 ( .A(value[51]), .B(\add_3_root_add_0_root_add_30_4/carry [8]), 
        .Y(N70) );
  AND2X1 U132 ( .A(\add_3_root_add_0_root_add_30_4/carry [7]), .B(value[50]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [8]) );
  XOR2X1 U133 ( .A(value[50]), .B(\add_3_root_add_0_root_add_30_4/carry [7]), 
        .Y(N69) );
  AND2X1 U134 ( .A(\add_3_root_add_0_root_add_30_4/carry [6]), .B(value[49]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [7]) );
  XOR2X1 U135 ( .A(value[49]), .B(\add_3_root_add_0_root_add_30_4/carry [6]), 
        .Y(N68) );
  AND2X1 U136 ( .A(\add_3_root_add_0_root_add_30_4/carry [5]), .B(value[48]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [6]) );
  XOR2X1 U137 ( .A(value[48]), .B(\add_3_root_add_0_root_add_30_4/carry [5]), 
        .Y(N67) );
  AND2X1 U138 ( .A(\add_3_root_add_0_root_add_30_4/carry [4]), .B(value[47]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [5]) );
  XOR2X1 U139 ( .A(value[47]), .B(\add_3_root_add_0_root_add_30_4/carry [4]), 
        .Y(N66) );
  AND2X1 U140 ( .A(\add_3_root_add_0_root_add_30_4/carry [3]), .B(value[46]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [4]) );
  XOR2X1 U141 ( .A(value[46]), .B(\add_3_root_add_0_root_add_30_4/carry [3]), 
        .Y(N65) );
  AND2X1 U142 ( .A(\add_3_root_add_0_root_add_30_4/carry [2]), .B(value[45]), 
        .Y(\add_3_root_add_0_root_add_30_4/carry [3]) );
  XOR2X1 U143 ( .A(value[45]), .B(\add_3_root_add_0_root_add_30_4/carry [2]), 
        .Y(N64) );
  AND2X1 U144 ( .A(quotient_correction[0]), .B(value[43]), .Y(
        \add_3_root_add_0_root_add_30_4/carry [1]) );
  XOR2X1 U145 ( .A(value[43]), .B(quotient_correction[0]), .Y(N62) );
  OAI211XL U146 ( .A0(n92), .A1(n93), .B0(n94), .C0(n95), .Y(remainder[42]) );
  AOI22XL U147 ( .A0(N61), .A1(n96), .B0(N39), .B1(n97), .Y(n95) );
  CLKNAND2X2 U148 ( .A(N50), .B(n98), .Y(n94) );
  OAI2B11X1 U149 ( .A1N(digit_sum[8]), .A0(n93), .B0(n99), .C0(n100), .Y(
        remainder[41]) );
  AOI22XL U150 ( .A0(N60), .A1(n96), .B0(N38), .B1(n97), .Y(n100) );
  CLKNAND2X2 U151 ( .A(N49), .B(n98), .Y(n99) );
  OAI2B11X1 U152 ( .A1N(digit_sum[7]), .A0(n93), .B0(n101), .C0(n102), .Y(
        remainder[40]) );
  AOI22XL U153 ( .A0(N59), .A1(n96), .B0(N37), .B1(n97), .Y(n102) );
  CLKNAND2X2 U154 ( .A(N48), .B(n98), .Y(n101) );
  OAI2B11X1 U155 ( .A1N(digit_sum[6]), .A0(n93), .B0(n103), .C0(n104), .Y(
        remainder[39]) );
  AOI22XL U156 ( .A0(N58), .A1(n96), .B0(N36), .B1(n97), .Y(n104) );
  CLKNAND2X2 U157 ( .A(N47), .B(n98), .Y(n103) );
  OAI2B11X1 U158 ( .A1N(digit_sum[5]), .A0(n93), .B0(n105), .C0(n106), .Y(
        remainder[38]) );
  AOI22XL U159 ( .A0(N57), .A1(n96), .B0(N35), .B1(n97), .Y(n106) );
  CLKNAND2X2 U160 ( .A(N46), .B(n98), .Y(n105) );
  OAI211XL U161 ( .A0(n107), .A1(n93), .B0(n108), .C0(n109), .Y(remainder[37])
         );
  AOI22XL U162 ( .A0(N56), .A1(n96), .B0(N34), .B1(n97), .Y(n109) );
  CLKNAND2X2 U163 ( .A(N45), .B(n98), .Y(n108) );
  OAI211XL U164 ( .A0(n110), .A1(n93), .B0(n111), .C0(n112), .Y(remainder[36])
         );
  AOI22XL U165 ( .A0(N55), .A1(n96), .B0(N33), .B1(n97), .Y(n112) );
  CLKNAND2X2 U166 ( .A(N44), .B(n98), .Y(n111) );
  OAI211XL U167 ( .A0(n113), .A1(n93), .B0(n114), .C0(n115), .Y(remainder[35])
         );
  AOI22XL U168 ( .A0(N54), .A1(n96), .B0(N32), .B1(n97), .Y(n115) );
  CLKNAND2X2 U169 ( .A(N43), .B(n98), .Y(n114) );
  OAI2B11X1 U170 ( .A1N(digit_sum[1]), .A0(n93), .B0(n116), .C0(n117), .Y(
        remainder[34]) );
  AOI22XL U171 ( .A0(N53), .A1(n96), .B0(N31), .B1(n97), .Y(n117) );
  OAI211XL U172 ( .A0(n118), .A1(n93), .B0(n119), .C0(n120), .Y(remainder[33])
         );
  AOI22XL U173 ( .A0(n118), .A1(n96), .B0(n118), .B1(n97), .Y(n120) );
  CLKNAND2X2 U174 ( .A(N41), .B(n98), .Y(n119) );
  OR2X1 U175 ( .A(n98), .B(n97), .Y(quotient_correction[1]) );
  OR2X1 U176 ( .A(n97), .B(n96), .Y(quotient_correction[0]) );
  CLKINVX1 U177 ( .A(N41), .Y(n118) );
  AOI2BB1X1 U178 ( .A0N(n122), .A1N(n123), .B0(digit_sum[11]), .Y(n121) );
  NAND4X1 U179 ( .A(digit_sum[9]), .B(digit_sum[8]), .C(digit_sum[1]), .D(n125), .Y(n122) );
  CLKINVX1 U180 ( .A(digit_sum[10]), .Y(n123) );
  CLKINVX1 U181 ( .A(digit_sum[11]), .Y(n124) );
  CLKINVX1 U182 ( .A(digit_sum[9]), .Y(n92) );
  OAI211XL U183 ( .A0(digit_sum[1]), .A1(N41), .B0(n125), .C0(digit_sum[8]), 
        .Y(n126) );
  AND4X1 U184 ( .A(digit_sum[6]), .B(digit_sum[5]), .C(digit_sum[7]), .D(n127), 
        .Y(n125) );
  NOR3X1 U185 ( .A(n107), .B(n113), .C(n110), .Y(n127) );
  CLKINVX1 U186 ( .A(digit_sum[3]), .Y(n110) );
  CLKINVX1 U187 ( .A(digit_sum[2]), .Y(n113) );
  CLKINVX1 U188 ( .A(digit_sum[4]), .Y(n107) );
endmodule

