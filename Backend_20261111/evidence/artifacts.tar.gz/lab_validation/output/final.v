/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : O-2018.06-SP1
// Date      : Wed Nov 11 12:06:46 2026
/////////////////////////////////////////////////////////////


module backend_smoke ( clk, reset_n, enable, count );
  output [7:0] count;
  input clk, reset_n, enable;


  DFFRQX2 count_reg_7_ ( .D(count[6]), .CK(clk), .RN(reset_n), .Q(count[7]) );
  DFFRQX2 count_reg_0_ ( .D(enable), .CK(clk), .RN(reset_n), .Q(count[0]) );
  DFFRQX2 count_reg_1_ ( .D(count[0]), .CK(clk), .RN(reset_n), .Q(count[1]) );
  DFFRQX2 count_reg_2_ ( .D(count[1]), .CK(clk), .RN(reset_n), .Q(count[2]) );
  DFFRQX2 count_reg_3_ ( .D(count[2]), .CK(clk), .RN(reset_n), .Q(count[3]) );
  DFFRQX2 count_reg_4_ ( .D(count[3]), .CK(clk), .RN(reset_n), .Q(count[4]) );
  DFFRQX2 count_reg_5_ ( .D(count[4]), .CK(clk), .RN(reset_n), .Q(count[5]) );
  DFFRQX2 count_reg_6_ ( .D(count[5]), .CK(clk), .RN(reset_n), .Q(count[6]) );
endmodule

